# Cleaning Gallery v4 experimental

Adds confidence-weighted rendered-body geometry to v3.2 clustering.

- Continuous geometry only; no attractiveness or categorical grading
- Pose-normalized shoulder/pelvis/torso ratios
- Pose-anchored rendered contour measurements at upper torso, waist, and lower torso levels
- Derived chest/waist and lower-torso/waist ratios
- Confidence-adaptive body weighting; unreliable geometry falls back toward visual features
- Pose weight reduced and clustering admission relaxed to reduce false splits
- Medoid/outlier purity validation retained
- Random representative retained
- Long-press representative to open Cluster Inspector and inspect all members
- Android OS trash via MediaStore.createTrashRequest

The contour estimator is deliberately an MVP heuristic. Its purpose is A/B validation before adding a heavier segmentation model.
