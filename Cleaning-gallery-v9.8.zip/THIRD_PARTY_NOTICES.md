# Third-party notices

## Twemoji
App launcher character artwork is derived from Twemoji's Wizard emoji (U+1F9D9).

Copyright Twitter, Inc. and other contributors.
Twemoji graphics are licensed under Creative Commons Attribution 4.0 International (CC BY 4.0).
Source: https://github.com/twitter/twemoji
License: https://creativecommons.org/licenses/by/4.0/

The artwork is resized and placed on a custom rounded background for use as the launcher icon.
