# Cleaning Gallery v9.1 — Explainable automatic grading

Flow: protect → automatic analysis → S/A/B/C/D → clusters within grade → open cluster → select individual photos → Android trash.

Displayed component scores:
- Body shape: 42% of the automatic composite
- Body size / image occupancy: 28%
- Pose: 18%
- Visual/body emphasis proxy: 12%
- Detection confidence pulls uncertain results toward 50

Grade thresholds:
- S >= 78
- A >= 64
- B >= 50
- C >= 36
- D < 36

These are app heuristics derived from image geometry/pose/edge measurements, not an externally validated universal attractiveness scale. v9.1 exposes the component scores and thresholds in the UI so classification decisions can be inspected.
