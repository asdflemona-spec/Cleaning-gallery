# Gallery Cleaner v10.2 Research Ensemble

Implemented pipeline:
1. MediaStore incremental scan with protected-photo persistence.
2. MediaPipe Pose visibility routing: FULL_BODY / UPPER_TORSO / LOWER_BODY / PARTIAL / UNCERTAIN.
3. Deterministic technical evaluator: resolution, bits-per-pixel proxy, edge sharpness, exposure and tonal spread.
4. Composition evaluator: aspect/framing proxy, pose presentation and tonal spread.
5. Visible-body evaluator: only when shoulders+hips and contour confidence are available; missing body regions are UNKNOWN, not penalized.
6. Ensemble score with confidence and evaluator-disagreement diagnostics.
7. MobileNet embedding is retained for visual-relative distance/grouping, not treated as an absolute beauty oracle.
8. Cleaner candidates are independent of aesthetic score: decode failure, extreme resolution/byte anomalies, near-empty black/white frames, and deterministic dHash duplicate/derived candidates.
9. Protected photos are excluded from cleaner candidates.
10. Cleanup uses Android MediaStore trash request rather than permanent deletion.
11. Existing active-learning pair feedback and constraint clustering remain available for iterative preference research.

Known research limitation: the body-aesthetic component is an explicit heuristic preference model, not a universal or objective definition of beauty. The architecture intentionally exposes its score separately so it can be replaced by future evaluators/teacher models.
