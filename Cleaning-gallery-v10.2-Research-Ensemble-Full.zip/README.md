# Cleaning Gallery v10.2 — Research Ensemble

Android Java gallery-cleaning research app. This version combines explainable technical cleanup with a multi-evaluator human-photo research pipeline.

## Implemented
- incremental MediaStore scan and cache invalidation for v10.2
- protected photos
- thumbnail grids and normal-tap multi-select
- Android system trash flow
- Pose Landmarker Full visibility/body geometry
- MobileNet V3 Large visual embeddings for relative similarity
- FULL_BODY / UPPER_TORSO / LOWER_BODY / PARTIAL / UNCERTAIN routing
- technical, composition, visible-body and ensemble scores
- confidence + evaluator disagreement diagnostics
- deterministic automatic-cleanup candidate screen
- active-learning pair feedback / constraint clustering retained from v9.8.4
- GitHub Actions downloads required MediaPipe models and builds debug APK

The app never assigns a penalty to a body region that is not visible. Aesthetic score alone is not an automatic-delete reason.
