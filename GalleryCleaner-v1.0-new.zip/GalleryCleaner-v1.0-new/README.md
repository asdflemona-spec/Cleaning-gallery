# Gallery Cleaner 1.0
Fresh rebuild: fixed absolute grades, cropped-photo aware scoring, persistent features, incremental MediaStore scanning, 32-photo checkpoints, stable groups, and MediaStore trash.
