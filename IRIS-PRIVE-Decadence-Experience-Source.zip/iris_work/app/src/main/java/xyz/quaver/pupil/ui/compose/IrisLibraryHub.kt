package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val night = Color(0xFF110A0E)
private val gold = Color(0xFFD1AF87)
private val ivory = Color(0xFFF2E4DB)
private val velvet = Color(0xFF321B27)
private val scenes = listOf(
    Triple("Guest List", "THE INVITATION", "A private evening among extraordinary fictional guests."),
    Triple("Encounters", "AFTER DARK", "A gallery of romance, glances and midnight intrigue."),
    Triple("The Excess", "NO LIMITS", "Champagne, lavish parties and beautiful extravagance."),
    Triple("Residence", "PRIVATE SUITE", "A secluded world of velvet, marble and discreet service."),
    Triple("Concierge", "AT YOUR SERVICE", "Curate the atmosphere of an imaginary private evening."),
    Triple("Secret Archive", "BEHIND CLOSED DOORS", "A personal collection away from the crowd.")
)

/** Interactive fictional luxury setting, with a real local-media gallery in Collection. */
@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("iris_prive_decadence", 0) }
    var page by remember { mutableStateOf("Residence") }
    var scene by remember { mutableIntStateOf(prefs.getInt("scene", 0).coerceIn(0, scenes.lastIndex)) }
    var mood by remember { mutableStateOf(prefs.getString("mood", "Midnight") ?: "Midnight") }
    var source by remember { mutableStateOf("Instagram") }
    var filter by remember { mutableStateOf("All") }
    Column(Modifier.fillMaxSize().background(night)) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            Text("MEMBERS ONLY · FICTIONAL EXPERIENCE", color = gold, fontSize = 9.sp, letterSpacing = 1.sp)
            Text("IRIS PRIVÉ", color = ivory, fontSize = 29.sp, fontFamily = FontFamily.Serif)
        }
        when (page) {
            "Residence" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text("DECADENCE", color = gold, fontSize = 12.sp, letterSpacing = 3.sp)
                Text("Your Private World", color = ivory, fontSize = 28.sp, fontFamily = FontFamily.Serif)
                Text("An imaginary world of beautiful excess.", color = ivory.copy(alpha = .65f), fontSize = 12.sp)
                Spacer(Modifier.height(18.dp))
                scenes.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { entry ->
                            val index = scenes.indexOf(entry)
                            Surface(Modifier.weight(1f).padding(bottom = 10.dp).clickable {
                                scene = index; prefs.edit().putInt("scene", index).apply(); page = "Scene"
                            }, color = velvet, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, gold.copy(alpha = .35f))) {
                                Column(Modifier.padding(15.dp)) {
                                    Text(listOf("✦", "♡", "◇", "⌂", "♛", "◈")[index], color = gold, fontSize = 26.sp)
                                    Spacer(Modifier.height(24.dp))
                                    Text(entry.first, color = ivory, fontSize = 17.sp, fontFamily = FontFamily.Serif)
                                    Text(entry.second, color = gold, fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
                Text("PRIVATE ATMOSPHERE", color = gold, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Midnight", "Velvet", "Champagne").forEach { option ->
                        Surface(Modifier.weight(1f).clickable { mood = option; prefs.edit().putString("mood", option).apply() },
                            color = if (mood == option) gold else velvet, shape = RoundedCornerShape(10.dp)) {
                            Text(option, Modifier.padding(vertical = 12.dp), textAlign = TextAlign.Center,
                                color = if (mood == option) night else ivory, fontSize = 11.sp)
                        }
                    }
                }
            }
            "Scene" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(22.dp)) {
                Text("‹  RESIDENCE", Modifier.clickable { page = "Residence" }, color = gold)
                Spacer(Modifier.height(60.dp))
                Text(scenes[scene].second, color = gold, fontSize = 12.sp, letterSpacing = 2.sp)
                Text(scenes[scene].first, color = ivory, fontFamily = FontFamily.Serif, fontSize = 36.sp)
                Spacer(Modifier.height(20.dp))
                Text(scenes[scene].third, color = ivory, fontSize = 17.sp)
                Spacer(Modifier.height(26.dp))
                Text("ATMOSPHERE · $mood", color = gold, fontSize = 13.sp)
                Spacer(Modifier.height(30.dp))
                Button(onClick = { page = "Collection" }, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = gold, contentColor = night)) {
                    Text("OPEN YOUR COLLECTION")
                }
                Spacer(Modifier.height(15.dp))
                Text("Fictional scene only. No real guests, staff or services are arranged.",
                    color = ivory.copy(alpha = .55f), fontSize = 11.sp)
            }
            else -> Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("TikTok", "Instagram", "Recap").forEach { option ->
                        Surface(Modifier.weight(1f).clickable { source = option }, color = if (source == option) gold else velvet,
                            shape = RoundedCornerShape(12.dp)) {
                            Text(option, Modifier.padding(vertical = 12.dp), textAlign = TextAlign.Center,
                                color = if (source == option) night else ivory, fontSize = 12.sp)
                        }
                    }
                }
                Row {
                    listOf("All", "Images", "Videos").forEach { option ->
                        Text(option, Modifier.clickable { filter = option }.padding(12.dp),
                            color = if (filter == option) gold else ivory.copy(alpha = .65f), fontSize = 12.sp)
                    }
                }
                IrisGallerySection(Modifier.weight(1f), category = source, mediaFilter = filter)
            }
        }
        Row(Modifier.fillMaxWidth().background(velvet).padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Residence", "Collection").forEach { option ->
                Text(option, Modifier.clickable { page = option }.padding(10.dp),
                    color = if (page == option || (page == "Scene" && option == "Residence")) gold else ivory.copy(alpha = .6f))
            }
        }
    }
}
