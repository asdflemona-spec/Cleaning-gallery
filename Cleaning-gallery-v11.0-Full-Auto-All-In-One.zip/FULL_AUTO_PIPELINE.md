# Gallery Cleaner Full Auto v11.0

Pipeline: MediaStore scan -> technical quality -> dHash/derivative detection -> MediaPipe pose visibility -> view-type routing -> visible-only body geometry -> composition -> MobileNet embedding -> within-view relative calibration -> ensemble/confidence/disagreement -> KEEP/REVIEW/TRASH -> protected-photo veto -> Android MediaStore trash request.

Safety invariants:
- Protected photos never become trash candidates.
- Invisible body regions are UNKNOWN, not zero.
- Low-confidence or high-disagreement aesthetic decisions become REVIEW.
- Objective decode/empty/extreme-low-quality and dominated derivative evidence can become TRASH.
- Shared media uses Android system trash confirmation.
