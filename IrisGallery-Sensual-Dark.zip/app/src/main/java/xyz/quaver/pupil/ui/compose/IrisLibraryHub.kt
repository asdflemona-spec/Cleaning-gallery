package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Library now contains only the on-device Gallery. Source browsing remains in Search/Discover. */
@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("IrisGallery", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp))
        Text("THE AESTHETIC OF ALLURE  ·  PRIVATE LIBRARY", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(8.dp))
        IrisGallerySection(Modifier.weight(1f))
    }
}
