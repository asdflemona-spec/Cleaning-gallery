# Bobaedream adapter integration (experimental)

Two isolated ContentSource adapters share one implementation: `bobaedream_nsfw` and `bobaedream_girl`. Existing Pupil/Hitomi/Ggoorr/gallery modules are retained.

- Browse pagination: `/board/new_writing/{board}/{pageNumber}` (zero-based Iris pages).
- Post details: `/board/bbs_view/{board}/{postId}`.
- Query input filters titles on each loaded board page only; this is **not** server-side/global search.
- UI: Search, Discover, Library filters; reuses IrisViewer and IrisSourceActions.

## Validation required

The public website's rendered listing and one sample detail page were inspected. HTML/CSS selectors were not validated against raw site markup on an Android runtime. Thumbnail and detail-media extraction, hotlink/referrer handling, video playback, pagination, and source switching must be tested on device. A local Gradle compile was attempted but could not start because the wrapper distribution could not be downloaded in this environment. Do not label this integration verified or production-ready until CI and device checks pass.

The existing GitHub Actions ZIP-unpack workflow was not modified.
