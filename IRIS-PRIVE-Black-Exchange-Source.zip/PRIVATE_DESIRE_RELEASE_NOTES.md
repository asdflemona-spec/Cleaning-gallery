# IRIS PRIVÉ — Private Desire (source preview)

- Redesigned the landing collection as an obsidian/champagne private salon.
- TikTok, Instagram and Recap category buttons now select the corresponding real media presentation rather than being decorative.
- All / Images / Videos now filter local MediaStore results.
- Removed the duplicated gallery mode picker from the gallery section and avoided a vertically scrolling parent around a vertically scrolling media viewer.
- Updated the launcher display name to IRIS PRIVÉ.

## Important limitations
- This is a source preview, not a verified APK. No Android SDK/Gradle build was executed.
- The original codebase remains, including legacy features outside the landing screen.
- The three sections are viewing modes of the same device media, not proven TikTok/Instagram-origin folders.
- Official social network logo assets, app icon redesign, biometric vault, and encryption are not included.
