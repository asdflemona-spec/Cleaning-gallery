/*
 *     Pupil, Hitomi.la viewer for Android
 *     Copyright (C) 2019  tom5079
 *
 *     This program is free software: you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation, either version 3 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package xyz.quaver.pupil.ui.compose

import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import xyz.quaver.pupil.R
import xyz.quaver.pupil.histories
import xyz.quaver.pupil.readProgress
import xyz.quaver.pupil.ui.viewmodel.HistoryViewModel

/**
 * Galleries from [histories], most recently opened first.
 */
@Composable
fun HistoryScreen(
    modifier: Modifier = Modifier,
    onGalleryClick: (Int) -> Unit = {},
    onShowDetail: (Int) -> Unit = {},
    includeIris: Boolean = true,
    viewModel: HistoryViewModel = viewModel(),
) {
    Column(modifier) {
        GalleryList(
        viewModel = viewModel,
        modifier = Modifier.weight(1f),
        onGalleryClick = onGalleryClick,
        onShowDetail = onShowDetail,
        emptyMessage = stringResource(R.string.history_empty),
        noMatchMessage = stringResource(R.string.history_no_match),
    )
        if (includeIris) IrisLibrarySection(IrisLibraryFilter.HISTORY, Modifier.weight(1f))
    }

}

fun removeFromHistory(galleryID: Int) {
    histories.remove(galleryID)
    readProgress.remove(galleryID)
}
