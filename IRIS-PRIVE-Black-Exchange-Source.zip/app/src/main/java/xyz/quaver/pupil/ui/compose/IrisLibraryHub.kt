package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val ink = Color(0xFF100A0C)
private val gilt = Color(0xFFD0AC83)
private val ivory = Color(0xFFF3E7DE)
private val plum = Color(0xFF301922)
private val muted = Color(0xFFAE9295)

/** A deliberately decadent fictional catalogue, backed by real on-device media.
 *  The "lots" are media files, never people or services offered for sale.
 */
@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("iris_black_exchange", 0) }
    var section by remember { mutableStateOf("Exchange") }
    var source by remember { mutableStateOf(prefs.getString("source", "Instagram") ?: "Instagram") }
    var type by remember { mutableStateOf("All") }
    var edition by remember { mutableStateOf(prefs.getString("edition", "Velvet") ?: "Velvet") }
    val headline = when (edition) {
        "Scandal" -> "Beautifully Indiscreet"
        "Excess" -> "A Catalogue of Bad Taste"
        else -> "The Price of Elegance"
    }
    Column(Modifier.fillMaxSize().background(ink)) {
        Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 13.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("PRIVATE WHOLESALE · FICTIONAL EDITION", color = gilt, fontSize = 9.sp, letterSpacing = 1.1.sp)
                Text("IRIS PRIVÉ", color = ivory, fontSize = 28.sp, fontFamily = FontFamily.Serif)
                Text("THE BLACK EXCHANGE", color = muted, fontSize = 10.sp, letterSpacing = 2.sp)
            }
            Text("◈", color = gilt, fontSize = 27.sp)
        }
        if (section == "Exchange") {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                Surface(color = plum, shape = RoundedCornerShape(13.dp), border = BorderStroke(1.dp, gilt.copy(alpha = .35f))) {
                    Column(Modifier.fillMaxWidth().padding(15.dp)) {
                        Text("THE MIDNIGHT CATALOGUE  /  NO. 001", color = gilt, fontSize = 9.sp, letterSpacing = 1.3.sp)
                        Spacer(Modifier.height(5.dp))
                        Text(headline, color = ivory, fontFamily = FontFamily.Serif, fontSize = 23.sp)
                        Text("Expensive packaging. Shameless appetite.", color = muted, fontSize = 11.sp)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("Velvet", "Scandal", "Excess").forEach { choice ->
                                Surface(Modifier.weight(1f).clickable {
                                    edition = choice
                                    prefs.edit().putString("edition", choice).apply()
                                }, color = if (edition == choice) gilt else ink, shape = RoundedCornerShape(7.dp)) {
                                    Text(choice.uppercase(), Modifier.padding(vertical = 8.dp), textAlign = TextAlign.Center,
                                        color = if (edition == choice) ink else ivory, fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(11.dp))
                Text("SELECT A SOURCE", color = gilt, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("TikTok", "Instagram", "Recap").forEach { choice ->
                        Surface(Modifier.weight(1f).clickable {
                            source = choice
                            prefs.edit().putString("source", choice).apply()
                        }, color = if (source == choice) gilt else plum, shape = RoundedCornerShape(9.dp)) {
                            Text(choice, Modifier.padding(vertical = 11.dp), textAlign = TextAlign.Center,
                                color = if (source == choice) ink else ivory, fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text("THE PRIVATE VAULT", color = gilt, fontSize = 11.sp, letterSpacing = 2.sp)
                Text("Objects of Desire", color = ivory, fontFamily = FontFamily.Serif, fontSize = 24.sp)
                Text("Only media marked as favourites on your device appears here.", color = muted, fontSize = 11.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            (if (section == "Vault") listOf("Favorites") else listOf("All", "Images", "Videos")).forEach { choice ->
                Text(choice.uppercase(), Modifier.clickable { type = choice }.padding(vertical = 7.dp),
                    color = if (section == "Vault" || type == choice) gilt else muted, fontSize = 11.sp)
            }
        }
        // The real, permission-aware local gallery is the catalogue itself; no decorative dead-end cards.
        IrisGallerySection(Modifier.weight(1f), category = source, mediaFilter = if (section == "Vault") "Favorites" else type)
        Row(Modifier.fillMaxWidth().background(plum).padding(vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Exchange", "Vault").forEach { choice ->
                Text(if (choice == "Exchange") "◇  EXCHANGE" else "♢  VAULT",
                    Modifier.clickable { section = choice }.padding(horizontal = 20.dp, vertical = 5.dp),
                    color = if (section == choice) gilt else muted, fontSize = 12.sp)
            }
        }
    }
}
