package xyz.quaver.pupil.ui.compose

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import coil3.compose.AsyncImage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray

/** User-initiated downloads only. Credentials are handled by the first-party site, never by Iris. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun IrisSocialWebSource(service: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val isX = service == "x"
    val home = if (isX) "https://x.com/" else "https://www.pinterest.com/"
    val login = if (isX) "https://x.com/i/flow/login" else "https://www.pinterest.com/login/"
    var webView by remember(service) { mutableStateOf<WebView?>(null) }
    var currentUrl by remember(service) { mutableStateOf(home) }
    var canBack by remember(service) { mutableStateOf(false) }
    var candidates by remember(service) { mutableStateOf<List<String>>(emptyList()) }
    var showPicker by remember(service) { mutableStateOf(false) }
    var search by remember(service) { mutableStateOf("") }
    var selected by remember(service) { mutableStateOf(setOf<String>()) }

    fun offer(url: String?) {
        if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
            candidates = listOf(url)
            selected = setOf(url)
            showPicker = true
        } else Toast.makeText(context, "직접 저장 가능한 미디어 주소가 없습니다.", Toast.LENGTH_SHORT).show()
    }

    DisposableEffect(service) {
        onDispose {
            webView?.stopLoading()
            webView?.destroy()
            webView = null
        }
    }
    BackHandler(canBack) { webView?.goBack() }
    Column(modifier) {
        Text(if (isX) "X · 미디어 탐색" else "Pinterest · 미디어 탐색", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                value = search, onValueChange = { search = it },
                label = { Text(if (isX) "검색어 또는 @계정" else "핀 검색어") },
                modifier = Modifier.weight(1f), singleLine = true,
            )
            Button(onClick = {
                val q = search.trim().removePrefix("@")
                if (q.isNotEmpty()) {
                    val destination = if (isX && search.trim().startsWith("@"))
                        "https://x.com/" + Uri.encode(q)
                    else if (isX) "https://x.com/search?q=" + Uri.encode(search.trim())
                    else "https://www.pinterest.com/search/pins/?q=" + Uri.encode(search.trim())
                    webView?.loadUrl(destination)
                }
            }, modifier = Modifier.padding(top = 8.dp)) { Text("검색") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            TextButton(onClick = { webView?.loadUrl(home) }) { Text("홈") }
            TextButton(onClick = { webView?.loadUrl(login) }) { Text("로그인") }
            TextButton(onClick = { webView?.reload() }) { Text("새로고침") }
            TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))) }) { Text("외부 브라우저") }
        }
        Button(onClick = {
            // Extract visible media from the nearest post when possible; never read passwords or cookies in JS.
            val script = """(function(){var root=document.querySelector('article:hover')||document.querySelector('article:focus-within')||document.querySelector('[data-test-id="pin"]:hover')||document;var els=root.querySelectorAll('img,video,video source');var out=[];for(var i=0;i<els.length;i++){var e=els[i];var u=e.currentSrc||e.src||e.getAttribute('src');if(u&&u.indexOf('https://')===0&&out.indexOf(u)<0){out.push(u);}}return JSON.stringify(out.slice(0,80));})()"""
            webView?.evaluateJavascript(script) { encoded ->
                try {
                    val decoded = JSONArray("[$encoded]").getString(0)
                    val arr = JSONArray(decoded)
                    candidates = (0 until arr.length()).map { arr.getString(it) }.filter { it.startsWith("https://") }.distinct()
                    selected = candidates.toSet()
                    if (candidates.isNotEmpty()) showPicker = true
                    else Toast.makeText(context, "다운로드 가능한 미디어를 찾지 못했습니다.", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {
                    Toast.makeText(context, "미디어 검색에 실패했습니다.", Toast.LENGTH_SHORT).show()
                }
            }
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) { Text("사진 · 동영상 선택") }
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.setSupportMultipleWindows(false)
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            currentUrl = url ?: home
                            canBack = view?.canGoBack() == true
                        }
                    }
                    setOnLongClickListener {
                        val hit = hitTestResult
                        if (hit.type == WebView.HitTestResult.IMAGE_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                            offer(hit.extra)
                            true
                        } else false
                    }
                    setDownloadListener { url, _, _, _, _ -> offer(url) }
                    loadUrl(home)
                    webView = this
                }
            },
            update = { webView = it },
        )
    }
    if (showPicker) {
        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("미디어 선택 · ${candidates.size}개") },
            text = {
                Column {
                    Text("사진과 동영상을 선택해 저장합니다. 썸네일이나 직접 접근할 수 없는 스트림은 저장되지 않을 수 있습니다.")
                    Row {
                        TextButton(onClick = { selected = candidates.toSet() }) { Text("전체 선택") }
                        TextButton(onClick = { selected = emptySet() }) { Text("선택 해제") }
                    }
                    LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                        itemsIndexed(candidates) { index, url ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Checkbox(checked = url in selected, onCheckedChange = { checked ->
                                    selected = if (checked) selected + url else selected - url
                                })
                                if (url.substringBefore('?').matches(Regex(".*\\.(jpg|jpeg|png|webp|gif)", RegexOption.IGNORE_CASE))) {
                                    AsyncImage(model = url, contentDescription = null, modifier = Modifier.size(56.dp))
                                }
                                Text("${index + 1}. " + url.substringBefore('?').takeLast(45), maxLines = 2, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = selected.isNotEmpty(), onClick = {
                    selected.forEach { url -> queueSocialDownload(context, url, if (isX) "X" else "Pinterest", currentUrl) }
                    showPicker = false
                }) { Text("${selected.size}개 다운로드") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("취소") } }
        )
    }

}

private fun queueSocialDownload(context: Context, url: String, service: String, referer: String) {
    try {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" || uri.host.isNullOrBlank()) throw IllegalArgumentException("HTTPS 주소만 지원")
        val name = URLUtil.guessFileName(url, null, null).take(100)
        val request = DownloadManager.Request(uri)
            .setTitle(name)
            .setDescription("IrisGallery $service")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, "Iris/$service/$name")
        CookieManager.getInstance().getCookie(url)?.let { request.addRequestHeader("Cookie", it) }
        if (referer.startsWith("https://")) request.addRequestHeader("Referer", referer)
        request.addRequestHeader("User-Agent", android.webkit.WebSettings.getDefaultUserAgent(context))
        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        Toast.makeText(context, "다운로드 대기열에 추가했습니다. 알림에서 결과를 확인하세요.", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "다운로드 요청 실패: ${e.message}", Toast.LENGTH_LONG).show()
    }
}
