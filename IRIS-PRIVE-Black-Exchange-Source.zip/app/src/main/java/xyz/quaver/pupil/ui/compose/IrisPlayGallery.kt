package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisGalleryMedia

/** Puzzle is the only retained experimental Library play mode. */
@Composable
fun IrisPlayGallery(
    media: List<IrisGalleryMedia>,
    mode: IrisGallerySkin,
    open: (IrisGalleryMedia) -> Unit,
    modifier: Modifier = Modifier
) {
    if (mode != IrisGallerySkin.PUZZLE) return
    val photos = remember(media) { media.filter { !it.isVideo } }
    if (photos.isEmpty()) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Add photos to play")
        }
        return
    }
    PuzzleGallery(photos, modifier, open)
}

@Composable
private fun PuzzleGallery(
    photos: List<IrisGalleryMedia>,
    modifier: Modifier,
    open: (IrisGalleryMedia) -> Unit
) {
    var index by remember { mutableIntStateOf(0) }
    var revealed by remember(index) { mutableStateOf(setOf<Int>()) }
    val photo = photos[index.mod(photos.size)]
    Column(modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Reveal the picture · ${revealed.size}/9", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
            AsyncImage(
                model = photo.uri,
                contentDescription = photo.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Column(Modifier.fillMaxSize()) {
                repeat(3) { row ->
                    Row(Modifier.weight(1f)) {
                        repeat(3) { col ->
                            val cell = row * 3 + col
                            Box(
                                Modifier.weight(1f).fillMaxHeight().padding(1.dp)
                                    .background(if (cell in revealed) Color.Transparent else Color(0xFF38455D))
                                    .clickable { revealed = revealed + cell },
                                contentAlignment = Alignment.Center
                            ) {
                                if (cell !in revealed) Text("${cell + 1}", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
        Row {
            TextButton(onClick = { revealed = (0..8).toSet() }) { Text("Reveal all") }
            Button(onClick = { index++ }) { Text("Next photo") }
            TextButton(onClick = { open(photo) }) { Text("Open") }
        }
    }
}
