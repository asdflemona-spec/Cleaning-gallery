package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import xyz.quaver.pupil.source.GgoorrSource
import xyz.quaver.pupil.source.DcinsideSource
import xyz.quaver.pupil.source.BobaedreamSource
import xyz.quaver.pupil.source.HitomiSource
import xyz.quaver.pupil.source.SourceItem

private enum class DiscoverSource { ALL, HITOMI, GGOORR, BOBA_NSFW, BOBA_GIRL, DC_GIRL, DC_BEST }

/** Content-first browse page inspired by successful multi-source artwork browsers. */
@Composable
fun IrisDiscoverScreen(onSearchClick: () -> Unit) {
    val hitomi = remember { HitomiSource() }
    val ggoorr = remember { GgoorrSource() }
    val bobaNsfw = remember { BobaedreamSource("nsfw") }
    val bobaGirl = remember { BobaedreamSource("girl") }
    val dcGirl = remember { DcinsideSource("duwk") }
    val dcBest = remember { DcinsideSource("dcbest") }
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(DiscoverSource.ALL) }
    var items by remember { mutableStateOf<List<SourceItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun refresh() { scope.launch {
        loading = true; error = null
        try {
            items = when (selected) {
                DiscoverSource.HITOMI -> hitomi.search("").items
                DiscoverSource.GGOORR -> ggoorr.search("").items
                DiscoverSource.BOBA_NSFW -> bobaNsfw.browse().items
                DiscoverSource.BOBA_GIRL -> bobaGirl.browse().items
                DiscoverSource.DC_GIRL -> dcGirl.browse().items
                DiscoverSource.DC_BEST -> dcBest.browse().items
                DiscoverSource.ALL -> {
                    val a = async { runCatching { hitomi.search("").items }.getOrDefault(emptyList()) }
                    val b = async { runCatching { ggoorr.search("").items }.getOrDefault(emptyList()) }
                    val c = async { runCatching { bobaNsfw.browse().items }.getOrDefault(emptyList()) }
                    val d = async { runCatching { bobaGirl.browse().items }.getOrDefault(emptyList()) }
                    (a.await() + b.await() + c.await() + d.await() +
                        async { runCatching { dcGirl.browse().items }.getOrDefault(emptyList()) }.await() +
                        async { runCatching { dcBest.browse().items }.getOrDefault(emptyList()) }.await()).distinctBy { "${it.sourceId}:${it.remoteId}" }
                }
            }
        } catch (t: Throwable) { error = t.message ?: "Unable to load this source" }
        finally { loading = false }
    } }
    LaunchedEffect(selected) { refresh() }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp)) {
            Text("Discover", style = MaterialTheme.typography.headlineLarge)
            Text("Artwork from your sources", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))
            Surface(shape = MaterialTheme.shapes.extraLarge, tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth().clickable(onClick = onSearchClick)) {
                Text("Search artwork, tags, creators…", Modifier.padding(16.dp))
            }
            Spacer(Modifier.height(10.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected == DiscoverSource.ALL, { selected = DiscoverSource.ALL }, { Text("All") }) }
                item { FilterChip(selected == DiscoverSource.HITOMI, { selected = DiscoverSource.HITOMI }, { Text("Hitomi") }) }
                item { FilterChip(selected == DiscoverSource.GGOORR, { selected = DiscoverSource.GGOORR }, { Text("Ggoorr") }) }
                item { FilterChip(selected == DiscoverSource.BOBA_NSFW, { selected = DiscoverSource.BOBA_NSFW }, { Text("NSFW") }) }
                item { FilterChip(selected == DiscoverSource.BOBA_GIRL, { selected = DiscoverSource.BOBA_GIRL }, { Text("Girl") }) }
                item { FilterChip(selected == DiscoverSource.DC_GIRL, { selected = DiscoverSource.DC_GIRL }, { Text("DC Girl") }) }
                item { FilterChip(selected == DiscoverSource.DC_BEST, { selected = DiscoverSource.DC_BEST }, { Text("DC Best") }) }
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text(it, Modifier.padding(16.dp)) }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(items, key = { "${it.sourceId}:${it.remoteId}" }) { item ->
                Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onSearchClick)) {
                    RemoteImage(item.thumbnailUrl, Modifier.fillMaxWidth().height(190.dp), item.title, contentScale = ContentScale.Crop,
                        headers = when (item.sourceId) {
                            "ggoorr" -> ggoorr.requestHeaders
                            "bobaedream_nsfw" -> bobaNsfw.requestHeaders
                            "bobaedream_girl" -> bobaGirl.requestHeaders
                            "dcinside_duwk" -> dcGirl.requestHeaders
                            "dcinside_dcbest" -> dcBest.requestHeaders
                            else -> emptyMap()
                        })
                    Column(Modifier.padding(10.dp)) {
                        Text(item.title, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                        Text(item.sourceId, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
