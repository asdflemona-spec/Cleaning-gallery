# Cleaning Gallery v9 — Automatic grading + manual deletion

Flow: protect photos → on-device feature extraction → automatic S/A/B/C/D grading → similarity clustering inside each grade → open a cluster → manually select individual images → Android OS trash.

v9 removes active learning, Must-Link/Cannot-Link feedback, and random-representative whole-cluster deletion from the main flow.

Automatic grading uses only image-derived geometry/presentation signals already extracted on device: rendered body geometry, relative size/shape, pose geometry, contour confidence, and visual presentation features. The depicted subjects are treated as synthetic/non-real imagery; the app does not infer identity, ethnicity, or age.

The grade is a heuristic organization score, not an objective claim about attractiveness. Within each grade, body/pose/visual similarity is used to form smaller clusters. Deletion always requires opening a cluster and explicitly selecting images.
