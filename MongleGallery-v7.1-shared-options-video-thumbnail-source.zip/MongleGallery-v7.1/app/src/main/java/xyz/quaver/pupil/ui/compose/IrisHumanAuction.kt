package xyz.quaver.pupil.ui.compose

import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisAuctionRecord
import xyz.quaver.pupil.util.IrisAuctionStore
import xyz.quaver.pupil.util.IrisAuctionOptions

private val fieldNames = mapOf("function" to "기능적", "status" to "상태적", "social" to "사회적", "legal" to "법적")

@Composable
private fun AuctionPreview(uri: String) {
    val context = LocalContext.current
    val video = remember(uri) {
        val parsed = Uri.parse(uri)
        parsed.path?.contains("/video/", ignoreCase = true) == true ||
            runCatching { context.contentResolver.getType(parsed)?.startsWith("video/") == true }.getOrDefault(false)
    }
    if (!video) {
        AsyncImage(model = uri, contentDescription = "경매 물품 사진", modifier = Modifier.size(100.dp), contentScale = ContentScale.Crop)
    } else {
        val bitmap by produceState<android.graphics.Bitmap?>(null, uri) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(context, Uri.parse(uri))
                        retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?: retriever.getFrameAtTime()
                    } finally { retriever.release() }
                }.getOrNull()
            }
        }
        Box(Modifier.size(100.dp).background(Color.DarkGray), contentAlignment = Alignment.Center) {
            bitmap?.let { Image(it.asImageBitmap(), "동영상 대표 화면", Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            Text("▶", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Composable
fun IrisHumanAuction(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var records by remember { mutableStateOf(IrisAuctionStore.list(context)) }
    var editing by remember { mutableStateOf<IrisAuctionRecord?>(null) }
    var managing by remember { mutableStateOf(false) }
    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("경매 물품", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = { managing = true }) { Text("속성 선택지 관리") }
        }
        if (records.isEmpty()) Text("경매 물품이 없습니다. 갤러리에서 ♥를 선택하세요.", Modifier.padding(16.dp))
        LazyColumn(contentPadding = PaddingValues(8.dp)) {
            items(records, key = { it.uri }) { record ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { editing = record }) {
                    Row(Modifier.padding(12.dp)) {
                        AuctionPreview(record.uri)
                        Column(Modifier.padding(start = 12.dp)) {
                            Text("H-${record.number.toString().padStart(3, '0')}", style = MaterialTheme.typography.titleMedium)
                            Text("경제적 · ${record.credits} 크레딧")
                            Text("기능적 · ${record.function}")
                            Text("상태적 · ${record.status}")
                            Text("사회적 · ${record.social}")
                            Text("법적 · ${record.legal}")
                        }
                    }
                }
            }
        }
    }
    if (managing) OptionManager(onClose = { managing = false; records = IrisAuctionStore.list(context) })
    editing?.let { initial ->
        var credits by remember(initial.uri) { mutableStateOf(initial.credits.toString()) }
        var function by remember(initial.uri) { mutableStateOf(initial.function) }
        var status by remember(initial.uri) { mutableStateOf(initial.status) }
        var social by remember(initial.uri) { mutableStateOf(initial.social) }
        var legal by remember(initial.uri) { mutableStateOf(initial.legal) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("H-${initial.number.toString().padStart(3, '0')} 속성 선택") },
            text = {
                Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                    OutlinedTextField(credits, { credits = it.filter(Char::isDigit).take(8) }, label = { Text("경제적 · 크레딧") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    AuctionOptionPicker("function", function) { function = it }
                    AuctionOptionPicker("status", status) { status = it }
                    AuctionOptionPicker("social", social) { social = it }
                    AuctionOptionPicker("legal", legal) { legal = it }
                    Text("선택지는 모든 경매 물품에서 공유됩니다.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    IrisAuctionStore.update(context, initial.copy(
                        credits = credits.toIntOrNull() ?: 0,
                        function = function, status = status, social = social, legal = legal
                    ))
                    records = IrisAuctionStore.list(context)
                    editing = null
                }) { Text("저장") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("취소") } }
        )
    }
}

@Composable
private fun AuctionOptionPicker(category: String, selected: String, onSelect: (String) -> Unit) {
    val context = LocalContext.current
    var options by remember(category) { mutableStateOf(IrisAuctionOptions.list(context, category)) }
    var expanded by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text("${fieldNames[category]} 속성", style = MaterialTheme.typography.labelLarge)
        Box {
            OutlinedButton(onClick = { options = IrisAuctionOptions.list(context, category); expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected.ifBlank { "선택하세요" }, modifier = Modifier.weight(1f))
                Text("⌄")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                DropdownMenuItem(text = { Text("선택 안 함") }, onClick = { onSelect(""); expanded = false })
                options.forEach { value ->
                    DropdownMenuItem(text = { Text(value) }, onClick = { onSelect(value); expanded = false })
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(draft, { draft = it }, label = { Text("새 선택지 입력") }, singleLine = true, modifier = Modifier.weight(1f))
            TextButton(onClick = {
                if (draft.isNotBlank()) {
                    IrisAuctionOptions.add(context, category, draft)
                    options = IrisAuctionOptions.list(context, category)
                    onSelect(draft.trim())
                    draft = ""
                }
            }) { Text("추가") }
        }
    }
}

@Composable
private fun OptionManager(onClose: () -> Unit) {
    val context = LocalContext.current
    var revision by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("공통 속성 선택지 관리") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                fieldNames.forEach { (category, name) ->
                    key(category, revision) {
                        var draft by remember { mutableStateOf("") }
                        Text("$name 속성", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 12.dp))
                        IrisAuctionOptions.list(context, category).forEach { option ->
                            var rename by remember(option) { mutableStateOf(option) }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(rename, { rename = it }, modifier = Modifier.weight(1f), singleLine = true)
                                TextButton(onClick = {
                                    IrisAuctionOptions.rename(context, category, option, rename)
                                    revision++
                                }) { Text("수정") }
                                TextButton(onClick = {
                                    IrisAuctionOptions.remove(context, category, option)
                                    revision++
                                }) { Text("삭제") }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(draft, { draft = it }, label = { Text("새 선택지") }, modifier = Modifier.weight(1f), singleLine = true)
                            TextButton(onClick = {
                                IrisAuctionOptions.add(context, category, draft)
                                revision++
                            }) { Text("추가") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("완료") } }
    )
}
