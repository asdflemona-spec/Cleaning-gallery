package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val black = Color(0xFF0B0B0C)
private val gold = Color(0xFFC2A785)
private val white = Color(0xFFEAE2D8)
private data class ChatLine(val mine: Boolean, val text: String)

@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("iris_secretary", 0) }
    var page by remember { mutableStateOf("Collection") }
    var category by remember { mutableStateOf("Instagram") }
    var filter by remember { mutableStateOf("All") }
    var draft by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(ChatLine(false, "안녕하세요. IRIS PRIVÉ 비서입니다. 가격표 작성, 컬렉션 이용법, 전시 문구를 도와드릴게요. 현재는 오프라인 기본 응답 모드입니다.")) }
    fun reply(q: String): String {
        val t = q.lowercase()
        return when {
            "가격" in t || "price" in t -> "Collection에서 사진이나 영상을 고른 뒤, 썸네일 아래 '+ 가격'을 누르면 원화 가격표를 직접 저장할 수 있습니다. 실제 거래 기능은 없습니다."
            "영상" in t || "비디오" in t -> "Collection에서 Videos를 선택하고 썸네일을 누르면 영상을 재생합니다."
            "사진" in t || "이미지" in t -> "Collection에서 Images를 선택하면 사진만 볼 수 있습니다."
            "문구" in t || "소개" in t -> "추천 전시 문구: '가장 사적인 취향에 붙인 가장 터무니없는 가격.'"
            "안녕" in t -> "어서 오세요. 오늘은 어떤 컬렉션을 정리해 드릴까요?"
            else -> "현재는 인터넷 AI가 연결되지 않은 기본 비서입니다. '가격', '사진', '영상', '전시 문구'를 물어보실 수 있어요. 자유 대화형 AI는 별도 모델 연결이 필요합니다."
        }
    }
    Column(Modifier.fillMaxSize().background(black)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("PRIVATE COLLECTION", color = gold, fontSize = 9.sp, letterSpacing = 2.sp)
                Text("IRIS PRIVÉ", color = white, fontSize = 27.sp, fontFamily = FontFamily.Serif)
            }
            Text("◇", color = gold, fontSize = 24.sp)
        }
        if (page == "Collection") {
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("TikTok", "Instagram", "Recap").forEach { c ->
                    Surface(Modifier.weight(1f).clickable { category = c }, color = if (category == c) gold else Color(0xFF30232A), shape = RoundedCornerShape(10.dp)) {
                        Text(c, Modifier.padding(vertical = 11.dp), color = if (category == c) black else white, fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
            Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(15.dp)) {
                listOf("All", "Images", "Videos").forEach { f ->
                    Text(f, Modifier.clickable { filter = f }.padding(7.dp), color = if (filter == f) gold else white, fontSize = 12.sp)
                }
            }
            IrisGallerySection(Modifier.weight(1f).padding(horizontal = 6.dp), category = category, mediaFilter = filter)
        } else {
            Text("PRIVATE SECRETARY", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = gold, fontSize = 11.sp)
            Text("기본 오프라인 채팅 · 외부 AI 미연결", Modifier.padding(horizontal = 18.dp), color = white, fontSize = 11.sp)
            androidx.compose.foundation.lazy.LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(messages.size) { i ->
                    val line = messages[i]
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.mine) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (line.mine) gold else Color(0xFF30232A), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth(.87f)) {
                            Text(line.text, Modifier.padding(13.dp), color = if (line.mine) black else white, fontSize = 14.sp)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("비서에게 메시지...") }, singleLine = true)
                TextButton(onClick = {
                    val q = draft.trim()
                    if (q.isNotEmpty()) { messages.add(ChatLine(true, q)); messages.add(ChatLine(false, reply(q))); draft = "" }
                }) { Text("전송", color = gold) }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFF25181E)).padding(12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Collection", "Secretary").forEach { tab ->
                Text(tab, Modifier.clickable { page = tab }.padding(8.dp), color = if (page == tab) gold else white)
            }
        }
    }
}
