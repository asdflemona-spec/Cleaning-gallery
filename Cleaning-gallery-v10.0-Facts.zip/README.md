# Gallery Cleaner v1.0 Facts

AI aesthetic grading has been removed.

Classification/search uses only explicit or deterministically computed information:
- MediaStore filename, folder/RELATIVE_PATH, MIME type, timestamps, byte size, width/height/orientation
- user-explicit protected state and tags
- optional SHA-256 exact-file duplicate detection

No NIMA, Pose Landmarker, MobileNet, aesthetic score, body geometry, or learned classifier is used.
Selected non-protected photos are sent to Android system trash via MediaStore.createTrashRequest().
