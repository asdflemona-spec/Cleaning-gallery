package com.cleaninggallery.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import java.io.*;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 static final int PERM=10, TRASH=200;
 final ArrayList<Photo> photos=new ArrayList<>(), shown=new ArrayList<>();
 final HashSet<Long> protectedIds=new HashSet<>(), selected=new HashSet<>();
 final ExecutorService pool=Executors.newSingleThreadExecutor();
 LinearLayout root, filters; TextView title,status; GridView grid; PhotoAdapter adapter;
 EditText query,minW,minH,minMB,tagQuery; Spinner orientation,mime,sort; CheckBox onlyProtected,onlyDuplicates;
 SharedPreferences state,tags;
 static class Photo { long id,taken,modified,size; int w,h; String name="",mime="",path="",sha=""; Uri uri; Photo(long id,Uri u){this.id=id;uri=u;} }
 int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
 TextView tv(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(0xff111111);v.setPadding(dp(12),dp(6),dp(12),dp(6));return v;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setMinHeight(dp(50));return b;}
 @Override public void onCreate(Bundle b){super.onCreate(b);state=getSharedPreferences("v10_state",0);tags=getSharedPreferences("v10_tags",0);build();requestAccess();}
 void build(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xfffafafa);root.setPadding(0,dp(6),0,dp(8));title=tv("Gallery Cleaner · Facts",25);title.setTypeface(null,1);status=tv("사진 인덱스를 읽는 중…",14);root.addView(title);root.addView(status);
   filters=new LinearLayout(this);filters.setOrientation(LinearLayout.VERTICAL);query=new EditText(this);query.setHint("파일명 / 폴더 / MIME / 태그 검색");query.setSingleLine(true);query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);filters.addView(query);
   LinearLayout row1=new LinearLayout(this);orientation=spinner(new String[]{"방향: 전체","세로","가로","정사각"});mime=spinner(new String[]{"형식: 전체","JPEG","PNG","WEBP","GIF","HEIC/HEIF"});sort=spinner(new String[]{"정렬: 최신","오래된","큰 파일","작은 파일","고해상도","파일명"});row1.addView(orientation,new LinearLayout.LayoutParams(0,dp(52),1));row1.addView(mime,new LinearLayout.LayoutParams(0,dp(52),1));row1.addView(sort,new LinearLayout.LayoutParams(0,dp(52),1));filters.addView(row1);
   LinearLayout row2=new LinearLayout(this);minW=num("최소 W");minH=num("최소 H");minMB=num("최소 MB");row2.addView(minW,new LinearLayout.LayoutParams(0,dp(52),1));row2.addView(minH,new LinearLayout.LayoutParams(0,dp(52),1));row2.addView(minMB,new LinearLayout.LayoutParams(0,dp(52),1));filters.addView(row2);
   tagQuery=new EditText(this);tagQuery.setHint("선택 사진에 붙일 태그 (명시적 사용자 정보)");tagQuery.setSingleLine(true);filters.addView(tagQuery);
   LinearLayout row3=new LinearLayout(this);onlyProtected=new CheckBox(this);onlyProtected.setText("보호만");onlyDuplicates=new CheckBox(this);onlyDuplicates.setText("완전 중복만");Button apply=btn("검색");row3.addView(onlyProtected);row3.addView(onlyDuplicates);row3.addView(apply,new LinearLayout.LayoutParams(0,dp(52),1));filters.addView(row3);root.addView(filters);
   grid=new GridView(this);grid.setNumColumns(4);grid.setVerticalSpacing(dp(2));grid.setHorizontalSpacing(dp(2));adapter=new PhotoAdapter();grid.setAdapter(adapter);root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
   LinearLayout bar=new LinearLayout(this);Button protect=btn("보호"),tag=btn("태그"),dup=btn("중복 계산"),trash=btn("휴지통");bar.addView(protect,new LinearLayout.LayoutParams(0,dp(62),1));bar.addView(tag,new LinearLayout.LayoutParams(0,dp(62),1));bar.addView(dup,new LinearLayout.LayoutParams(0,dp(62),1));bar.addView(trash,new LinearLayout.LayoutParams(0,dp(62),1));root.addView(bar);setContentView(root);
   apply.setOnClickListener(v->applyFilters());query.setOnEditorActionListener((v,a,e)->{applyFilters();return true;});grid.setOnItemClickListener((p,v,pos,id)->{long x=shown.get(pos).id;if(!selected.add(x))selected.remove(x);adapter.notifyDataSetChanged();updateStatus();});
   protect.setOnClickListener(v->{for(long id:selected){if(!protectedIds.add(id))protectedIds.remove(id);}saveProtected();adapter.notifyDataSetChanged();updateStatus();});
   tag.setOnClickListener(v->applyTag());dup.setOnClickListener(v->computeHashes());trash.setOnClickListener(v->trashSelected());
 }
 Spinner spinner(String[] a){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));return s;}
 EditText num(String hint){EditText e=new EditText(this);e.setHint(hint);e.setInputType(2|8192);e.setTextSize(13);return e;}
 void requestAccess(){String p=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_EXTERNAL_STORAGE;if(checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED)loadPhotos();else requestPermissions(new String[]{p},PERM);}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==PERM&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)loadPhotos();else status.setText("사진 접근 권한이 필요합니다.");}
 void loadProtected(){protectedIds.clear();String x=state.getString("protected","");for(String q:x.split(","))try{if(!q.isEmpty())protectedIds.add(Long.parseLong(q));}catch(Exception ignored){}}
 void saveProtected(){StringBuilder b=new StringBuilder();for(long x:protectedIds){if(b.length()>0)b.append(',');b.append(x);}state.edit().putString("protected",b.toString()).apply();}
 void loadPhotos(){loadProtected();photos.clear();String[] pr={MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME,MediaStore.Images.Media.MIME_TYPE,MediaStore.Images.Media.RELATIVE_PATH,MediaStore.Images.Media.DATE_TAKEN,MediaStore.Images.Media.DATE_MODIFIED,MediaStore.Images.Media.SIZE,MediaStore.Images.Media.WIDTH,MediaStore.Images.Media.HEIGHT};
   try(Cursor c=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,pr,null,null,MediaStore.Images.Media.DATE_TAKEN+" DESC")){if(c!=null)while(c.moveToNext()){long id=c.getLong(0);Photo p=new Photo(id,ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,id));p.name=nz(c.getString(1));p.mime=nz(c.getString(2));p.path=nz(c.getString(3));p.taken=c.getLong(4);p.modified=c.getLong(5);p.size=c.getLong(6);p.w=c.getInt(7);p.h=c.getInt(8);p.sha=state.getString("sha_"+id+"_"+p.modified+"_"+p.size,"");photos.add(p);}}
   applyFilters();}
 String nz(String s){return s==null?"":s;}
 int intv(EditText e){try{return Integer.parseInt(e.getText().toString().trim());}catch(Exception x){return 0;}}
 double dbl(EditText e){try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;}}
 void applyFilters(){String q=query.getText().toString().trim().toLowerCase(Locale.ROOT);int mw=intv(minW),mh=intv(minH);double mb=dbl(minMB);int o=orientation.getSelectedItemPosition(),m=mime.getSelectedItemPosition();HashMap<String,Integer> hc=hashCounts();shown.clear();
   for(Photo p:photos){String tg=tags.getString("t_"+p.id,"");String hay=(p.name+" "+p.path+" "+p.mime+" "+tg).toLowerCase(Locale.ROOT);if(!q.isEmpty()&&!hay.contains(q))continue;if(p.w<mw||p.h<mh||p.size<mb*1024*1024)continue;if(onlyProtected.isChecked()&&!protectedIds.contains(p.id))continue;if(onlyDuplicates.isChecked()&&(p.sha.isEmpty()||hc.getOrDefault(p.sha,0)<2))continue;if(o==1&&!(p.h>p.w))continue;if(o==2&&!(p.w>p.h))continue;if(o==3&&p.w!=p.h)continue;if(!mimeOk(p.mime,m))continue;shown.add(p);}
   Comparator<Photo> cmp;switch(sort.getSelectedItemPosition()){case 1:cmp=Comparator.comparingLong(x->x.taken);break;case 2:cmp=(a,b)->Long.compare(b.size,a.size);break;case 3:cmp=Comparator.comparingLong(x->x.size);break;case 4:cmp=(a,b)->Long.compare((long)b.w*b.h,(long)a.w*a.h);break;case 5:cmp=(a,b)->a.name.compareToIgnoreCase(b.name);break;default:cmp=(a,b)->Long.compare(b.taken,a.taken);}shown.sort(cmp);selected.retainAll(ids(shown));adapter.notifyDataSetChanged();updateStatus();}
 boolean mimeOk(String s,int m){if(m==0)return true;s=s.toLowerCase(Locale.ROOT);if(m==1)return s.contains("jpeg")||s.contains("jpg");if(m==2)return s.contains("png");if(m==3)return s.contains("webp");if(m==4)return s.contains("gif");return s.contains("heic")||s.contains("heif");}
 HashSet<Long> ids(List<Photo>a){HashSet<Long>x=new HashSet<>();for(Photo p:a)x.add(p.id);return x;}
 HashMap<String,Integer> hashCounts(){HashMap<String,Integer> m=new HashMap<>();for(Photo p:photos)if(!p.sha.isEmpty())m.put(p.sha,m.getOrDefault(p.sha,0)+1);return m;}
 void updateStatus(){long bytes=0;for(Photo p:shown)bytes+=p.size;status.setText("전체 "+photos.size()+" · 검색결과 "+shown.size()+" · 선택 "+selected.size()+" · "+String.format(Locale.US,"%.1f MB",bytes/1048576.0)+(onlyDuplicates.isChecked()?" · SHA-256 완전중복":""));}
 void applyTag(){String t=tagQuery.getText().toString().trim();if(selected.isEmpty()){Toast.makeText(this,"사진을 먼저 선택하세요",Toast.LENGTH_SHORT).show();return;}SharedPreferences.Editor e=tags.edit();for(long id:selected){String old=tags.getString("t_"+id,"");if(t.isEmpty())e.remove("t_"+id);else{LinkedHashSet<String>s=new LinkedHashSet<>();for(String x:old.split(","))if(!x.trim().isEmpty())s.add(x.trim());s.add(t);e.putString("t_"+id,String.join(",",s));}}e.apply();Toast.makeText(this,t.isEmpty()?"태그 제거":"태그 추가: "+t,Toast.LENGTH_SHORT).show();applyFilters();}
 void computeHashes(){status.setText("SHA-256 계산 중… 파일 바이트가 같은 사진만 중복으로 판정합니다.");pool.submit(()->{int done=0;SharedPreferences.Editor ed=state.edit();for(Photo p:photos){if(p.sha.isEmpty())try(InputStream in=getContentResolver().openInputStream(p.uri)){MessageDigest md=MessageDigest.getInstance("SHA-256");byte[] b=new byte[65536];int n;while(in!=null&&(n=in.read(b))>0)md.update(b,0,n);p.sha=hex(md.digest());ed.putString("sha_"+p.id+"_"+p.modified+"_"+p.size,p.sha);}catch(Exception ignored){}done++;if(done%50==0){ed.apply();ed=state.edit();final int d=done;runOnUiThread(()->status.setText("SHA-256 "+d+" / "+photos.size()));}}ed.apply();runOnUiThread(()->{applyFilters();Toast.makeText(this,"완전 중복 계산 완료",Toast.LENGTH_SHORT).show();});});}
 String hex(byte[] a){StringBuilder b=new StringBuilder();for(byte x:a)b.append(String.format(Locale.US,"%02x",x&255));return b.toString();}
 void trashSelected(){ArrayList<Uri> u=new ArrayList<>();for(Photo p:shown)if(selected.contains(p.id)&&!protectedIds.contains(p.id))u.add(p.uri);if(u.isEmpty()){Toast.makeText(this,"선택된 비보호 사진이 없습니다",Toast.LENGTH_SHORT).show();return;}try{PendingIntent pi=MediaStore.createTrashRequest(getContentResolver(),u,true);startIntentSenderForResult(pi.getIntentSender(),TRASH,null,0,0,0);}catch(Exception e){Toast.makeText(this,"휴지통 요청 실패",Toast.LENGTH_LONG).show();}}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==TRASH&&c==RESULT_OK){selected.clear();loadPhotos();}}
 class PhotoAdapter extends BaseAdapter {public int getCount(){return shown.size();}public Object getItem(int i){return shown.get(i);}public long getItemId(int i){return shown.get(i).id;}public View getView(int i,View v,ViewGroup parent){FrameLayout box=v instanceof FrameLayout?(FrameLayout)v:new FrameLayout(MainActivity.this);box.removeAllViews();Photo p=shown.get(i);ImageView im=new ImageView(MainActivity.this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(im,new FrameLayout.LayoutParams(-1,dp(112)));try{im.setImageBitmap(getContentResolver().loadThumbnail(p.uri,new android.util.Size(300,300),null));}catch(Exception ignored){}TextView meta=tv((protectedIds.contains(p.id)?"🔒 ":"")+p.w+"×"+p.h,10);meta.setTextColor(Color.WHITE);meta.setBackgroundColor(0x88000000);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,dp(28),Gravity.BOTTOM);box.addView(meta,lp);box.setForeground(new ColorDrawable(selected.contains(p.id)?0x8833aa55:0));return box;}}
 @Override protected void onDestroy(){super.onDestroy();pool.shutdownNow();}
}
