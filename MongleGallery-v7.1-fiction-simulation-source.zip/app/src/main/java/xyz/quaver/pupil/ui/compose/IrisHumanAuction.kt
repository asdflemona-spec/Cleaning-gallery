package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisAuctionRecord
import xyz.quaver.pupil.util.IrisAuctionStore
import xyz.quaver.pupil.util.IrisSimulationStore
import xyz.quaver.pupil.util.IrisSimulation

@Composable
fun IrisHumanAuction(modifier:Modifier=Modifier){
    val context=LocalContext.current
    var records by remember { mutableStateOf(IrisAuctionStore.list(context)) }
    var editing by remember { mutableStateOf<IrisAuctionRecord?>(null) }
    var section by remember { mutableStateOf(0) }
    var simulationId by remember { mutableStateOf<String?>(null) }
    Column(modifier){
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)) {
            FilterChip(section==0,{section=0},label={Text("추천 자료")})
            Spacer(Modifier.width(8.dp))
            FilterChip(section==1,{section=1},label={Text("제도 전시")})
            Spacer(Modifier.width(8.dp))
            FilterChip(section==2,{section=2},label={Text("구조 분석")})
        }
        if(section==1 || section==2){
            Text(if(section==1) "성노예제 제도 전시 · 비판적 분석" else "성착취 구조 분석 · 비판적 분석",style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(16.dp))
            Text("가상 제도 분석입니다. 실제 사진 속 인물의 권리·소유권·성적 동의를 변경하지 않습니다.",modifier=Modifier.padding(horizontal=16.dp))
            TextButton(onClick={simulationId="F-001"},modifier=Modifier.padding(horizontal=12.dp)){Text("가상 사례 F-001 편집 및 이력 보기") }
            val stages=if(section==1) listOf("정보화 · 사진과 기록","서열화 · 분류 제도의 작동","상품화 · 역사적 거래 구조","도구화 · 권리 침해의 구조","제도적 처우 · 통제와 배제") else listOf("시각적 소비 · 열람과 비교","상업적 소비 · 상품화 메커니즘","강제적 이용 · 동의권 침해","권리 회복 · 보호와 지원")
            stages.forEachIndexed { index, stage -> Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp)){Text("${index+1}. $stage",modifier=Modifier.padding(14.dp))} }
        } else {
        Text("인간 경매 · 가상 사진 카탈로그",style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(16.dp))
        Text("실제 인물의 거래·법적 지위를 나타내지 않는 사용자 지정 분류입니다.",modifier=Modifier.padding(horizontal=16.dp))
        LazyColumn { items(records,key={it.uri}) { r ->
            Card(Modifier.fillMaxWidth().padding(8.dp).clickable { editing=r }) {
                Row(Modifier.padding(12.dp)) {
                    AsyncImage(model=r.uri,contentDescription="추천 사진",modifier=Modifier.size(100.dp))
                    Column(Modifier.padding(start=12.dp)) {
                        Text("H-${r.number.toString().padStart(3,'0')}",style=MaterialTheme.typography.titleMedium)
                        Text("경제적 · ${r.credits} 크레딧")
                        Text("기능적 · ${r.function}")
                        Text("정보적 · ${r.score}/100")
                        Text("사회적 · ${r.social}")
                        Text("법적 · ${r.legal}")
                    }
                }
            }
        } }
        }
    }
    simulationId?.let { id ->
        FictionSimulationDialog(id,onClose={simulationId=null})
    }
    editing?.let { initial ->
        var credits by remember(initial.uri) { mutableStateOf(initial.credits.toString()) }
        var function by remember(initial.uri) { mutableStateOf(initial.function) }
        var score by remember(initial.uri) { mutableFloatStateOf(initial.score.toFloat()) }
        var social by remember(initial.uri) { mutableStateOf(initial.social) }
        var legal by remember(initial.uri) { mutableStateOf(initial.legal) }
        AlertDialog(onDismissRequest={editing=null},title={Text("H-${initial.number.toString().padStart(3,'0')} 속성 편집")},text={
            Column {
                Text("경제적 속성 (가상 크레딧)")
                OutlinedTextField(credits,{credits=it.filter(Char::isDigit).take(8)},label={Text("크레딧")},singleLine=true)
                Text("기능적 속성")
                AttributeSelector(function,listOf("일반 작업형","창작형","분석형","지원형","기타")){function=it}
                Text("정보적 속성 · ${score.toInt()}/100")
                Slider(score,{score=it},valueRange=0f..100f)
                Text("사회적 속성")
                AttributeSelector(social,(1..5).map { "제${it}등급" }){social=it}
                Text("법적 속성 (가상 세계관 설정)")
                AttributeSelector(legal,listOf("독립적 인격 불인정","가상 자율 객체","가상 등록 객체","미분류")){legal=it}
            }
        },confirmButton={TextButton(onClick={
            IrisAuctionStore.update(context,initial.copy(credits=credits.toIntOrNull()?:0,function=function,score=score.toInt(),social=social,legal=legal))
            records=IrisAuctionStore.list(context);editing=null
        }){Text("저장")}},dismissButton={TextButton(onClick={editing=null}){Text("취소")}})
    }
}

@Composable private fun AttributeSelector(value:String,choices:List<String>,onChange:(String)->Unit){
    var expanded by remember { mutableStateOf(false) }
    Box { TextButton(onClick={expanded=true}){Text("$value ▾")}
        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
            choices.forEach { option -> DropdownMenuItem(text={Text(option)},onClick={onChange(option);expanded=false}) }
        }
    }
}

/** Isolated fictional case editor: never binds coercive classifications to gallery photos. */
@Composable private fun FictionSimulationDialog(id:String,onClose:()->Unit){
    val context=LocalContext.current
    var record by remember(id) { mutableStateOf(IrisSimulationStore.get(context,id)) }
    var credits by remember(id) { mutableStateOf(record.credits.toString()) }
    AlertDialog(onDismissRequest=onClose,title={Text("가상 제도 사례 $id")},text={
        Column {
            Text("실존 인물이나 추천 사진에 적용되지 않는 허구의 제도 모델입니다.")
            Text("① 서열화 · 가상 평가")
            AttributeSelector(record.rank,listOf("고평가","저평가","평가 제외")){record=record.copy(rank=it)}
            Text("② 상품화 · 모의 크레딧 (실제 결제 없음)")
            OutlinedTextField(credits,{credits=it.filter(Char::isDigit).take(7)},label={Text("가상 크레딧")},singleLine=true)
            Text("③ 제도적 처우")
            AttributeSelector(record.exposure,listOf("노출","접근 제한","배제")){record=record.copy(exposure=it)}
            Text("④ 통제 상태")
            AttributeSelector(record.governance,listOf("기록","통제","재심사","해제")){record=record.copy(governance=it)}
            Text("⑤ 가상 제도 내 동의권")
            AttributeSelector(record.consent,listOf("권리 보장","제도적 권리 박탈 묘사","권리 회복")){record=record.copy(consent=it)}
            Text("⑥ 기록 단계")
            AttributeSelector(record.phase,listOf("등록","평가","모의 거래 기록","통제 분석","결과 분석")){record=record.copy(phase=it)}
            Text("변경 이력 (${record.history.size}건)")
            record.history.takeLast(4).forEach { Text("• $it",style=MaterialTheme.typography.bodySmall) }
        }
    },confirmButton={TextButton(onClick={
        val updated=record.copy(credits=credits.toIntOrNull()?:0)
        val event="${updated.phase}: ${updated.rank} / ${updated.credits} CR / ${updated.exposure} / ${updated.governance} / ${updated.consent}"
        IrisSimulationStore.save(context,updated,event)
        record=IrisSimulationStore.get(context,id)
    }){Text("기록 저장")}},dismissButton={TextButton(onClick=onClose){Text("닫기")}})
}
