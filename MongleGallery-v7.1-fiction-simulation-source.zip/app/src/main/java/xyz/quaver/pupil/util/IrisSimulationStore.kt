package xyz.quaver.pupil.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Fiction-only institutional simulation. No actual person, rights, or property is transferred. */
data class IrisSimulation(val id:String, val rank:String="평가 제외", val exposure:String="제한", val governance:String="기록", val consent:String="권리 보장", val credits:Int=40, val phase:String="등록", val history:List<String> = emptyList())

object IrisSimulationStore {
    private fun prefs(c:Context)=c.getSharedPreferences("iris_fiction_sim_v1",Context.MODE_PRIVATE)
    fun get(c:Context,id:String):IrisSimulation {
        val raw=prefs(c).getString(id,null) ?: return IrisSimulation(id)
        return runCatching {
            val o=JSONObject(raw); val a=o.optJSONArray("history") ?: JSONArray()
            IrisSimulation(id,o.optString("rank","평가 제외"),o.optString("exposure","제한"),o.optString("governance","기록"),o.optString("consent","권리 보장"),o.optInt("credits",40),o.optString("phase","등록"),(0 until a.length()).map { a.getString(it) })
        }.getOrElse { IrisSimulation(id) }
    }
    fun save(c:Context,v:IrisSimulation,event:String) {
        val a=JSONArray(); (v.history+event).takeLast(100).forEach(a::put)
        val o=JSONObject().put("rank",v.rank).put("exposure",v.exposure).put("governance",v.governance).put("consent",v.consent).put("credits",v.credits).put("phase",v.phase).put("history",a)
        prefs(c).edit().putString(v.id,o.toString()).apply()
    }
}
