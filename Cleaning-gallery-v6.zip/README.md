# Cleaning Gallery v6 — Personalized Attractiveness-Type Clustering

Experimental Android MVP for a gallery containing fictional/non-real characters.

## v6 changes
- Replaces the final hand-weighted distance with a 16D personalized attractiveness-type embedding head.
- Feedback labels are `same attractiveness type` / `different attractiveness type`.
- Fixed ~20% holdout split based on photo-ID pair hash. Holdout pairs are never used to update the embedding.
- Shows feedback/train/validation counts and unseen holdout accuracy.
- Hard negatives update the embedding away from the current representative.
- Feedback persists in SharedPreferences.
- Tap the review subtitle or use Inspector > Learning diagnostics to inspect validation state and re-cluster immediately.
- Keeps v5 body/pose/visual feature extraction as cold-start inputs; the learned projection determines their combinations rather than a fixed final weight vector.

## Validation
Success should be judged by unseen holdout accuracy together with manual false-merge / false-split checks and average cluster size. Holdout accuracy alone is not sufficient.
