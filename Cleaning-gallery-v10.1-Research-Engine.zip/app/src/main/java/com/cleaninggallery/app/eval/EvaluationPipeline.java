package com.cleaninggallery.app.eval;

import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.List;

/** Plug-in pipeline. Future pose/body/human-aesthetic models are added as independent evaluators. */
public final class EvaluationPipeline {
    private final List<Evaluator> evaluators = new ArrayList<>();
    public EvaluationPipeline(){ evaluators.add(new TechnicalEvaluator()); }
    public List<Evaluation> run(Bitmap bitmap, PhotoFacts facts){
        ArrayList<Evaluation> out=new ArrayList<>();
        for(Evaluator e:evaluators) out.add(e.evaluate(bitmap,facts));
        return out;
    }
}
