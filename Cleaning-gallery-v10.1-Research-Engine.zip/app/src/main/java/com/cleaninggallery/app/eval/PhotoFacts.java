package com.cleaninggallery.app.eval;

public final class PhotoFacts {
    public long id, sizeBytes, dateTaken, dateModified;
    public int width, height;
    public String mimeType = "", displayName = "", relativePath = "";
    public double megapixels(){ return width > 0 && height > 0 ? (width * (double)height) / 1_000_000.0 : 0; }
    public double bytesPerPixel(){ return width > 0 && height > 0 ? sizeBytes / (double)(width * (long)height) : Double.NaN; }
}
