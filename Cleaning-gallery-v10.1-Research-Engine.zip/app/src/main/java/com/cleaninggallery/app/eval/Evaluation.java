package com.cleaninggallery.app.eval;

import java.util.LinkedHashMap;
import java.util.Map;

/** Raw, inspectable evaluator output. Missing evidence is UNKNOWN, never a bad score. */
public final class Evaluation {
    public enum View { UNKNOWN, FULL_BODY, UPPER_BODY, LOWER_BODY, PARTIAL_BODY, FACE_OR_HEAD, OTHER }
    public final Map<String, Double> metrics = new LinkedHashMap<>();
    public View view = View.UNKNOWN;
    public double technical = Double.NaN;
    public double framing = Double.NaN;
    public double form = Double.NaN;
    public double humanAesthetic = Double.NaN;
    public double overall = Double.NaN;
    public double confidence = 0.0;
    public boolean evaluable = false;
    public String reason = "not evaluated";
}
