package com.cleaninggallery.app.eval;

import android.graphics.Bitmap;

/** Deterministic technical measurements only; no semantic or beauty claim. */
public final class TechnicalEvaluator implements Evaluator {
    public String id(){ return "technical-v1"; }
    public Evaluation evaluate(Bitmap b, PhotoFacts f){
        Evaluation e = new Evaluation();
        e.metrics.put("megapixels", f.megapixels());
        e.metrics.put("bytes_per_pixel", f.bytesPerPixel());
        if (b == null || b.getWidth() < 2 || b.getHeight() < 2) { e.reason="decode/size failure"; return e; }
        int w=b.getWidth(), h=b.getHeight(), step=Math.max(1, Math.min(w,h)/96);
        double sum=0,sum2=0,edges=0; long n=0, en=0;
        for(int y=0;y<h;y+=step) for(int x=0;x<w;x+=step){
            int c=b.getPixel(x,y); double l=.2126*((c>>16)&255)+.7152*((c>>8)&255)+.0722*(c&255);
            sum+=l; sum2+=l*l; n++;
            if(x+step<w){int q=b.getPixel(x+step,y);double l2=.2126*((q>>16)&255)+.7152*((q>>8)&255)+.0722*(q&255);edges+=Math.abs(l-l2);en++;}
            if(y+step<h){int q=b.getPixel(x,y+step);double l2=.2126*((q>>16)&255)+.7152*((q>>8)&255)+.0722*(q&255);edges+=Math.abs(l-l2);en++;}
        }
        double mean=sum/Math.max(1,n), variance=sum2/Math.max(1,n)-mean*mean, edge=edges/Math.max(1,en);
        e.metrics.put("luma_mean",mean); e.metrics.put("luma_variance",Math.max(0,variance)); e.metrics.put("edge_energy",edge);
        double mp=f.megapixels(), res=Math.min(1.0, mp/2.0), exposure=1.0-Math.min(1.0,Math.abs(mean-127.5)/127.5);
        double contrast=Math.min(1.0,Math.sqrt(Math.max(0,variance))/55.0), detail=Math.min(1.0,edge/24.0);
        e.technical=100.0*(.35*res+.20*exposure+.20*contrast+.25*detail);
        e.evaluable=true; e.confidence=.95; e.reason="deterministic pixel/file measurements";
        return e;
    }
}
