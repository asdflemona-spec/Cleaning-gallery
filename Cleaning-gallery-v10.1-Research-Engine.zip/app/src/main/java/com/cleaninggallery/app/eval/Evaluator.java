package com.cleaninggallery.app.eval;

import android.graphics.Bitmap;

public interface Evaluator {
    String id();
    Evaluation evaluate(Bitmap bitmap, PhotoFacts facts);
}
