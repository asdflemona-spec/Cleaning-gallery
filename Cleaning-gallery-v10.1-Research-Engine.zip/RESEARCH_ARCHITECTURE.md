# Gallery Cleaner Research Engine v1

## Goal
Rank and clean a gallery without pretending that one fixed formula is universal beauty. Preserve raw evidence and evaluator disagreement so failed cases become the next experiment set.

## Evaluation layers
1. Technical facts: resolution, bytes/pixel, luminance, contrast, edge/detail proxies, decode status.
2. View/visibility taxonomy: full body, upper body, lower body, partial body, face/head, other, unknown.
3. Composition/framing: future independent evaluator.
4. Visible-form/body-shape aesthetics: future independent evaluator; only score visible/evaluable regions.
5. Human-image aesthetics: future teacher/student evaluator inspired by HumanAesExpert's fine-grained HIAA dimensions.
6. Relative ranking: compare only compatible view/evidence classes.
7. Cleaning: objective redundancy/derivative/technical-failure rules plus conservative aesthetic ranking.

## Invariants
- UNKNOWN is never converted to zero/bad.
- No hidden body part is inferred merely to fill a score.
- Raw measurements and each evaluator's version are persisted separately before fusion.
- A new evaluator can be added/removed without changing MediaStore/trash code.
- Conflicting evaluators create research samples instead of automatic deletion.
- Permanent deletion is out of scope; Android trash remains the destructive boundary.

## Next experiments
- visibility/view classifier
- pose/segmentation based evaluability mask
- HumanAesExpert teacher benchmark on a representative offline sample
- small student/ranker distilled from teacher outputs
- pairwise ranker within compatible view classes
- duplicate/derivative cleaner
- disagreement/error-set exporter
