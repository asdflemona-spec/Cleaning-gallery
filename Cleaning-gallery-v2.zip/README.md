# Cleaning Gallery MVP v2

## Flow
전체 사진 → 보호할 사진 선택 → 나머지 이미지 특징 분석/군집화 → 군집별 랜덤 1장 → 군집 전체를 Android 시스템 휴지통으로.

## v2 changes
- Bottom controls respect system status/navigation areas (`fitsSystemWindows`, bottom padding).
- Replaced date-only clustering.
- On-device visual features: 64-bit difference hash, average RGB color, aspect ratio, capture time.
- Hybrid clustering:
  - temporal neighbor similarity (up to 30 minutes / local window)
  - global perceptual-hash LSH buckets for similar images across time
  - giant-cluster splitting to prevent nearly the whole library becoming one cluster
  - largest clusters shown first for deletion leverage
- Random representative is preserved exactly as requested.

## Build
Android 11+ / compileSdk 35 / JDK 17.
Use the included `.github/workflows/build-apk.yml`.
