
package com.cleaninggallery.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int PERM=10, TRASH=200;
    private final ArrayList<Photo> photos=new ArrayList<>();
    private final HashSet<Long> protectedIds=new HashSet<>();
    private final ArrayList<Cluster> clusters=new ArrayList<>();
    private int clusterIndex=0;
    private LinearLayout root;
    private TextView title,subtitle;
    private final ExecutorService pool=Executors.newFixedThreadPool(Math.max(2,Runtime.getRuntime().availableProcessors()-1));

    static class Photo {
        long id,taken,hash; Uri uri; int w,h,r,g,b; boolean featured;
        Photo(long id,long taken,Uri uri){this.id=id;this.taken=taken;this.uri=uri;}
        double aspect(){return h==0?1.0:(double)w/h;}
    }
    static class Cluster { ArrayList<Photo> items=new ArrayList<>(); Photo sample; }
    static class DSU {
        int[] p,s;
        DSU(int n){p=new int[n];s=new int[n];for(int i=0;i<n;i++){p[i]=i;s[i]=1;}}
        int f(int x){while(p[x]!=x){p[x]=p[p[x]];x=p[x];}return x;}
        void u(int a,int b){a=f(a);b=f(b);if(a==b)return;if(s[a]<s[b]){int t=a;a=b;b=t;}p[b]=a;s[a]+=s[b];}
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setNavigationBarColor(Color.WHITE);
        if(Build.VERSION.SDK_INT>=23)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        buildShell(); requestAccess();
    }
    private int dp(int x){return(int)(x*getResources().getDisplayMetrics().density);}
    private TextView tv(String s,int sp){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(0xff111111);v.setPadding(dp(16),dp(8),dp(16),dp(8));return v;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setMinHeight(dp(56));return b;}

    private void buildShell(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xfffafafa);
        // Do not draw edge-to-edge. fitSystemWindows keeps controls above nav/status bars.
        root.setFitsSystemWindows(true);
        root.setPadding(0,dp(6),0,dp(12));
        title=tv("Cleaning Gallery",26);title.setTypeface(null,1);
        subtitle=tv("사진을 불러오는 중…",15);
        root.addView(title);root.addView(subtitle);setContentView(root);
    }
    private void requestAccess(){
        String p=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_EXTERNAL_STORAGE;
        if(checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED)loadPhotos();else requestPermissions(new String[]{p},PERM);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r==PERM&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)loadPhotos();else subtitle.setText("사진 접근 권한이 필요합니다.");
    }
    private void loadPhotos(){
        photos.clear();
        String[] pr={MediaStore.Images.Media._ID,MediaStore.Images.Media.DATE_TAKEN,MediaStore.Images.Media.WIDTH,MediaStore.Images.Media.HEIGHT};
        try(Cursor c=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,pr,null,null,MediaStore.Images.Media.DATE_TAKEN+" DESC")){
            if(c!=null){int ci=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID),ct=c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN);
                int cw=c.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH),ch=c.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT);
                while(c.moveToNext()){long id=c.getLong(ci);Photo p=new Photo(id,c.getLong(ct),Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,""+id));p.w=c.getInt(cw);p.h=c.getInt(ch);photos.add(p);}
            }
        } showProtectScreen();
    }
    private void resetBody(){while(root.getChildCount()>2)root.removeViewAt(2);}
    private void showProtectScreen(){
        resetBody();title.setText("1. 제거 안 할 사진 선택");subtitle.setText("전체 "+photos.size()+"장 · 탭한 사진은 보호");
        GridView grid=new GridView(this);grid.setNumColumns(4);grid.setVerticalSpacing(dp(2));grid.setHorizontalSpacing(dp(2));grid.setClipToPadding(false);grid.setPadding(0,0,0,dp(12));
        PhotoAdapter a=new PhotoAdapter(photos,protectedIds);grid.setAdapter(a);
        grid.setOnItemClickListener((p,v,pos,id)->{long x=photos.get(pos).id;if(!protectedIds.add(x))protectedIds.remove(x);a.notifyDataSetChanged();subtitle.setText("전체 "+photos.size()+"장 · 보호 "+protectedIds.size()+"장");});
        root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        Button next=btn("보호 완료 → 정교하게 군집화");next.setOnClickListener(v->startClustering());root.addView(next,new LinearLayout.LayoutParams(-1,dp(68)));
    }

    private void startClustering(){
        resetBody();title.setText("2. 이미지 분석");subtitle.setText("시각 특징을 계산하는 중…");
        ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(photos.size());root.addView(bar,new LinearLayout.LayoutParams(-1,dp(48)));
        pool.submit(()->{
            ArrayList<Photo> work=new ArrayList<>();for(Photo p:photos)if(!protectedIds.contains(p.id))work.add(p);
            int done=0;for(Photo p:work){computeFeature(p);int d=++done;if(d%20==0)runOnUiThread(()->{bar.setProgress(d);subtitle.setText("이미지 분석 "+d+" / "+work.size());});}
            ArrayList<Cluster> made=cluster(work);
            runOnUiThread(()->{clusters.clear();clusters.addAll(made);clusterIndex=0;showCluster();});
        });
    }

    private void computeFeature(Photo p){
        try{
            Bitmap src=getContentResolver().loadThumbnail(p.uri,new android.util.Size(96,96),null);
            Bitmap small=Bitmap.createScaledBitmap(src,9,8,true);
            long h=0;int bit=0;
            for(int y=0;y<8;y++)for(int x=0;x<8;x++){int a=small.getPixel(x,y),b=small.getPixel(x+1,y);int la=Color.red(a)*3+Color.green(a)*6+Color.blue(a),lb=Color.red(b)*3+Color.green(b)*6+Color.blue(b);if(la>lb)h|=(1L<<bit);bit++;}
            p.hash=h;
            Bitmap col=Bitmap.createScaledBitmap(src,4,4,true);long rr=0,gg=0,bb=0;
            for(int y=0;y<4;y++)for(int x=0;x<4;x++){int c=col.getPixel(x,y);rr+=Color.red(c);gg+=Color.green(c);bb+=Color.blue(c);}
            p.r=(int)(rr/16);p.g=(int)(gg/16);p.b=(int)(bb/16);p.featured=true;
            small.recycle();col.recycle();src.recycle();
        }catch(Exception e){p.featured=false;}
    }
    private int ham(long a,long b){return Long.bitCount(a^b);}
    private int colorDist(Photo a,Photo b){return Math.abs(a.r-b.r)+Math.abs(a.g-b.g)+Math.abs(a.b-b.b);}
    private boolean aspectNear(Photo a,Photo b){double x=a.aspect(),y=b.aspect();return Math.abs(Math.log(x/y))<0.22;}
    private boolean similar(Photo a,Photo b,int threshold){
        return a.featured&&b.featured&&aspectNear(a,b)&&ham(a.hash,b.hash)<=threshold&&colorDist(a,b)<=125;
    }

    private ArrayList<Cluster> cluster(ArrayList<Photo> a){
        // Hybrid high-leverage clustering:
        // 1) temporal neighbours: aggressive similarity threshold
        // 2) global LSH buckets: visually alike images even far apart in time
        // 3) hard cap: giant components are split into visually tighter chunks
        int n=a.size();DSU d=new DSU(n);
        a.sort(Comparator.comparingLong(x->x.taken));
        for(int i=0;i<n;i++){
            Photo x=a.get(i);
            for(int j=i+1;j<n&&j<i+45;j++){
                Photo y=a.get(j);long gap=Math.abs(y.taken-x.taken);
                if(x.taken>0&&y.taken>0&&gap>30*60*1000L)break;
                if(similar(x,y,22))d.u(i,j);
            }
        }
        HashMap<Integer,ArrayList<Integer>> buckets=new HashMap<>();
        for(int i=0;i<n;i++)if(a.get(i).featured){
            Photo p=a.get(i);
            int orient=p.w>=p.h?1:0;
            int key=(int)((p.hash>>>52)&0xfff) | (orient<<12);
            ArrayList<Integer> list=buckets.computeIfAbsent(key,k->new ArrayList<>());
            int start=Math.max(0,list.size()-80);
            for(int z=start;z<list.size();z++){int j=list.get(z);if(similar(p,a.get(j),13))d.u(i,j);}
            list.add(i);
        }
        LinkedHashMap<Integer,ArrayList<Photo>> groups=new LinkedHashMap<>();
        for(int i=0;i<n;i++)groups.computeIfAbsent(d.f(i),k->new ArrayList<>()).add(a.get(i));
        ArrayList<Cluster> out=new ArrayList<>();Random rnd=new Random();
        for(ArrayList<Photo> g:groups.values()){
            if(g.size()<=120){Cluster c=new Cluster();c.items.addAll(g);c.sample=g.get(rnd.nextInt(g.size()));out.add(c);}
            else{
                // Giant clusters are split chronologically into <=80 to prevent "everything in one cluster".
                g.sort(Comparator.comparingLong(x->x.taken));
                for(int s=0;s<g.size();s+=80){Cluster c=new Cluster();c.items.addAll(g.subList(s,Math.min(s+80,g.size())));c.sample=c.items.get(rnd.nextInt(c.items.size()));out.add(c);}
            }
        }
        // High leverage first, singletons last.
        out.sort((x,y)->Integer.compare(y.items.size(),x.items.size()));
        return out;
    }

    private void showCluster(){
        resetBody();title.setText("3. 랜덤 이미지만 확인");
        if(clusters.isEmpty()||clusterIndex>=clusters.size()){subtitle.setText("모든 군집을 확인했습니다.");Button b=btn("처음으로");b.setOnClickListener(v->showProtectScreen());root.addView(b);return;}
        Cluster c=clusters.get(clusterIndex);subtitle.setText((clusterIndex+1)+"/"+clusters.size()+" · 이 이미지와 함께 묶인 "+c.items.size()+"장");
        ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);image.setBackgroundColor(0xffeeeeee);image.setPadding(dp(8),dp(8),dp(8),dp(8));
        root.addView(image,new LinearLayout.LayoutParams(-1,0,1));loadThumb(c.sample.uri,image,1200);
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setPadding(dp(8),dp(6),dp(8),dp(6));
        Button skip=btn("유지 / 다음");Button trash=btn("군집 휴지통 ("+c.items.size()+")");
        actions.addView(skip,new LinearLayout.LayoutParams(0,dp(72),1));actions.addView(trash,new LinearLayout.LayoutParams(0,dp(72),1));root.addView(actions,new LinearLayout.LayoutParams(-1,dp(84)));
        skip.setOnClickListener(v->{clusterIndex++;showCluster();});trash.setOnClickListener(v->trashCluster(c));
    }
    private void trashCluster(Cluster c){
        ArrayList<Uri> u=new ArrayList<>();for(Photo p:c.items)u.add(p.uri);
        if(u.size()>1900)u=new ArrayList<>(u.subList(0,1900));
        PendingIntent pi=MediaStore.createTrashRequest(getContentResolver(),u,true);
        try{startIntentSenderForResult(pi.getIntentSender(),TRASH,null,0,0,0);}catch(Exception e){Toast.makeText(this,"휴지통 요청 실패",Toast.LENGTH_SHORT).show();}
    }
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==TRASH){if(result==RESULT_OK)Toast.makeText(this,"휴지통으로 이동",Toast.LENGTH_SHORT).show();clusterIndex++;showCluster();}}
    private void loadThumb(Uri uri,ImageView target,int size){pool.submit(()->{try{Bitmap b=getContentResolver().loadThumbnail(uri,new android.util.Size(size,size),null);runOnUiThread(()->target.setImageBitmap(b));}catch(IOException ignored){}});}

    class PhotoAdapter extends BaseAdapter{
        ArrayList<Photo>d;HashSet<Long>s;PhotoAdapter(ArrayList<Photo>d,HashSet<Long>s){this.d=d;this.s=s;}
        public int getCount(){return d.size();}public Object getItem(int p){return d.get(p);}public long getItemId(int p){return d.get(p).id;}
        public View getView(int p,View cv,ViewGroup parent){FrameLayout box;ImageView im;if(cv==null){box=new FrameLayout(MainActivity.this);im=new ImageView(MainActivity.this);im.setId(100);im.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(im,new FrameLayout.LayoutParams(-1,dp(96)));cv=box;}else{box=(FrameLayout)cv;im=box.findViewById(100);}Photo ph=d.get(p);im.setImageDrawable(new ColorDrawable(0xffdddddd));loadThumb(ph.uri,im,256);box.setForeground(new ColorDrawable(s.contains(ph.id)?0x6633aa55:0));return cv;}
    }
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
