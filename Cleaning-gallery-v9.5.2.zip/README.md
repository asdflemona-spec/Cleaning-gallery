# Cleaning Gallery v9.5

Incremental persistent classification:
- Photo cache keyed by MediaStore ID.
- Cache validity checks DATE_MODIFIED + SIZE.
- Unchanged photos restore saved score, grade and stable cluster ID.
- New/modified photos alone run feature extraction.
- New/modified photos attach to the nearest existing cluster when within the existing threshold; otherwise a new cluster is created.
- Existing grades/clusters are not globally reshuffled on app restart.
- Protected IDs persist locally.
- Existing grade-folder → cluster-folder → grid UI and Galaxy Gallery folder export remain.

Android recommends resyncing cached MediaStore data when the media collection changes. v9.5 additionally checks per-photo modification metadata so unchanged items can reuse classification.

## v9.5.1 Samsung Gallery export
- Flattened exported cluster directories to `Pictures/CleaningGallery_<GRADE>_<STABLE_CLUSTER_ID>/`.
- Stable cluster IDs from v9.5 are reused, so incremental photos continue targeting the same physical album.
- After `RELATIVE_PATH` update, the app queries MediaStore again and reports both update count and verified-path count.
- A successful `update()` is no longer presented as proof that the requested path is actually stored.

## v9.5.2 selection UX fix
- Normal tap now immediately selects/deselects a photo.
- Multiple photos can be accumulated by repeated taps.
- Long press still enters explicit multi-select mode and selects the pressed photo.
- Selection does not collapse back to single-selection after the first item.
- Updated helper text and empty-selection warning.
