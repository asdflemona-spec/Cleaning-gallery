package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val dark = Color(0xFF0B0B0C)
private val gold = Color(0xFFC2A785)
private val ivory = Color(0xFFEAE2D8)

@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    var page by remember { mutableStateOf("Instagram") }
    var filter by remember { mutableStateOf("All") }
    Column(Modifier.fillMaxSize().background(dark)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("PRIVATE CATALOGUE", color = gold, fontSize = 10.sp, letterSpacing = 2.sp)
                Text("IRIS PRIVÉ", color = ivory, fontFamily = FontFamily.Serif, fontSize = 28.sp)
            }
            Text("◇", color = gold, fontSize = 25.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("Instagram", "TikTok", "Auction", "Recap").forEach { tab ->
                Surface(Modifier.weight(1f).clickable { page = tab }, color = if (page == tab) gold else Color(0xFF2D2025), shape = RoundedCornerShape(8.dp)) {
                    Text(tab, Modifier.padding(vertical = 12.dp), color = if (page == tab) dark else ivory,
                        fontSize = 11.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        }
        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            listOf("All", "Images", "Videos").forEach { f ->
                Text(f, Modifier.clickable { filter = f }.padding(7.dp), color = if (filter == f) gold else ivory, fontSize = 12.sp)
            }
        }
        IrisGallerySection(Modifier.weight(1f).padding(horizontal = 6.dp), category = page, mediaFilter = filter)
    }
}
