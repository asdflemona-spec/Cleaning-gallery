package xyz.quaver.pupil.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Metadata for user-selected images of non-person objects. Stores current values only. */
data class IrisAuctionRecord(
    val uri: String,
    val number: Int,
    val credits: Int = 320,
    val function: String = "",
    val status: String = "",
    val social: String = "",
    val legal: String = ""
)

object IrisAuctionStore {
    private fun prefs(c: Context) = c.getSharedPreferences("iris_auction_catalog_v1", Context.MODE_PRIVATE)

    fun list(c: Context): List<IrisAuctionRecord> {
        val raw = prefs(c).getString("records", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                // Older versions used numeric "score" for information status. Preserve the
                // user's existing information value as editable status text on migration.
                val legacyStatuses = listOf("미등록", "기본 등록", "상세 등록", "지속 감시", "기록 말소")
                val status = if (o.has("status")) o.optString("status", "")
                    else legacyStatuses.getOrElse(o.optInt("score", 0)) { "" }
                IrisAuctionRecord(
                    uri = o.getString("uri"),
                    number = o.getInt("number"),
                    credits = o.optInt("credits", 320),
                    function = o.optString("function", ""),
                    status = status,
                    social = o.optString("social", ""),
                    legal = o.optString("legal", "")
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun save(c: Context, items: List<IrisAuctionRecord>) {
        val array = JSONArray()
        items.forEach { r ->
            array.put(JSONObject()
                .put("uri", r.uri).put("number", r.number).put("credits", r.credits)
                .put("function", r.function).put("status", r.status)
                .put("social", r.social).put("legal", r.legal))
        }
        prefs(c).edit().putString("records", array.toString()).apply()
    }

    fun toggle(c: Context, uri: String): Boolean {
        val items = list(c).toMutableList()
        val existing = items.indexOfFirst { it.uri == uri }
        if (existing >= 0) {
            items.removeAt(existing)
            save(c, items)
            return false
        }
        val next = (items.maxOfOrNull { it.number } ?: 0) + 1
        items.add(IrisAuctionRecord(uri = uri, number = next))
        save(c, items)
        return true
    }

    fun update(c: Context, record: IrisAuctionRecord) {
        save(c, list(c).map { if (it.uri == record.uri) record else it })
    }

    fun contains(c: Context, uri: String): Boolean = list(c).any { it.uri == uri }
}
