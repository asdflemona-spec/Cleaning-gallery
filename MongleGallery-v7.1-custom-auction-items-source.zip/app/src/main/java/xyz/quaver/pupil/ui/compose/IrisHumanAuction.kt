package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisAuctionRecord
import xyz.quaver.pupil.util.IrisAuctionStore

/** Local-gallery ♥ selections are the catalogue objects; no historical analysis tabs or logs. */
@Composable
fun IrisHumanAuction(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var records by remember { mutableStateOf(IrisAuctionStore.list(context)) }
    var editing by remember { mutableStateOf<IrisAuctionRecord?>(null) }

    Column(modifier) {
        Text("경매 물품", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp))
        if (records.isEmpty()) {
            Text("경매 물품이 없습니다. 갤러리에서 ♥를 선택하세요.", modifier = Modifier.padding(16.dp))
        }
        LazyColumn(contentPadding = PaddingValues(8.dp)) {
            items(records, key = { it.uri }) { record ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { editing = record }) {
                    Row(Modifier.padding(12.dp)) {
                        AsyncImage(model = record.uri, contentDescription = "경매 물품 이미지", modifier = Modifier.size(100.dp))
                        Column(Modifier.padding(start = 12.dp)) {
                            Text("H-${record.number.toString().padStart(3, '0')}", style = MaterialTheme.typography.titleMedium)
                            Text("경제적 · ${record.credits} 크레딧")
                            Text("기능적 · ${record.function}")
                            Text("상태적 · ${record.status}")
                            Text("사회적 · ${record.social}")
                            Text("법적 · ${record.legal}")
                        }
                    }
                }
            }
        }
    }
    editing?.let { initial ->
        var credits by remember(initial.uri) { mutableStateOf(initial.credits.toString()) }
        var function by remember(initial.uri) { mutableStateOf(initial.function) }
        var status by remember(initial.uri) { mutableStateOf(initial.status) }
        var social by remember(initial.uri) { mutableStateOf(initial.social) }
        var legal by remember(initial.uri) { mutableStateOf(initial.legal) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("H-${initial.number.toString().padStart(3, '0')} 속성 직접 편집") },
            text = {
                Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                    OutlinedTextField(credits, { credits = it.filter(Char::isDigit).take(8) }, label = { Text("경제적 속성 · 크레딧") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(function, { function = it }, label = { Text("기능적 속성") }, minLines = 1)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(status, { status = it }, label = { Text("상태적 속성") }, minLines = 1)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(social, { social = it }, label = { Text("사회적 속성") }, minLines = 1)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(legal, { legal = it }, label = { Text("법적 속성") }, minLines = 1)
                    Spacer(Modifier.height(8.dp))
                    Text("네 가지 속성은 정해진 선택지 없이 자유롭게 작성하고 수정할 수 있습니다.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    IrisAuctionStore.update(context, initial.copy(
                        credits = credits.toIntOrNull() ?: 0,
                        function = function,
                        status = status,
                        social = social,
                        legal = legal
                    ))
                    records = IrisAuctionStore.list(context)
                    editing = null
                }) { Text("저장") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("취소") } }
        )
    }
}
