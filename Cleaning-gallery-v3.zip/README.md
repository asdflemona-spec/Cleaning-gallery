# Cleaning Gallery v3

High-purity clustering for random-representative review.

- ML Kit 33-landmark pose detection (selected body landmarks normalized into geometry)
- perceptual dHash
- RGB distribution histogram
- composition/aspect and edge-density features
- capture-time weak prior
- confidence-adaptive pose weighting
- complete-link-like conservative admission: a new image must be close to every current cluster member
- medoid purity gate and outlier rejection
- Random Representative Reliability (RRR)
- clusters sorted by size × purity × RRR
- no arbitrary maximum cluster size
- Android system trash via MediaStore.createTrashRequest

The clustering intentionally prefers false splits over false merges because the UI makes a whole-cluster decision from one random representative.
