package com.cleaninggallery.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;

import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarker;
import com.google.mediapipe.tasks.vision.poselandmarker.PoseLandmarkerResult;

import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    static final int PERM=10, TRASH=20, CHECKPOINT=100;
    final ExecutorService worker=Executors.newSingleThreadExecutor();
    final ArrayList<Photo> photos=new ArrayList<>();
    final ArrayList<Group> groups=new ArrayList<>();
    final HashSet<Long> selected=new HashSet<>();
    SharedPreferences cache;
    LinearLayout root; TextView status; ProgressBar progress;
    PoseLandmarker pose;
    int nextGroup=1;

    static class Photo {
        long id, modified, size; Uri uri; int group; String grade="U"; double score=50;
        float[] body=new float[4]; int mask; long hash;
    }
    static class Group { int id; String grade; Photo rep; ArrayList<Photo> items=new ArrayList<>(); }

    @Override public void onCreate(Bundle b){ super.onCreate(b); cache=getSharedPreferences("v201",0); buildUi(); initAi(); requestAccess(); }
    void buildUi(){ ScrollView s=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24); s.addView(root); setContentView(s);
        TextView h=new TextView(this); h.setText("Gallery Cleaner v2.0.1"); h.setTextSize(26); root.addView(h);
        status=new TextView(this); status.setText("준비 중"); root.addView(status);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); root.addView(progress,new LinearLayout.LayoutParams(-1,44));
        Button scan=new Button(this); scan.setText("새 사진 확인"); scan.setOnClickListener(v->scan()); root.addView(scan);
        Button trash=new Button(this); trash.setText("선택 사진 → 휴지통"); trash.setOnClickListener(v->trash()); root.addView(trash); }
    void initAi(){ try { BaseOptions base=BaseOptions.builder().setModelAssetPath("pose_landmarker_lite.task").build();
        PoseLandmarker.PoseLandmarkerOptions opts=PoseLandmarker.PoseLandmarkerOptions.builder().setBaseOptions(base).setRunningMode(RunningMode.IMAGE).setNumPoses(1).build();
        pose=PoseLandmarker.createFromOptions(this,opts); status.setText("온디바이스 AI 준비 완료");
    } catch(Exception e){ status.setText("AI 초기화 실패: "+e.getClass().getSimpleName()); } }
    void requestAccess(){ String p=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_EXTERNAL_STORAGE; if(checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED) scan(); else requestPermissions(new String[]{p},PERM); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==PERM&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED) scan(); }

    void scan(){ if(pose==null){status.setText("AI 모델을 사용할 수 없습니다");return;} worker.submit(()->{
        ArrayList<Photo> all=query(), changed=new ArrayList<>(); photos.clear(); groups.clear(); nextGroup=1;
        for(Photo p:all){ if(restore(p)) restoreGroup(p); else changed.add(p); photos.add(p); }
        final int total=changed.size(); runOnUiThread(()->{progress.setMax(Math.max(1,total));progress.setProgress(0);status.setText("신규/변경 "+total+"장");});
        SharedPreferences.Editor ed=cache.edit(); int done=0;
        for(Photo p:changed){ try{ infer(p); attach(p); }catch(Exception e){p.grade="U";} save(ed,p); done++;
            if(done%CHECKPOINT==0){ ed.commit(); ed=cache.edit(); }
            final int d=done; if(d%5==0||d==total) runOnUiThread(()->{progress.setProgress(d);status.setText(d+" / "+total+" 처리");}); }
        ed.commit(); runOnUiThread(this::render);
    }); }
    ArrayList<Photo> query(){ ArrayList<Photo>a=new ArrayList<>(); String[] pr={MediaStore.Images.Media._ID,MediaStore.Images.Media.DATE_MODIFIED,MediaStore.Images.Media.SIZE};
        try(Cursor c=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,pr,null,null,MediaStore.Images.Media.DATE_ADDED+" DESC")){ if(c!=null)while(c.moveToNext()){Photo p=new Photo();p.id=c.getLong(0);p.modified=c.getLong(1);p.size=c.getLong(2);p.uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(p.id));a.add(p);} } catch(Exception ignored){} return a; }
    void infer(Photo p)throws Exception { Bitmap b=getContentResolver().loadThumbnail(p.uri,new android.util.Size(512,512),null); p.hash=dHash(b); MPImage img=new BitmapImageBuilder(b).build(); PoseLandmarkerResult r=pose.detect(img); readPose(r,p); p.score=fixedScore(p); p.grade=fixedGrade(p); b.recycle(); }
    void readPose(PoseLandmarkerResult r,Photo p){ p.mask=0; if(r.landmarks().isEmpty())return; List<NormalizedLandmark> l=r.landmarks().get(0); if(l.size()<25)return;
        NormalizedLandmark ls=l.get(11),rs=l.get(12),lh=l.get(23),rh=l.get(24); if(vis(ls)&&vis(rs)){p.mask|=1;p.body[0]=dist(ls,rs);} if(vis(lh)&&vis(rh)){p.mask|=2;p.body[1]=dist(lh,rh);} if((p.mask&3)==3){p.body[2]=p.body[0]/Math.max(.01f,p.body[1]);p.body[3]=Math.abs((ls.y()+rs.y())*.5f-(lh.y()+rh.y())*.5f);} }
    boolean vis(NormalizedLandmark x){ return x.visibility().orElse(0f)>=.55f; }
    float dist(NormalizedLandmark a,NormalizedLandmark b){ return(float)Math.hypot(a.x()-b.x(),a.y()-b.y()); }
    double bell(double x,double c,double w){double z=(x-c)/w;return Math.exp(-z*z);}
    double fixedScore(Photo p){ double s=0,w=0; if((p.mask&1)!=0){s+=.22*bell(p.body[0],.32,.18);w+=.22;} if((p.mask&2)!=0){s+=.22*bell(p.body[1],.30,.18);w+=.22;} if((p.mask&3)==3){s+=.40*bell(p.body[2],1.02,.38)+.16*bell(p.body[3],.30,.18);w+=.56;} return w<.2?50:100*Math.max(0,Math.min(1,s/w)); }
    String fixedGrade(Photo p){ if(p.mask==0)return"U";double s=p.score;if(s>=78)return"S";if(s>=68)return"A";if(s>=57)return"B";if(s>=46)return"C";return"D"; }
    long dHash(Bitmap src){ Bitmap b=Bitmap.createScaledBitmap(src,9,8,true); long h=0;int k=0;for(int y=0;y<8;y++)for(int x=0;x<8;x++){int a=b.getPixel(x,y),c=b.getPixel(x+1,y);int ga=((a>>16)&255)*3+((a>>8)&255)*6+(a&255);int gc=((c>>16)&255)*3+((c>>8)&255)*6+(c&255);if(ga>gc)h|=1L<<k;k++;}if(b!=src)b.recycle();return h; }
    double sim(Photo a,Photo b){ return 1.0-Long.bitCount(a.hash^b.hash)/64.0; }
    void attach(Photo p){ if("U".equals(p.grade)){p.group=0;return;} Group best=null;double bs=.76;for(Group g:groups)if(g.grade.equals(p.grade)){double s=sim(p,g.rep);if(s>bs){bs=s;best=g;}} if(best==null){best=new Group();best.id=nextGroup++;best.grade=p.grade;best.rep=p;groups.add(best);}p.group=best.id;best.items.add(p); }
    void restoreGroup(Photo p){if(p.group<=0||"U".equals(p.grade))return;Group g=null;for(Group x:groups)if(x.id==p.group)g=x;if(g==null){g=new Group();g.id=p.group;g.grade=p.grade;g.rep=p;groups.add(g);}g.items.add(p);nextGroup=Math.max(nextGroup,p.group+1);}
    String enc(float[]a){StringBuilder s=new StringBuilder();for(float x:a){if(s.length()>0)s.append(',');s.append(x);}return s.toString();}
    float[] dec(String s){String[]q=s.split(",");float[]a=new float[q.length];for(int i=0;i<a.length;i++)a[i]=Float.parseFloat(q[i]);return a;}
    void save(SharedPreferences.Editor e,Photo p){e.putString("p"+p.id,p.modified+"|"+p.size+"|"+p.grade+"|"+p.score+"|"+p.group+"|"+p.mask+"|"+p.hash+"|"+enc(p.body));}
    boolean restore(Photo p){String x=cache.getString("p"+p.id,null);if(x==null)return false;try{String[]z=x.split("\\|",-1);if(Long.parseLong(z[0])!=p.modified||Long.parseLong(z[1])!=p.size)return false;p.grade=z[2];p.score=Double.parseDouble(z[3]);p.group=Integer.parseInt(z[4]);p.mask=Integer.parseInt(z[5]);p.hash=Long.parseLong(z[6]);p.body=dec(z[7]);return true;}catch(Exception e){return false;}}
    String label(Group g){return g.grade+"-"+String.format(Locale.US,"%03d",g.id);}
    void render(){while(root.getChildCount()>4)root.removeViewAt(4);status.setText("사진 "+photos.size()+"장 · 그룹 "+groups.size()+"개");for(Group g:groups){Button b=new Button(this);b.setText(label(g)+" · "+g.items.size()+"장");b.setOnClickListener(v->show(g));root.addView(b);}}
    void show(Group g){Dialog d=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(box);for(Photo p:g.items){CheckBox c=new CheckBox(this);c.setText("사진 #"+p.id);c.setChecked(selected.contains(p.id));c.setOnCheckedChangeListener((v,on)->{if(on)selected.add(p.id);else selected.remove(p.id);});box.addView(c);}d.setContentView(sv);d.show();}
    void trash(){ArrayList<Uri>u=new ArrayList<>();for(Photo p:photos)if(selected.contains(p.id))u.add(p.uri);if(u.isEmpty())return;if(u.size()>1900){Toast.makeText(this,"1900장 이하로 선택하세요",Toast.LENGTH_LONG).show();return;}try{PendingIntent pi=MediaStore.createTrashRequest(getContentResolver(),u,true);startIntentSenderForResult(pi.getIntentSender(),TRASH,null,0,0,0);}catch(Exception ignored){}}
    @Override protected void onActivityResult(int r,int c,Intent i){super.onActivityResult(r,c,i);if(r==TRASH&&c==RESULT_OK){SharedPreferences.Editor e=cache.edit();for(long id:selected)e.remove("p"+id);e.apply();selected.clear();scan();}}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdownNow();if(pose!=null)pose.close();}
}
