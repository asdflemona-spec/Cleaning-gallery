# Gallery Cleaner v2.0.1
- MediaPipe Pose Landmarker only; all legacy ML Kit imports removed.
- Official pose_landmarker_lite model is downloaded automatically by Gradle preBuild and packaged into assets.
- Incremental processing: unchanged photos restore cached grade/group/hash/body features.
- 100-photo durable cache checkpoints; inference runs on a bounded background worker.
- Cropped/partial photos use only visible shoulder/hip evidence; no missing-part zero penalty.
- Fixed absolute S/A/B/C/D thresholds; U = insufficient visible pose evidence.
- Same-grade grouping uses cached perceptual image similarity so old photos do not need AI re-inference.
