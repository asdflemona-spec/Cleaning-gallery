package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().background(Color(0xFF100D13))) {
        Text("IrisGallery", fontSize=34.sp,fontWeight=FontWeight.Light,
            color=Color(0xFFFFE2EB), modifier=Modifier.padding(start=18.dp,top=18.dp))
        Text("THE AESTHETIC OF ALLURE  ·  PRIVATE LIBRARY",fontSize=10.sp,
            color=Color(0xFFD5A2B7),modifier=Modifier.padding(start=18.dp,bottom=12.dp))
        IrisGallerySection(Modifier.weight(1f))
    }
}
