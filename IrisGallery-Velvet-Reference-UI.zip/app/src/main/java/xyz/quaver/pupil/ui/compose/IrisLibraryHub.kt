package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import xyz.quaver.pupil.R

@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    var category by remember { mutableStateOf("TikTok") }
    var filter by remember { mutableStateOf("All") }
    val rose = Color(0xFFF0A6C3)
    Column(Modifier.fillMaxSize().background(Color(0xFF100D13)).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("IrisGallery", color = Color(0xFFFFE5EF), fontSize = 32.sp, fontFamily = FontFamily.Serif)
            Text("✧", color = rose, fontSize = 26.sp)
        }
        Text("THE AESTHETIC OF ALLURE · PRIVATE LIBRARY", color = Color(0xFFB995A8), fontSize = 10.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(20.dp))
        Image(painterResource(R.drawable.iris_velvet_hero), contentDescription = "IrisGallery editorial cover", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(190.dp).border(1.dp, Color(0xFF654052), RoundedCornerShape(20.dp)))
        Spacer(Modifier.height(20.dp))
        Text("My Private Gallery", color = Color(0xFFFFDCE9), fontSize = 25.sp, fontFamily = FontFamily.Serif)
        Text("시선이 머무는 곳, 그곳이 갤러리.", color = Color(0xFFC4A8B5), fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("TikTok", "Instagram", "Recap").forEach { name ->
                val active = category == name
                Surface(modifier = Modifier.weight(1f).clickable { category = name; filter = "All" }, color = if(active) Color(0xFF633246) else Color(0xFF241A23), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, if(active) rose else Color(0xFF40303C))) {
                    Column(Modifier.padding(vertical = 15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(when(name) {"TikTok" -> "♪"; "Instagram" -> "◎"; else -> "♛"}, color = rose, fontSize = 24.sp)
                        Text(name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val filters = when(category) {"TikTok" -> listOf("All", "Videos", "Images"); "Instagram" -> listOf("All", "Posts", "Reels"); else -> listOf("All", "Favorites", "Recent")}
            filters.forEach { item ->
                Surface(color = if(filter == item) rose else Color(0xFF2A222B), shape = RoundedCornerShape(10.dp), modifier = Modifier.clickable { filter = item }) {
                    Text(item, modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp), color = if(filter == item) Color(0xFF28121F) else Color(0xFFE3CCD8), fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("$category · $filter", color = rose, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Text("저장된 콘텐츠는 아래 라이브러리에서 확인하세요.", color = Color(0xFFAD94A2), fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        IrisGallerySection(Modifier.fillMaxWidth())
    }
}
