package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

enum class IrisLibrarySource { GALLERY }

@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("Library", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(16.dp))
        var auction by remember { mutableStateOf(false) }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            FilterChip(!auction, { auction = false }, label = { Text("Gallery") })
            Spacer(Modifier.width(8.dp))
            FilterChip(auction, { auction = true }, label = { Text("인간 경매") })
        }
        if (auction) IrisHumanAuction(Modifier.weight(1f)) else IrisGallerySection(Modifier.weight(1f))
    }
}

