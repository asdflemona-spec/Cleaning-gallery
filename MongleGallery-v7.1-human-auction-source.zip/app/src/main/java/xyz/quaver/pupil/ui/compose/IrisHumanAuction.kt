package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisAuctionRecord
import xyz.quaver.pupil.util.IrisAuctionStore

@Composable
fun IrisHumanAuction(modifier:Modifier=Modifier){
    val context=LocalContext.current
    var records by remember { mutableStateOf(IrisAuctionStore.list(context)) }
    var editing by remember { mutableStateOf<IrisAuctionRecord?>(null) }
    Column(modifier){
        Text("인간 경매 · 가상 사진 카탈로그",style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(16.dp))
        Text("실제 인물의 거래·법적 지위를 나타내지 않는 사용자 지정 분류입니다.",modifier=Modifier.padding(horizontal=16.dp))
        LazyColumn { items(records,key={it.uri}) { r ->
            Card(Modifier.fillMaxWidth().padding(8.dp).clickable { editing=r }) {
                Row(Modifier.padding(12.dp)) {
                    AsyncImage(model=r.uri,contentDescription="추천 사진",modifier=Modifier.size(100.dp))
                    Column(Modifier.padding(start=12.dp)) {
                        Text("H-${r.number.toString().padStart(3,'0')}",style=MaterialTheme.typography.titleMedium)
                        Text("경제적 · ${r.credits} 크레딧")
                        Text("기능적 · ${r.function}")
                        Text("정보적 · ${r.score}/100")
                        Text("사회적 · ${r.social}")
                        Text("법적 · ${r.legal}")
                    }
                }
            }
        } }
    }
    editing?.let { initial ->
        var credits by remember(initial.uri) { mutableStateOf(initial.credits.toString()) }
        var function by remember(initial.uri) { mutableStateOf(initial.function) }
        var score by remember(initial.uri) { mutableFloatStateOf(initial.score.toFloat()) }
        var social by remember(initial.uri) { mutableStateOf(initial.social) }
        var legal by remember(initial.uri) { mutableStateOf(initial.legal) }
        AlertDialog(onDismissRequest={editing=null},title={Text("H-${initial.number.toString().padStart(3,'0')} 속성 편집")},text={
            Column {
                Text("경제적 속성 (가상 크레딧)")
                OutlinedTextField(credits,{credits=it.filter(Char::isDigit).take(8)},label={Text("크레딧")},singleLine=true)
                Text("기능적 속성")
                AttributeSelector(function,listOf("일반 작업형","창작형","분석형","지원형","기타")){function=it}
                Text("정보적 속성 · ${score.toInt()}/100")
                Slider(score,{score=it},valueRange=0f..100f)
                Text("사회적 속성")
                AttributeSelector(social,(1..5).map { "제${it}등급" }){social=it}
                Text("법적 속성 (가상 세계관 설정)")
                AttributeSelector(legal,listOf("독립적 인격 불인정","가상 자율 객체","가상 등록 객체","미분류")){legal=it}
            }
        },confirmButton={TextButton(onClick={
            IrisAuctionStore.update(context,initial.copy(credits=credits.toIntOrNull()?:0,function=function,score=score.toInt(),social=social,legal=legal))
            records=IrisAuctionStore.list(context);editing=null
        }){Text("저장")}},dismissButton={TextButton(onClick={editing=null}){Text("취소")}})
    }
}

@Composable private fun AttributeSelector(value:String,choices:List<String>,onChange:(String)->Unit){
    var expanded by remember { mutableStateOf(false) }
    Box { TextButton(onClick={expanded=true}){Text("$value ▾")}
        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
            choices.forEach { option -> DropdownMenuItem(text={Text(option)},onClick={onChange(option);expanded=false}) }
        }
    }
}
