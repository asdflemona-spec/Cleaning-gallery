# Gallery Cleaner v10.1 — Research architecture

Goal: automatically rank and clean a large gallery while keeping separate evidence channels instead of pretending one formula is universal beauty.

## Evidence layers
1. Technical: resolution, byte size, bytes/pixel, decode success, edge/sharpness proxy, aspect ratio.
2. View/visibility: pose confidence and explicit visibility mask. Missing body regions are UNKNOWN, never bad.
3. Human geometry: only when the required landmarks/contours are visible; shoulder/pelvis/torso contour ratios and pose geometry.
4. General visual representation: MobileNet embedding + histogram + dHash for relative grouping, not as a claim of beauty.
5. Relative aesthetics: ranking is relative inside the scanned collection. S/A/B/C/D are experimental retention ranks, not objective statements about a person.
6. Objective cleaners: exact/near duplicate and technically dominated-copy cleaners are the next independent deletion channel.

## View taxonomy roadmap
FULL_BODY_FRONT, FULL_BODY_SIDE, FULL_BODY_BACK, UPPER_BODY, LOWER_BODY, FACE_UPPER, PARTIAL, SEATED, LYING, OCCLUDED, STRONG_PERSPECTIVE, UNKNOWN.

## Evaluator contract
Each future evaluator should output: name, applicability, confidence, attributes, scalar/ranking evidence, explanation. Evaluators must be replaceable and their raw outputs retained so failed methods can be compared instead of silently overwriting previous evidence.

## Learning loop
scan -> evaluate -> disagreement set -> failure taxonomy -> evaluator experiment -> validation -> retain/reject -> rescan changed/new photos only.

## Safety of deletion
The app never permanently deletes directly. Android MediaStore createTrashRequest is used, so the OS confirmation is the final boundary. Protected IDs remain excluded from analysis/deletion.

## Current implementation inherited from v9.8.4
MediaPipe Pose Landmarker Full, MobileNet V3 Large Image Embedder, pixel histogram, dHash, contour geometry, partial-body visibility masking, incremental cache, relative grades, stable clusters, protection, normal-tap multiselect, Select All, MediaStore trash, Samsung Gallery RELATIVE_PATH album application.

## Important limitation
v10.1 is an experimental baseline, not a solved universal beauty model. The purpose of this branch is to preserve measurements and failure cases so subsequent evaluators can be tested against the same gallery instead of replacing the methodology blindly.
