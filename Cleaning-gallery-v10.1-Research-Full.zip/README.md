# Cleaning Gallery v10.1 Research

Complete Android Java project. The app automatically begins analysis after media permission; per-photo manual labeling is not required for the normal path. Existing protected IDs are respected.

The current research baseline separates visible-body evidence from missing information, combines pose/contour measurements with general visual embeddings for relative grouping, and keeps Android system Trash as the deletion boundary.

See `RESEARCH_ARCHITECTURE.md` for the evaluator roadmap and limitations.

Build: JDK 17, Gradle 8.9, AGP 8.7.3, compile/target SDK 35, min SDK 30. GitHub Actions downloads the two MediaPipe model assets and builds `:app:assembleDebug`.
