package xyz.quaver.pupil.ui.compose

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import xyz.quaver.pupil.util.IrisGalleryMedia

private val ink = Color(0xFF100A0C)
private val gilt = Color(0xFFD0AC83)
private val ivory = Color(0xFFF3E7DE)
private val plum = Color(0xFF301922)
private val muted = Color(0xFFAE9295)
private data class Lot(val uri: String, val name: String, val price: String, val description: String, val source: String)

@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("iris_prive_auction", 0) }
    var tab by remember { mutableStateOf("Discover") }
    var source by remember { mutableStateOf(prefs.getString("source", "Instagram") ?: "Instagram") }
    var kind by remember { mutableStateOf("All") }
    var picked by remember { mutableStateOf<IrisGalleryMedia?>(null) }
    var title by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var owned by remember { mutableStateOf(false) }
    fun readLots(): List<Lot> = runCatching {
        val json = JSONArray(prefs.getString("lots", "[]") ?: "[]")
        (0 until json.length()).map { i -> json.getJSONObject(i).let { Lot(it.getString("uri"), it.getString("name"), it.getString("price"), it.getString("description"), it.getString("source")) } }
    }.getOrDefault(emptyList())
    var lots by remember { mutableStateOf(readLots()) }
    fun saveLots(value: List<Lot>) {
        lots = value
        val arr = JSONArray()
        value.forEach { arr.put(JSONObject().put("uri", it.uri).put("name", it.name).put("price", it.price).put("description", it.description).put("source", it.source)) }
        prefs.edit().putString("lots", arr.toString()).apply()
    }
    Column(Modifier.fillMaxSize().background(ink)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("PRIVATE MEDIA MARKET · LOCAL DEMO", color = gilt, fontSize = 9.sp, letterSpacing = 1.sp)
                Text("IRIS PRIVÉ", color = ivory, fontSize = 28.sp, fontFamily = FontFamily.Serif)
            }
            Text("◈", color = gilt, fontSize = 25.sp)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Discover", "Auction", "My Listings").forEach { item ->
                Surface(Modifier.weight(1f).clickable { tab = item; picked = null }, color = if (tab == item) gilt else plum, shape = RoundedCornerShape(9.dp)) {
                    Text(item, Modifier.padding(vertical = 12.dp), textAlign = TextAlign.Center, fontSize = 11.sp, color = if (tab == item) ink else ivory)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        if (tab != "My Listings") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Instagram", "X", "Recap").forEach { item ->
                    Surface(Modifier.weight(1f).clickable { source = item; prefs.edit().putString("source", item).apply() }, color = if (source == item) gilt else plum, shape = RoundedCornerShape(8.dp)) {
                        Text(item, Modifier.padding(vertical = 10.dp), textAlign = TextAlign.Center, fontSize = 12.sp, color = if (source == item) ink else ivory)
                    }
                }
            }
            Row(Modifier.padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                listOf("All", "Images", "Videos").forEach { item ->
                    Text(item, Modifier.clickable { kind = item }.padding(vertical = 12.dp), fontSize = 12.sp, color = if (kind == item) gilt else muted)
                }
            }
        }
        when {
            picked != null && tab == "Auction" -> {
                val selected = picked!!
                Column(Modifier.weight(1f).padding(18.dp)) {
                    Text("NEW AUCTION LISTING", color = gilt, fontSize = 12.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(selected.name, color = ivory, fontSize = 15.sp)
                    Spacer(Modifier.height(14.dp))
                    OutlinedTextField(title, { title = it }, label = { Text("Listing title") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(price, { price = it.filter(Char::isDigit).take(12) }, label = { Text("Asking price (KRW)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(description, { description = it }, label = { Text("Description / usage rights") }, modifier = Modifier.fillMaxWidth(), maxLines = 3)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(owned, { owned = it })
                        Text("I own this media or have the rights to sell it.", color = ivory, fontSize = 12.sp)
                    }
                    Button(onClick = {
                        saveLots(lots + Lot(selected.uri, title.trim(), price, description.trim(), source))
                        picked = null; title = ""; price = ""; description = ""; owned = false; tab = "My Listings"
                    }, enabled = owned && title.isNotBlank() && price.toLongOrNull()?.let { it > 0 } == true,
                        colors = ButtonDefaults.buttonColors(containerColor = gilt, contentColor = ink), modifier = Modifier.fillMaxWidth()) { Text("SAVE LOCAL LISTING") }
                    Text("Draft only. No online publication, payment, bidding or buyer messaging is connected.", color = muted, fontSize = 11.sp)
                    TextButton(onClick = { picked = null }) { Text("Cancel") }
                }
            }
            tab == "My Listings" -> {
                LazyColumn(Modifier.weight(1f).padding(horizontal = 15.dp)) {
                    item { Text("MY SALE LISTINGS  ·  ${lots.size}", color = gilt, fontSize = 13.sp) }
                    if (lots.isEmpty()) item { Text("No listings yet. Choose a photo or video from Auction.", Modifier.padding(top = 20.dp), color = muted) }
                    items(lots) { lot ->
                        Surface(Modifier.fillMaxWidth().padding(vertical = 5.dp), color = plum, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, gilt.copy(alpha = .3f))) {
                            Column(Modifier.padding(14.dp)) {
                                Text(lot.name, color = ivory, fontSize = 17.sp)
                                Text("₩${lot.price} · ${lot.source} · LOCAL DRAFT", color = gilt, fontSize = 12.sp)
                                Text(lot.description, color = muted, fontSize = 12.sp)
                                Row {
                                    TextButton(onClick = {
                                        val share = Intent(Intent.ACTION_SEND).apply {
                                            type = "text/plain"
                                            putExtra(Intent.EXTRA_TEXT, "${lot.name}\n₩${lot.price}\n${lot.description}\nContact me for licensing details.")
                                        }
                                        context.startActivity(Intent.createChooser(share, "Share listing details"))
                                    }) { Text("SHARE DETAILS") }
                                    TextButton(onClick = { saveLots(lots.filterNot { it == lot }) }) { Text("DELETE") }
                                }
                            }
                        }
                    }
                }
            }
            else -> IrisGallerySection(Modifier.weight(1f), category = source, mediaFilter = kind,
                onAuctionSelect = if (tab == "Auction") ({ media -> picked = media; title = media.name.substringBeforeLast('.'); price = ""; description = ""; owned = false }) else null)
        }
    }
}
