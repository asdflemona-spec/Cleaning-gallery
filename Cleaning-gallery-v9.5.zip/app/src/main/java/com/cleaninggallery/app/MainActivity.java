package com.cleaninggallery.app;

import android.Manifest; import android.app.*; import android.content.*; import android.content.pm.PackageManager; import android.database.Cursor;
import android.graphics.*; import android.graphics.drawable.ColorDrawable; import android.net.Uri; import android.os.*; import android.provider.MediaStore;
import android.view.*; import android.widget.*;
import com.google.android.gms.tasks.Tasks; import com.google.mlkit.vision.common.InputImage; import com.google.mlkit.vision.pose.*; import com.google.mlkit.vision.pose.defaults.*;
import java.io.IOException; import java.util.*; import java.util.concurrent.*;

public class MainActivity extends Activity {
 static final int PERM=10,TRASH=200, WRITE_ALBUMS=30; final ArrayList<Photo> photos=new ArrayList<>(); final HashSet<Long> protectedIds=new HashSet<>();
 ArrayList<Uri> pendingTrash=new ArrayList<>(); int pendingTrashCount=0;
 ArrayList<Uri> pendingAlbumUris=new ArrayList<>(); final HashMap<String,String> pendingAlbumPaths=new HashMap<>();
 final ArrayList<Cluster> clusters=new ArrayList<>(); int clusterIndex=0; final double[] metricW={.42,.08,.18,.16,.06,.05,.05}; int feedbackCount=0; final HashSet<String> askedPairs=new HashSet<>(); final HashSet<String> mustLinks=new HashSet<>(), cannotLinks=new HashSet<>(); ArrayList<Photo> learningPool=new ArrayList<>(); int activeRound=0;
 // v6 personalized attractiveness-type embedding head. Projection is trained only on TRAIN pairs.
 static final int RAW=7, EMB=16; final double[][] proj=new double[EMB][RAW]; int trainCount=0,valCount=0,valCorrect=0; final ArrayList<Double> learningCurve=new ArrayList<>(); LinearLayout root; TextView title,subtitle;
 final ExecutorService pool=Executors.newFixedThreadPool(Math.max(2,Runtime.getRuntime().availableProcessors()-1)); PoseDetector poseDetector;
 static class Photo { long id,taken,hash,modified,sizeBytes; Uri uri; int w,h; int savedCluster=-1; boolean cached=false; float[] hist=new float[48],pose=new float[24],body=new float[12]; float poseConf=0,bodyConf=0, edge=0; double autoScore=0, shapeScore=50, sizeScore=50, poseScore=50, emphasisScore=50; String grade="D"; boolean featured;
   Photo(long i,long t,Uri u){id=i;taken=t;uri=u;} double aspect(){return h==0?1:(double)w/h;} }
 static class Cluster { ArrayList<Photo> items=new ArrayList<>(); Photo sample; double purity,rrr,score; }
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setNavigationBarColor(Color.WHITE);buildShell();
   poseDetector=PoseDetection.getClient(new PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.SINGLE_IMAGE_MODE).build());loadMetric();requestAccess();}
 int dp(int x){return(int)(x*getResources().getDisplayMetrics().density);} TextView tv(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(0xff111111);v.setPadding(dp(16),dp(8),dp(16),dp(8));return v;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setMinHeight(dp(56));return b;}
 void buildShell(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xfffafafa);root.setFitsSystemWindows(true);root.setPadding(0,dp(6),0,dp(16));title=tv("Cleaning Gallery v9",26);title.setTypeface(null,1);subtitle=tv("사진을 불러오는 중…",15);root.addView(title);root.addView(subtitle);setContentView(root);}
 void requestAccess(){String p=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_EXTERNAL_STORAGE;if(checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED)loadPhotos();else requestPermissions(new String[]{p},PERM);}
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==PERM&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)loadPhotos();else subtitle.setText("사진 접근 권한이 필요합니다.");}
 void loadPhotos(){
   photos.clear();loadProtectedIds();
   String[] pr={MediaStore.Images.Media._ID,MediaStore.Images.Media.DATE_TAKEN,MediaStore.Images.Media.WIDTH,MediaStore.Images.Media.HEIGHT,MediaStore.Images.Media.DATE_MODIFIED,MediaStore.Images.Media.SIZE};
   try(Cursor c=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,pr,null,null,MediaStore.Images.Media.DATE_TAKEN+" DESC")){
     if(c!=null){int ci=c.getColumnIndexOrThrow(pr[0]),ct=c.getColumnIndexOrThrow(pr[1]),cw=c.getColumnIndexOrThrow(pr[2]),ch=c.getColumnIndexOrThrow(pr[3]),cm=c.getColumnIndexOrThrow(pr[4]),cs=c.getColumnIndexOrThrow(pr[5]);
       while(c.moveToNext()){long id=c.getLong(ci);Photo ph=new Photo(id,c.getLong(ct),Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,""+id));ph.w=c.getInt(cw);ph.h=c.getInt(ch);ph.modified=c.getLong(cm);ph.sizeBytes=c.getLong(cs);restorePhotoCache(ph);photos.add(ph);}
     }
   }
   if(hasUsableCache())restoreCachedClassification();else showProtect();
 }
 void loadProtectedIds(){protectedIds.clear();String raw=getSharedPreferences("state_v95",0).getString("protected","");if(!raw.isEmpty())for(String x:raw.split(","))try{protectedIds.add(Long.parseLong(x));}catch(Exception ignored){}}
 void saveProtectedIds(){StringBuilder b=new StringBuilder();for(long id:protectedIds){if(b.length()>0)b.append(",");b.append(id);}getSharedPreferences("state_v95",0).edit().putString("protected",b.toString()).apply();}
 String cacheKey(Photo ph){return "p_"+ph.id;}
 void restorePhotoCache(Photo ph){
   SharedPreferences sp=getSharedPreferences("photo_cache_v95",0);String x=sp.getString(cacheKey(ph),null);if(x==null)return;
   try{String[] z=x.split("\\|",-1);if(z.length<12)return;long mod=Long.parseLong(z[0]),sz=Long.parseLong(z[1]);if(mod!=ph.modified||sz!=ph.sizeBytes)return;
     ph.autoScore=Double.parseDouble(z[2]);ph.shapeScore=Double.parseDouble(z[3]);ph.sizeScore=Double.parseDouble(z[4]);ph.poseScore=Double.parseDouble(z[5]);ph.emphasisScore=Double.parseDouble(z[6]);ph.grade=z[7];ph.savedCluster=Integer.parseInt(z[8]);ph.bodyConf=Float.parseFloat(z[9]);ph.poseConf=Float.parseFloat(z[10]);ph.edge=Float.parseFloat(z[11]);
     if(z.length>12){String[] q=z[12].split(",");for(int i=0;i<Math.min(q.length,ph.body.length);i++)ph.body[i]=Float.parseFloat(q[i]);}
     ph.cached=true;ph.featured=true;
   }catch(Exception ignored){ph.cached=false;}
 }
 void savePhotoCache(Photo ph){
   StringBuilder body=new StringBuilder();for(int i=0;i<ph.body.length;i++){if(i>0)body.append(",");body.append(ph.body[i]);}
   String x=ph.modified+"|"+ph.sizeBytes+"|"+ph.autoScore+"|"+ph.shapeScore+"|"+ph.sizeScore+"|"+ph.poseScore+"|"+ph.emphasisScore+"|"+ph.grade+"|"+ph.savedCluster+"|"+ph.bodyConf+"|"+ph.poseConf+"|"+ph.edge+"|"+body;
   getSharedPreferences("photo_cache_v95",0).edit().putString(cacheKey(ph),x).apply();
 }
 boolean hasUsableCache(){for(Photo ph:photos)if(ph.cached&&!protectedIds.contains(ph.id))return true;return false;}
 void restoreCachedClassification(){
   ArrayList<Photo> eligible=new ArrayList<>(),changed=new ArrayList<>();for(Photo ph:photos)if(!protectedIds.contains(ph.id)){eligible.add(ph);if(!ph.cached)changed.add(ph);}
   if(changed.isEmpty()){rebuildClustersFromSaved(eligible);showGradeFolders();return;}
   analyzeIncremental(eligible,changed);
 }
 void reset(){while(root.getChildCount()>2)root.removeViewAt(2);}
 void showProtect(){reset();title.setText("1. 제거 안 할 사진 선택");subtitle.setText("전체 "+photos.size()+"장 · 탭하면 보호");GridView g=new GridView(this);g.setNumColumns(4);g.setClipToPadding(false);g.setPadding(0,0,0,dp(16));PhotoAdapter a=new PhotoAdapter();g.setAdapter(a);g.setOnItemClickListener((x,v,pos,id)->{long q=photos.get(pos).id;if(!protectedIds.add(q))protectedIds.remove(q);saveProtectedIds();a.notifyDataSetChanged();subtitle.setText("전체 "+photos.size()+" · 보호 "+protectedIds.size());});root.addView(g,new LinearLayout.LayoutParams(-1,0,1));Button n=btn("보호 완료 → 변경분 분석");n.setOnClickListener(v->analyze());root.addView(n,new LinearLayout.LayoutParams(-1,dp(72)));}
 void analyze(){ArrayList<Photo> eligible=new ArrayList<>(),changed=new ArrayList<>();for(Photo ph:photos)if(!protectedIds.contains(ph.id)){eligible.add(ph);if(!ph.cached)changed.add(ph);}if(changed.isEmpty()&&hasUsableCache()){rebuildClustersFromSaved(eligible);showGradeFolders();}else if(hasUsableCache())analyzeIncremental(eligible,changed);else analyzeFull(eligible);}
 void analyzeFull(ArrayList<Photo>w){reset();title.setText("2. 최초 분석");ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(w.size());root.addView(bar,new LinearLayout.LayoutParams(-1,dp(48)));pool.submit(()->{int k=0;for(Photo ph:w){features(ph);ph.autoScore=autoScore(ph);int d=++k;if(d%5==0||d==w.size())runOnUiThread(()->{bar.setProgress(d);subtitle.setText("최초 분석 "+d+" / "+w.size());});}assignRelativeGrades(w);ArrayList<Cluster> out=autoCluster(w);persistClusters(out);runOnUiThread(()->{clusters.clear();clusters.addAll(out);showGradeFolders();});});}
 void analyzeIncremental(ArrayList<Photo> eligible,ArrayList<Photo> changed){reset();title.setText("2. 변경분만 분석");ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(changed.size());root.addView(bar,new LinearLayout.LayoutParams(-1,dp(48)));pool.submit(()->{int k=0;for(Photo ph:changed){features(ph);ph.autoScore=autoScore(ph);int d=++k;runOnUiThread(()->{bar.setProgress(d);subtitle.setText("신규/수정 "+d+" / "+changed.size()+" · 기존 분류 유지");});}rebuildClustersFromSaved(eligible);attachChanged(changed);persistClusters(clusters);runOnUiThread(()->showGradeFolders());});}
 void rebuildClustersFromSaved(ArrayList<Photo> eligible){clusters.clear();TreeMap<Integer,Cluster> map=new TreeMap<>();for(Photo ph:eligible)if(ph.cached&&ph.savedCluster>=0){Cluster c=map.get(ph.savedCluster);if(c==null){c=new Cluster();map.put(ph.savedCluster,c);}c.items.add(ph);}for(Cluster c:map.values()){c.sample=medoid(c.items);c.score=gradeRank(c.sample.grade)*10000+c.items.size();clusters.add(c);}clusters.sort((x,y)->Double.compare(y.score,x.score));}
 void attachChanged(ArrayList<Photo> changed){
   int next=0;for(Photo ph:photos)next=Math.max(next,ph.savedCluster+1);
   for(Photo ph:changed){Cluster best=null;double bd=Double.MAX_VALUE;for(Cluster c:clusters){if(c.sample==null)continue;double d=autoDist(ph,c.sample);if(d<bd){bd=d;best=c;}}
     if(best!=null&&bd<.46){ph.grade=best.sample.grade;ph.savedCluster=best.sample.savedCluster;best.items.add(ph);best.sample=medoid(best.items);}
     else{ph.grade=nearestGrade(ph.autoScore);ph.savedCluster=next++;Cluster c=new Cluster();c.items.add(ph);c.sample=ph;c.score=gradeRank(ph.grade)*10000+1;clusters.add(c);}
     ph.cached=true;
   }
   clusters.sort((x,y)->Double.compare(gradeRank(y.sample.grade)*10000+y.items.size(),gradeRank(x.sample.grade)*10000+x.items.size()));
 }
 String nearestGrade(double score){Photo best=null;double bd=Double.MAX_VALUE;for(Photo ph:photos)if(ph.cached){double d=Math.abs(ph.autoScore-score);if(d<bd){bd=d;best=ph;}}return best==null?gradeFor(score):best.grade;}
 void persistClusters(ArrayList<Cluster> list){int idx=0;for(Cluster c:list){int stable=c.sample!=null&&c.sample.savedCluster>=0?c.sample.savedCluster:idx++;for(Photo ph:c.items){if(ph.savedCluster<0)ph.savedCluster=stable;ph.cached=true;savePhotoCache(ph);}}}
 void features(Photo p){try{Bitmap src=getContentResolver().loadThumbnail(p.uri,new android.util.Size(512,512),null);Bitmap dh=Bitmap.createScaledBitmap(src,9,8,true);long hh=0;int bit=0;for(int y=0;y<8;y++)for(int x=0;x<8;x++){int a=dh.getPixel(x,y),b=dh.getPixel(x+1,y);int la=Color.red(a)*3+Color.green(a)*6+Color.blue(a),lb=Color.red(b)*3+Color.green(b)*6+Color.blue(b);if(la>lb)hh|=1L<<bit++;else bit++;}p.hash=hh;
   Bitmap sm=Bitmap.createScaledBitmap(src,64,64,true);float edges=0;for(int y=0;y<64;y++)for(int x=0;x<64;x++){int c=sm.getPixel(x,y);int[] vs={Color.red(c),Color.green(c),Color.blue(c)};for(int q=0;q<3;q++){int bin=Math.min(15,vs[q]/16);p.hist[q*16+bin]++;}if(x>0){int l=sm.getPixel(x-1,y);edges+=Math.abs(Color.red(c)-Color.red(l))+Math.abs(Color.green(c)-Color.green(l))+Math.abs(Color.blue(c)-Color.blue(l));}}for(int i=0;i<48;i++)p.hist[i]/=4096f;p.edge=edges/(64f*64f*765f);
   try{Pose pose=Tasks.await(poseDetector.process(InputImage.fromBitmap(src,0)),12,TimeUnit.SECONDS);int[] ids={11,12,13,14,15,16,23,24,25,26,27,28};ArrayList<PoseLandmark> ls=new ArrayList<>();for(int id:ids)ls.add(pose.getPoseLandmark(id));PoseLandmark lh=pose.getPoseLandmark(23),rh=pose.getPoseLandmark(24),lsd=pose.getPoseLandmark(11),rsd=pose.getPoseLandmark(12);if(lh!=null&&rh!=null&&lsd!=null&&rsd!=null){float cx=(lh.getPosition().x+rh.getPosition().x+lsd.getPosition().x+rsd.getPosition().x)/4f,cy=(lh.getPosition().y+rh.getPosition().y+lsd.getPosition().y+rsd.getPosition().y)/4f;float scale=Math.max(30f,(float)Math.hypot(lsd.getPosition().x-rsd.getPosition().x,lsd.getPosition().y-rsd.getPosition().y));float conf=0;for(int i=0;i<ls.size();i++){PoseLandmark l=ls.get(i);if(l!=null){p.pose[i*2]=(l.getPosition().x-cx)/scale;p.pose[i*2+1]=(l.getPosition().y-cy)/scale;conf+=l.getInFrameLikelihood();}}p.poseConf=conf/ls.size();
      // v4 rendered-body geometry. Values are continuous, scale-normalized image measurements, not grades.
      float sx1=lsd.getPosition().x, sx2=rsd.getPosition().x, sy=(lsd.getPosition().y+rsd.getPosition().y)/2f;
      float hx1=lh.getPosition().x, hx2=rh.getPosition().x, hy=(lh.getPosition().y+rh.getPosition().y)/2f;
      float torso=Math.max(24f,(float)Math.hypot((sx1+sx2-hx1-hx2)/2f,sy-hy));
      float shoulder=(float)Math.hypot(sx1-sx2,lsd.getPosition().y-rsd.getPosition().y)/torso;
      float pelvis=(float)Math.hypot(hx1-hx2,lh.getPosition().y-rh.getPosition().y)/torso;
      float mx=(sx1+sx2+hx1+hx2)/4f;
      float chestY=sy+(hy-sy)*.34f, waistY=sy+(hy-sy)*.68f, lowerY=hy+(hy-sy)*.10f;
      float[] cw=contourWidth(src,mx,chestY,torso), ww=contourWidth(src,mx,waistY,torso), lw=contourWidth(src,mx,lowerY,torso);
      p.body[0]=shoulder;p.body[1]=pelvis;p.body[2]=cw[0];p.body[3]=ww[0];p.body[4]=lw[0];
      p.body[5]=cw[0]/Math.max(.15f,ww[0]); p.body[6]=lw[0]/Math.max(.15f,ww[0]); p.body[7]=shoulder/Math.max(.15f,pelvis);
      p.body[8]=(hy-sy)/torso; p.body[9]=(float)Math.atan2(rsd.getPosition().y-lsd.getPosition().y,rsd.getPosition().x-lsd.getPosition().x)/(float)Math.PI;
      p.body[10]=(float)Math.atan2(rh.getPosition().y-lh.getPosition().y,rh.getPosition().x-lh.getPosition().x)/(float)Math.PI; p.body[11]=(cw[0]+ww[0]+lw[0])/3f;
      float contourConf=(cw[1]+ww[1]+lw[1])/3f; p.bodyConf=Math.max(0,Math.min(1,p.poseConf*contourConf));}
   }catch(Exception ignored){}p.featured=true;dh.recycle();sm.recycle();src.recycle();}catch(Exception e){p.featured=false;}}

 float[] contourWidth(Bitmap src,float cx,float yf,float torso){
   int y=Math.max(2,Math.min(src.getHeight()-3,Math.round(yf))); int c=Math.max(2,Math.min(src.getWidth()-3,Math.round(cx)));
   int max=Math.max(12,Math.min(Math.round(torso*1.15f),src.getWidth()/2-2)); if(max<4)return new float[]{1,.05f};
   int bestL=c-Math.min(max,c-2),bestR=c+Math.min(max,src.getWidth()-c-3); float gl=0,gr=0;
   // Search strongest persistent vertical/color boundary on each side of pose-estimated torso center.
   for(int d=4;d<=max;d++){int xl=c-d,xr=c+d;if(xl>1){float g=grad(src,xl,y);if(g>gl){gl=g;bestL=xl;}}if(xr<src.getWidth()-2){float g=grad(src,xr,y);if(g>gr){gr=g;bestR=xr;}}}
   float width=Math.max(2,bestR-bestL)/Math.max(12f,torso); float conf=Math.min(1f,(gl+gr)/220f); return new float[]{Math.min(3f,width),conf};
 }
 float grad(Bitmap b,int x,int y){int l=b.getPixel(x-1,y),r=b.getPixel(x+1,y);return (Math.abs(Color.red(l)-Color.red(r))+Math.abs(Color.green(l)-Color.green(r))+Math.abs(Color.blue(l)-Color.blue(r)))/3f;}
 double histDist(Photo a,Photo b){double s=0;for(int i=0;i<48;i++)s+=Math.abs(a.hist[i]-b.hist[i]);return Math.min(1,s/6.0);} double poseDist(Photo a,Photo b){if(a.poseConf<.45||b.poseConf<.45)return .5;double s=0;for(int i=0;i<24;i++){double d=a.pose[i]-b.pose[i];s+=d*d;}return Math.min(1,Math.sqrt(s/24.0)/1.8);}
 double bodyDist(Photo a,Photo b){if(a.bodyConf<.18||b.bodyConf<.18)return .5;double s=0,w=0;for(int i=0;i<12;i++){double scale=(i>=5&&i<=7)?1.2:((i==9||i==10)?.45:1.0);double d=(a.body[i]-b.body[i])/scale;double wi=(i==2||i==3||i==4||i==5||i==6)?1.6:1.0;s+=wi*d*d;w+=wi;}return Math.min(1,Math.sqrt(s/Math.max(1,w)));} double hashDist(Photo a,Photo b){return Long.bitCount(a.hash^b.hash)/64.0;} double aspectDist(Photo a,Photo b){return Math.min(1,Math.abs(Math.log(a.aspect()/b.aspect()))/0.8);} double timeDist(Photo a,Photo b){if(a.taken<=0||b.taken<=0)return .5;double h=Math.abs(a.taken-b.taken)/3600000.0;return Math.min(1,h/24.0);}
 double[] metricFeatures(Photo a,Photo b){return new double[]{bodyDist(a,b),poseDist(a,b),histDist(a,b),hashDist(a,b),aspectDist(a,b),Math.min(1,Math.abs(a.edge-b.edge)*4),timeDist(a,b)};}
 double legacyDist(Photo a,Photo b){double[] f=metricFeatures(a,b);double sum=0,z=0;for(int i=0;i<f.length;i++){double conf=1;if(i==0)conf=.25+.75*Math.min(a.bodyConf,b.bodyConf);if(i==1)conf=.25+.75*Math.min(a.poseConf,b.poseConf);double w=metricW[i]*conf;sum+=w*f[i];z+=w;}return sum/Math.max(.001,z);}
 void initProjection(){for(int e=0;e<EMB;e++)for(int j=0;j<RAW;j++)proj[e][j]=((e+j)%RAW==0?1.0:0.0)+(((e*13+j*7)%17)-8)*.003;}
 void loadMetric(){initProjection();android.content.SharedPreferences sp=getSharedPreferences("metric_v8",0);feedbackCount=sp.getInt("n",0);trainCount=sp.getInt("train",0);valCount=sp.getInt("val",0);valCorrect=sp.getInt("valok",0);mustLinks.addAll(sp.getStringSet("must",new HashSet<>()));cannotLinks.addAll(sp.getStringSet("cannot",new HashSet<>()));for(int e=0;e<EMB;e++)for(int j=0;j<RAW;j++)proj[e][j]=Double.longBitsToDouble(sp.getLong("p"+e+"_"+j,Double.doubleToRawLongBits(proj[e][j])));}
 void saveMetric(){android.content.SharedPreferences.Editor ed=getSharedPreferences("metric_v8",0).edit().putInt("n",feedbackCount).putInt("train",trainCount).putInt("val",valCount).putInt("valok",valCorrect).putStringSet("must",new HashSet<>(mustLinks)).putStringSet("cannot",new HashSet<>(cannotLinks));for(int e=0;e<EMB;e++)for(int j=0;j<RAW;j++)ed.putLong("p"+e+"_"+j,Double.doubleToRawLongBits(proj[e][j]));ed.apply();}
 boolean validationPair(Photo a,Photo b){long x=(a.id*0x9E3779B97F4A7C15L)^(b.id*0xC2B2AE3D27D4EB4FL);return Math.floorMod(x,5)==0;} // fixed 20% holdout
 double[] rawVector(Photo a,Photo b){return metricFeatures(a,b);}
 double attractionDistance(Photo a,Photo b){double[] f=rawVector(a,b);double s=0;for(int e=0;e<EMB;e++){double z=0;for(int j=0;j<RAW;j++)z+=proj[e][j]*(f[j]-.5);s+=z*z;}return Math.min(1,Math.sqrt(s/EMB));}
 double dist(Photo a,Photo b){return attractionDistance(a,b);}
 void learnPair(Photo a,Photo b,boolean same){String pk=pairKey(a,b);if(same){mustLinks.add(pk);cannotLinks.remove(pk);}else{cannotLinks.add(pk);mustLinks.remove(pk);}feedbackCount++;double before=dist(a,b);if(validationPair(a,b)){valCount++;boolean pred=before<.43;if(pred==same)valCorrect++;learningCurve.add(valCount==0?0:valCorrect/(double)valCount);saveMetric();return;}double[] f=rawVector(a,b);double target=same?.16:.72;double lr=.045/Math.sqrt(1+trainCount/80.0);double current=Math.max(.001,before);double err=current-target;for(int e=0;e<EMB;e++){double z=0;for(int j=0;j<RAW;j++)z+=proj[e][j]*(f[j]-.5);for(int j=0;j<RAW;j++){double grad=(z/current/EMB)*(f[j]-.5);proj[e][j]-=lr*err*grad;proj[e][j]*=.9998;}}trainCount++;saveMetric();}
 String metricText(){int acc=valCount==0?0:(int)Math.round(100.0*valCorrect/valCount);return "피드백 "+feedbackCount+" · 학습 "+trainCount+" · 검증 "+valCount+" · unseen "+acc+"%";}
 void recluster(){reset();title.setText("피드백 반영 재군집화");subtitle.setText(metricText());pool.submit(()->{ArrayList<Photo>w=new ArrayList<>();for(Photo p:photos)if(!protectedIds.contains(p.id)&&p.featured)w.add(p);ArrayList<Cluster> out=cluster(w);runOnUiThread(()->{clusters.clear();clusters.addAll(out);clusterIndex=0;showCluster();});});}
 String pairKey(Photo a,Photo b){long x=Math.min(a.id,b.id),y=Math.max(a.id,b.id);return x+":"+y;}
 double questionValue(Photo a,Photo b){double d=dist(a,b);double uncertainty=1-Math.min(1,Math.abs(d-.43)/.43);double impact=1.0;int near=0;for(Photo p:learningPool)if(p!=a&&p!=b&&(dist(a,p)<.52||dist(b,p)<.52))near++;impact=Math.min(1,near/24.0);double novelty=askedPairs.contains(pairKey(a,b))?0:1;double coverage=.55+.45*Math.min(1,Math.abs(a.taken-b.taken)/86400000.0);return novelty*(.52*uncertainty+.28*impact+.20*coverage);}
 Photo[] nextQuestion(){if(learningPool.size()<2)return null;Photo ba=null,bb=null;double best=-1;Random r=new Random(99173L+feedbackCount*31L+activeRound);int tries=Math.min(900,Math.max(120,learningPool.size()*5));for(int k=0;k<tries;k++){Photo a=learningPool.get(r.nextInt(learningPool.size())),b=learningPool.get(r.nextInt(learningPool.size()));if(a==b||askedPairs.contains(pairKey(a,b)))continue;double q=questionValue(a,b);if(q>best){best=q;ba=a;bb=b;}}if(ba==null){outer:for(Photo a:learningPool)for(Photo b:learningPool)if(a!=b&&!askedPairs.contains(pairKey(a,b))){ba=a;bb=b;break outer;}}return ba==null?null:new Photo[]{ba,bb};}
 void showActiveLearning(){reset();title.setText("3. 내 매력 유형 기준 학습");subtitle.setText("피드백 "+feedbackCount+"회 · 모델이 정보가치 높은 비교를 선택합니다");Photo[] q=nextQuestion();if(q==null){buildFromFeedback();return;}Photo a=q[0],b=q[1];LinearLayout pics=new LinearLayout(this);pics.setOrientation(LinearLayout.HORIZONTAL);ImageView ia=new ImageView(this),ib=new ImageView(this);ia.setScaleType(ImageView.ScaleType.FIT_CENTER);ib.setScaleType(ImageView.ScaleType.FIT_CENTER);pics.addView(ia,new LinearLayout.LayoutParams(0,-1,1));pics.addView(ib,new LinearLayout.LayoutParams(0,-1,1));root.addView(pics,new LinearLayout.LayoutParams(-1,0,1));loadThumb(a.uri,ia,800);loadThumb(b.uri,ib,800);TextView hint=tv("이 두 이미지는 같은 성적 매력 유형인가?\n현재 모델 거리 "+String.format(java.util.Locale.US,"%.3f",dist(a,b)),16);root.addView(hint);LinearLayout act=new LinearLayout(this);Button same=btn("같은 유형"),different=btn("다른 유형"),skip=btn("건너뜀");act.addView(same,new LinearLayout.LayoutParams(0,dp(68),1));act.addView(different,new LinearLayout.LayoutParams(0,dp(68),1));act.addView(skip,new LinearLayout.LayoutParams(0,dp(68),1));root.addView(act);View.OnClickListener refresh=v->{askedPairs.add(pairKey(a,b));activeRound++;showActiveLearning();};same.setOnClickListener(v->{askedPairs.add(pairKey(a,b));learnPair(a,b,true);activeRound++;showActiveLearning();});different.setOnClickListener(v->{askedPairs.add(pairKey(a,b));learnPair(a,b,false);activeRound++;showActiveLearning();});skip.setOnClickListener(refresh);if(feedbackCount>=15){Button build=btn("현재 기준으로 임시 군집 만들기");build.setOnClickListener(v->buildFromFeedback());root.addView(build,new LinearLayout.LayoutParams(-1,dp(68)));}TextView info=tv("질문 선택 = 불확실성 + 영향범위 + 새로움. 15회부터 임시 군집을 볼 수 있고, 부족하면 다시 학습으로 돌아옵니다.",13);root.addView(info);}
 void buildFromFeedback(){reset();title.setText("피드백으로 군집 구성 중");subtitle.setText(metricText());pool.submit(()->{ArrayList<Cluster> out=cluster(new ArrayList<>(learningPool));runOnUiThread(()->{clusters.clear();clusters.addAll(out);clusterIndex=0;showCluster();});});}
 void showBoundaryQuestion(){if(clusters.size()<2){showActiveLearning();return;}Cluster ca=null,cb=null;double best=1e9;for(int i=0;i<clusters.size();i++)for(int j=i+1;j<clusters.size();j++){if(hardCannot(clusters.get(i).items,clusters.get(j).items))continue;Photo a=medoid(clusters.get(i).items),b=medoid(clusters.get(j).items);double d=dist(a,b);if(d<best&&!askedPairs.contains(pairKey(a,b))){best=d;ca=clusters.get(i);cb=clusters.get(j);}}if(ca==null){showActiveLearning();return;}Photo a=medoid(ca.items),b=medoid(cb.items);reset();title.setText("군집 경계 한 번에 교정");subtitle.setText("답 하나로 "+(ca.items.size()+cb.items.size())+"장 경계를 학습");LinearLayout pics=new LinearLayout(this);ImageView ia=new ImageView(this),ib=new ImageView(this);ia.setScaleType(ImageView.ScaleType.FIT_CENTER);ib.setScaleType(ImageView.ScaleType.FIT_CENTER);pics.addView(ia,new LinearLayout.LayoutParams(0,-1,1));pics.addView(ib,new LinearLayout.LayoutParams(0,-1,1));root.addView(pics,new LinearLayout.LayoutParams(-1,0,1));loadThumb(a.uri,ia,800);loadThumb(b.uri,ib,800);LinearLayout ac=new LinearLayout(this);Button yes=btn("같은 유형 → 합칠 방향"),no=btn("다른 유형 → 분리 방향");ac.addView(yes,new LinearLayout.LayoutParams(0,dp(72),1));ac.addView(no,new LinearLayout.LayoutParams(0,dp(72),1));root.addView(ac);yes.setOnClickListener(v->{askedPairs.add(pairKey(a,b));learnPair(a,b,true);buildFromFeedback();});no.setOnClickListener(v->{askedPairs.add(pairKey(a,b));learnPair(a,b,false);buildFromFeedback();});}
 void buildAutoClusters(ArrayList<Photo> src){reset();title.setText("3. 자동 등급화 및 군집화");subtitle.setText("신체 형태·크기·표현 특징으로 자동 분류 중…");pool.submit(()->{for(Photo p:src){p.autoScore=autoScore(p);}assignRelativeGrades(src);ArrayList<Cluster> out=autoCluster(src);runOnUiThread(()->{clusters.clear();clusters.addAll(out);clusterIndex=0;showAutoClusters();});});}
 double bell(double x,double center,double width){double z=(x-center)/Math.max(.001,width);return Math.exp(-z*z);}
 double autoScore(Photo p){
   // Evidence layer: only image-observable morphology proxies.
   // No claim that a 2D image gives true BMI, body fat, health, fertility, or a universal attractiveness value.
   double massShape=.5, waistShape=.5, dimorphism=.5, pose=.5, occupancy=.5;
   if(p.bodyConf>.05){
     double waist=Math.max(.15,p.body[3]);
     double upper=Math.max(.15,p.body[2]);
     double lower=Math.max(.15,p.body[4]);
     double whrProxy=waist/lower;
     double upperWaist=upper/waist;
     double lowerWaist=lower/waist;
     // Apparent overall torso fullness/volume proxy from normalized contour widths.
     double fullness=(upper+waist+lower)/3.0;
     // Broad response functions: literature supports direction/range, not a universal exact optimum.
     massShape=clamp01(.60*bell(fullness,1.00,.48)+.40*bell(waist,0.78,.34));
     waistShape=clamp01(.55*bell(whrProxy,.70,.16)+.25*bell(upperWaist,1.30,.42)+.20*bell(lowerWaist,1.38,.42));
     dimorphism=clamp01(.50+.28*(lower-waist)/lower+.22*(upper-waist)/upper);
     pose=clamp01(.50+Math.abs(p.body[9]-p.body[10])*.55);
     occupancy=clamp01((p.body[11]-.45)/1.35);
   }
   // Store interpretable components in existing fields.
   p.shapeScore=100*massShape;       // apparent mass / whole-shape proxy
   p.sizeScore=100*waistShape;       // waist + multi-ratio shape
   p.poseScore=100*dimorphism;       // sexually dimorphic silhouette proxy
   p.emphasisScore=100*occupancy;    // presentation, excluded from morphology score
   double conf=Math.max(.20,p.bodyConf);
   // Morphology only. Pose/occupancy are intentionally NOT allowed to raise the core attractiveness grade.
   double morphology=.45*massShape+.35*waistShape+.20*dimorphism;
   return 100*clamp01(morphology*conf+.50*(1-conf));
 }
 double presentationScore(Photo p){return clamp01(.55*(p.emphasisScore/100.0)+.45*posePresentation(p))*100;}
 double posePresentation(Photo p){if(p.bodyConf<=.05)return .5;return clamp01(.50+Math.abs(p.body[9]-p.body[10])*.55);}
 String scoreBreakdown(Photo p){return "전체체형 "+Math.round(p.shapeScore)+" · 허리/비율 "+Math.round(p.sizeScore)+" · 성적이형성 "+Math.round(p.poseScore)+" · 형태종합 "+Math.round(p.autoScore)+" · 표현 "+Math.round(presentationScore(p));}
 String gradeRule(){return "형태 상대등급: S 상위10% · A 다음20% · B 다음40% · C 다음20% · D 하위10% (표현점수는 등급과 분리)";}
 double clamp01(double x){return Math.max(0,Math.min(1,x));}
 String gradeFor(double x){if(x>=78)return "S";if(x>=64)return "A";if(x>=50)return "B";if(x>=36)return "C";return "D";}
 void assignRelativeGrades(ArrayList<Photo> a){
   ArrayList<Photo> v=new ArrayList<>(); for(Photo p:a)v.add(p);
   Collections.sort(v,(x,y)->Double.compare(y.autoScore,x.autoScore));
   int n=v.size(); for(int i=0;i<n;i++){double q=(i+.5)/Math.max(1.0,n);v.get(i).grade=q<=.10?"S":q<=.30?"A":q<=.70?"B":q<=.90?"C":"D";}
 }
 ArrayList<Cluster> autoCluster(ArrayList<Photo> src){ArrayList<Cluster> out=new ArrayList<>();String[] grades={"S","A","B","C","D"};for(String gr:grades){ArrayList<Photo> un=new ArrayList<>();for(Photo p:src)if(gr.equals(p.grade))un.add(p);while(!un.isEmpty()){Photo seed=un.remove(0);Cluster c=new Cluster();c.items.add(seed);ArrayList<Photo> add=new ArrayList<>();for(Photo p:un)if(autoDist(seed,p)<.46)add.add(p);c.items.addAll(add);un.removeAll(add);c.sample=medoid(c.items);c.score=gradeRank(gr)*10000+c.items.size();out.add(c);}}out.sort((a,b)->Double.compare(b.score,a.score));return out;}
 int gradeRank(String g){return g.equals("S")?5:g.equals("A")?4:g.equals("B")?3:g.equals("C")?2:1;}
 double autoDist(Photo a,Photo b){double body=bodyDist(a,b),pose=poseDist(a,b),visual=histDist(a,b),hash=Long.bitCount(a.hash^b.hash)/64.0,asp=Math.min(1,Math.abs(Math.log(Math.max(.1,a.aspect())/Math.max(.1,b.aspect()))));return .46*body+.12*pose+.22*visual+.14*hash+.06*asp;}

 void showAutoClusters(){showGradeFolders();}
 void showGradeFolders(){
   reset();title.setText("4. 등급 폴더");
   String[] grades={"S","A","B","C","D"};
   LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
   ScrollView scroll=new ScrollView(this);scroll.addView(list);
   int total=0;for(Cluster c:clusters)total+=c.items.size();
   int[] gc=new int[5];for(Cluster c:clusters)for(Photo ph:c.items){int gi=ph.grade.equals("S")?0:ph.grade.equals("A")?1:ph.grade.equals("B")?2:ph.grade.equals("C")?3:4;gc[gi]++;}
   subtitle.setText("분류 "+total+"장 · S "+gc[0]+" / A "+gc[1]+" / B "+gc[2]+" / C "+gc[3]+" / D "+gc[4]+"\n등급을 눌러 군집 폴더 보기");
   for(String gr:grades){
     int cc=0,pc=0;Photo cover=null;
     for(Cluster c:clusters)if(c.sample!=null&&gr.equals(c.sample.grade)){cc++;pc+=c.items.size();if(cover==null)cover=c.sample;}
     if(cc==0)continue;
     final String grade=gr;
     LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(8),dp(8),dp(8));
     ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);row.addView(im,new LinearLayout.LayoutParams(dp(88),dp(88)));
     if(cover!=null)loadThumb(cover.uri,im,256);
     TextView tx=tv("📁 "+gr+" 등급\n"+cc+"개 군집 · "+pc+"장",18);row.addView(tx,new LinearLayout.LayoutParams(0,dp(88),1));
     row.setOnClickListener(v->showClusterFolders(grade));
     list.addView(row,new LinearLayout.LayoutParams(-1,dp(104)));
   }
   root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
   LinearLayout bar=new LinearLayout(this);
   Button back=btn("보호 화면"),apply=btn("갤러리에 폴더 적용");
   bar.addView(back,new LinearLayout.LayoutParams(0,dp(72),1));bar.addView(apply,new LinearLayout.LayoutParams(0,dp(72),1));root.addView(bar);
   back.setOnClickListener(v->showProtect());apply.setOnClickListener(v->requestApplyGalleryFolders());
 }
 void showClusterFolders(String grade){
   reset();title.setText(grade+" 등급 · 군집 폴더");subtitle.setText("폴더를 누르면 내부 사진을 봅니다.");
   GridView g=new GridView(this);g.setNumColumns(2);ArrayList<Cluster> shown=new ArrayList<>();
   for(Cluster c:clusters)if(c.sample!=null&&grade.equals(c.sample.grade))shown.add(c);
   BaseAdapter ad=new BaseAdapter(){public int getCount(){return shown.size();}public Object getItem(int i){return shown.get(i);}public long getItemId(int i){return i;}
     public View getView(int i,View v,ViewGroup parent){
       LinearLayout box=v instanceof LinearLayout?(LinearLayout)v:new LinearLayout(MainActivity.this);box.removeAllViews();box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(6),dp(6),dp(6),dp(8));
       ImageView im=new ImageView(MainActivity.this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(im,new LinearLayout.LayoutParams(-1,dp(150)));
       Cluster c=shown.get(i);loadThumb(c.sample.uri,im,360);
       TextView t=tv("📁 Cluster "+String.format(Locale.US,"%03d",i+1)+" · "+c.items.size()+"장\n형태 "+Math.round(c.sample.autoScore),14);box.addView(t);
       return box;}};
   g.setAdapter(ad);g.setOnItemClickListener((x,v,pos,id)->showClusterGrid(shown.get(pos),grade,pos+1));
   root.addView(g,new LinearLayout.LayoutParams(-1,0,1));Button back=btn("← 등급 폴더");back.setOnClickListener(v->showGradeFolders());root.addView(back,new LinearLayout.LayoutParams(-1,dp(72)));
 }
 void showClusterGrid(Cluster c,String grade,int folderNo){
   reset();title.setText("📁 "+grade+" / Cluster "+String.format(Locale.US,"%03d",folderNo));
   final HashSet<Long> selected=new HashSet<>();final boolean[] selectMode={false};
   subtitle.setText(c.items.size()+"장 · 길게 눌러 선택 시작 · 이후 탭으로 복수 선택\n"+scoreBreakdown(c.sample));
   GridView g=new GridView(this);g.setNumColumns(4);
   BaseAdapter ad=new BaseAdapter(){public int getCount(){return c.items.size();}public Object getItem(int i){return c.items.get(i);}public long getItemId(int i){return c.items.get(i).id;}
     public View getView(int i,View v,ViewGroup parent){
       FrameLayout box=v instanceof FrameLayout?(FrameLayout)v:new FrameLayout(MainActivity.this);ImageView im;
       if(box.getChildCount()==0){im=new ImageView(MainActivity.this);im.setId(333);im.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(im,new FrameLayout.LayoutParams(-1,dp(112)));}
       else im=box.findViewById(333);Photo ph=c.items.get(i);loadThumb(ph.uri,im,320);
       box.setForeground(new ColorDrawable(selected.contains(ph.id)?0x8833aa55:0));return box;}};
   g.setAdapter(ad);
   LinearLayout bar=new LinearLayout(this);Button back=btn("← 폴더 목록"),all=btn("전체 선택"),del=btn("휴지통 (0)");
   bar.addView(back,new LinearLayout.LayoutParams(0,dp(72),1));bar.addView(all,new LinearLayout.LayoutParams(0,dp(72),1));bar.addView(del,new LinearLayout.LayoutParams(0,dp(72),1));
   Runnable refresh=()->{subtitle.setText(c.items.size()+"장 · "+(selectMode[0]?"선택 모드 · "+selected.size()+"장":"길게 눌러 선택 시작")+"\n"+scoreBreakdown(c.sample));del.setText("휴지통 ("+selected.size()+")");ad.notifyDataSetChanged();};
   g.setOnItemLongClickListener((parent,v,pos,id)->{selectMode[0]=true;selected.add(c.items.get(pos).id);refresh.run();return true;});
   g.setOnItemClickListener((parent,v,pos,id)->{if(!selectMode[0]){Toast.makeText(this,"여러 장 선택은 사진을 길게 누르세요",Toast.LENGTH_SHORT).show();return;}long q=c.items.get(pos).id;if(!selected.add(q))selected.remove(q);if(selected.isEmpty())selectMode[0]=false;refresh.run();});
   root.addView(g,new LinearLayout.LayoutParams(-1,0,1));root.addView(bar);
   back.setOnClickListener(v->showClusterFolders(grade));
   all.setOnClickListener(v->{selectMode[0]=true;if(selected.size()==c.items.size())selected.clear();else{selected.clear();for(Photo ph:c.items)selected.add(ph.id);}if(selected.isEmpty())selectMode[0]=false;refresh.run();});
   del.setOnClickListener(v->{ArrayList<Photo> pick=new ArrayList<>();for(Photo ph:c.items)if(selected.contains(ph.id))pick.add(ph);if(pick.isEmpty()){Toast.makeText(this,"먼저 사진을 길게 눌러 선택하세요",Toast.LENGTH_SHORT).show();return;}trashPhotos(pick);});
 }
 void requestApplyGalleryFolders(){
   ArrayList<Uri> uris=new ArrayList<>();pendingAlbumPaths.clear();
   HashMap<String,Integer> count=new HashMap<>();
   for(Cluster c:clusters){
     if(c.sample==null)continue;String gr=c.sample.grade;int n=count.containsKey(gr)?count.get(gr)+1:1;count.put(gr,n);
     String path="Pictures/CleaningGallery/"+gr+"/Cluster_"+String.format(Locale.US,"%03d",n)+"/";
     for(Photo ph:c.items){uris.add(ph.uri);pendingAlbumPaths.put(ph.uri.toString(),path);}
   }
   if(uris.isEmpty()){Toast.makeText(this,"적용할 사진이 없습니다",Toast.LENGTH_SHORT).show();return;}
   pendingAlbumUris=new ArrayList<>(uris);
   try{
     PendingIntent pi=MediaStore.createWriteRequest(getContentResolver(),pendingAlbumUris);
     startIntentSenderForResult(pi.getIntentSender(),WRITE_ALBUMS,null,0,0,0);
   }catch(Exception e){Toast.makeText(this,"앨범 쓰기 권한 요청 실패: "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show();}
 }
 void applyGalleryFolders(){
   int ok=0,fail=0;ContentResolver cr=getContentResolver();
   for(Uri u:pendingAlbumUris){String path=pendingAlbumPaths.get(u.toString());if(path==null)continue;try{ContentValues cv=new ContentValues();cv.put(MediaStore.MediaColumns.RELATIVE_PATH,path);int n=cr.update(u,cv,null,null);if(n>0)ok++;else fail++;}catch(Exception e){fail++;}}
   Toast.makeText(this,"갤러리 폴더 적용 "+ok+"장"+(fail>0?" · 실패 "+fail+"장":""),Toast.LENGTH_LONG).show();
   pendingAlbumUris.clear();pendingAlbumPaths.clear();
 }
 void trashPhotos(ArrayList<Photo> items){ArrayList<Uri>u=new ArrayList<>();for(Photo p:items)u.add(p.uri);requestTrashUris(u);}
 void showDiagnostics(){final Dialog d=new Dialog(this);LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(12),dp(12),dp(12),dp(12));b.addView(tv("v8 Constraint Clustering 진단",22));b.addView(tv(metricText(),16));b.addView(tv("검증 세트는 사진 ID 해시로 고정된 약 20%이며 학습 업데이트에 사용하지 않습니다. unseen 정확도는 같은/다른 매력 유형 피드백 예측 정확도입니다.",14));b.addView(tv("목표: 피드백이 늘면서 unseen 정확도↑, false merge↓, false split↓, 평균 군집 크기↑. 단일 매력도 등급 대신 16차원 개인화 매력유형 embedding을 학습합니다. COBRA 방식으로 먼저 과분할하고, Must-Link만 군집을 합치며 Cannot-Link는 합병을 금지합니다. learned metric은 질문 순서와 미확정 유사도에만 사용합니다.",14));Button re=btn("지금 재군집화");re.setOnClickListener(v->{d.dismiss();recluster();});b.addView(re);Button close=btn("닫기");close.setOnClickListener(v->d.dismiss());b.addView(close);d.setContentView(b);d.show();if(d.getWindow()!=null)d.getWindow().setLayout(-1,-2);}
 ArrayList<Cluster> cluster(ArrayList<Photo>a){
   // COBRA-style: deliberately over-cluster first. Feedback is a hard constraint, not merely a distance sample.
   ArrayList<ArrayList<Photo>> supers=new ArrayList<>(); ArrayList<Photo> un=new ArrayList<>(a);
   while(!un.isEmpty()){Photo seed=un.remove(0);ArrayList<Photo> g=new ArrayList<>();g.add(seed);ArrayList<Photo> add=new ArrayList<>();for(Photo p:un){boolean ok=dist(seed,p)<.30;for(Photo q:g)if(dist(p,q)>.34){ok=false;break;}if(ok)add.add(p);}g.addAll(add);un.removeAll(add);supers.add(g);}
   int n=supers.size();int[] par=new int[n];for(int i=0;i<n;i++)par[i]=i;
   // Must-Link feedback merges super-instances transitively.
   for(String key:mustLinks){String[] z=key.split(":");if(z.length!=2)continue;long x=Long.parseLong(z[0]),y=Long.parseLong(z[1]);int ix=superOf(supers,x),iy=superOf(supers,y);if(ix>=0&&iy>=0)union(par,ix,iy);}
   HashMap<Integer,ArrayList<Photo>> groups=new HashMap<>();for(int i=0;i<n;i++){int r=findRoot(par,i);groups.computeIfAbsent(r,k->new ArrayList<>()).addAll(supers.get(i));}
   ArrayList<Cluster> out=new ArrayList<>();for(ArrayList<Photo> g:groups.values()){Cluster c=new Cluster();c.items.addAll(g);c.sample=g.get(new Random().nextInt(g.size()));c.purity=purity(g);c.rrr=rrr(g);c.score=g.size()*c.purity*c.rrr;out.add(c);}out.sort((x,y)->Double.compare(y.score,x.score));return out;}
 int superOf(ArrayList<ArrayList<Photo>> s,long id){for(int i=0;i<s.size();i++)for(Photo p:s.get(i))if(p.id==id)return i;return -1;}
 int findRoot(int[] p,int x){while(p[x]!=x){p[x]=p[p[x]];x=p[x];}return x;} void union(int[] p,int a,int b){a=findRoot(p,a);b=findRoot(p,b);if(a!=b)p[b]=a;}
 boolean hardCannot(ArrayList<Photo>a,ArrayList<Photo>b){for(Photo x:a)for(Photo y:b)if(cannotLinks.contains(pairKey(x,y)))return true;return false;}
 Photo medoid(ArrayList<Photo>g){if(g.size()<2)return g.get(0);Photo best=g.get(0);double bs=1e9;for(Photo p:g){double s=0;for(Photo q:g)s+=dist(p,q);if(s<bs){bs=s;best=p;}}return best;} double purity(ArrayList<Photo>g){if(g.size()<2)return 1;double worst=0;for(int i=0;i<g.size();i++)for(int j=i+1;j<g.size();j++)worst=Math.max(worst,dist(g.get(i),g.get(j)));return Math.max(0,1-worst);} double rrr(ArrayList<Photo>g){if(g.size()<2)return 1;int good=0;for(Photo p:g){double worst=0;for(Photo q:g)worst=Math.max(worst,dist(p,q));if(worst<=.58)good++;}return good/(double)g.size();}
 void showCluster(){reset();title.setText("4. 피드백 기반 군집 확인");if(clusterIndex>=clusters.size()){subtitle.setText("완료");Button b=btn("처음으로");b.setOnClickListener(v->showProtect());root.addView(b);return;}Cluster c=clusters.get(clusterIndex);subtitle.setText((clusterIndex+1)+"/"+clusters.size()+" · "+c.items.size()+"장 · RRR "+Math.round(c.rrr*100)+"% · "+metricText());subtitle.setOnClickListener(v->showDiagnostics());ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.FIT_CENTER);root.addView(im,new LinearLayout.LayoutParams(-1,0,1));loadThumb(c.sample.uri,im,1200);im.setOnLongClickListener(v->{showInspector(c);return true;});LinearLayout ac=new LinearLayout(this);Button keep=btn("유지 / 다음"),trash=btn("군집 휴지통 ("+c.items.size()+")");ac.addView(keep,new LinearLayout.LayoutParams(0,dp(72),1));ac.addView(trash,new LinearLayout.LayoutParams(0,dp(72),1));root.addView(ac,new LinearLayout.LayoutParams(-1,dp(88)));LinearLayout learnBar=new LinearLayout(this);Button more=btn("기준 더 학습"),boundary=btn("군집 경계 교정");learnBar.addView(more,new LinearLayout.LayoutParams(0,dp(58),1));learnBar.addView(boundary,new LinearLayout.LayoutParams(0,dp(58),1));root.addView(learnBar);more.setOnClickListener(v->showActiveLearning());boundary.setOnClickListener(v->showBoundaryQuestion());keep.setOnClickListener(v->{clusterIndex++;showCluster();});trash.setOnClickListener(v->trash(c));}
 void showInspector(Cluster c){final Dialog d=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);TextView h=tv("학습 Inspector · "+c.items.size()+"장 · "+metricText(),18);box.addView(h);TextView help=tv("사진을 탭해 대표와 같은 성적 매력 유형인지 피드백하세요. 약 20%는 고정 검증 세트로만 사용됩니다.",14);box.addView(help);GridView g=new GridView(this);g.setNumColumns(4);g.setAdapter(new BaseAdapter(){public int getCount(){return c.items.size();}public Object getItem(int i){return c.items.get(i);}public long getItemId(int i){return c.items.get(i).id;}public View getView(int i,View v,ViewGroup p){ImageView im=v instanceof ImageView?(ImageView)v:new ImageView(MainActivity.this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setLayoutParams(new AbsListView.LayoutParams(-1,dp(100)));loadThumb(c.items.get(i).uri,im,256);return im;}});g.setOnItemClickListener((parent,v,pos,id)->{Photo x=c.items.get(pos);if(x==c.sample){Toast.makeText(this,"이 사진이 현재 대표입니다",Toast.LENGTH_SHORT).show();return;}new AlertDialog.Builder(this).setTitle("대표와 같은 매력 유형?").setMessage("현재 거리 "+String.format(java.util.Locale.US,"%.3f",dist(c.sample,x))+"\n"+metricText()).setPositiveButton("같은 매력 유형",(q,z)->{learnPair(c.sample,x,true);h.setText("학습 Inspector · "+c.items.size()+"장 · "+metricText());}).setNegativeButton("다른 매력 유형",(q,z)->{learnPair(c.sample,x,false);h.setText("학습 Inspector · "+c.items.size()+"장 · "+metricText());}).setNeutralButton("취소",null).show();});box.addView(g,new LinearLayout.LayoutParams(-1,0,1));LinearLayout actions=new LinearLayout(this);Button good=btn("군집 매력유형 일치"),diag=btn("학습 진단"),close=btn("닫기");actions.addView(good,new LinearLayout.LayoutParams(0,dp(64),1));actions.addView(diag,new LinearLayout.LayoutParams(0,dp(64),1));actions.addView(close,new LinearLayout.LayoutParams(0,dp(64),1));good.setOnClickListener(v->{for(Photo x:c.items)if(x!=c.sample)learnPair(c.sample,x,true);h.setText("학습 Inspector · "+c.items.size()+"장 · "+metricText());Toast.makeText(this,"positive pair 학습 완료",Toast.LENGTH_SHORT).show();});diag.setOnClickListener(v->showDiagnostics());close.setOnClickListener(v->d.dismiss());box.addView(actions);d.setContentView(box);d.show();if(d.getWindow()!=null)d.getWindow().setLayout(-1,-1);}
 void requestTrashUris(ArrayList<Uri> u){
   if(u==null||u.isEmpty()){Toast.makeText(this,"선택된 사진이 없습니다",Toast.LENGTH_SHORT).show();return;}
   // MediaStore requires item-specific MediaStore URIs and system confirmation.
   pendingTrash=new ArrayList<>(u); pendingTrashCount=u.size();
   if(pendingTrash.size()>1900) pendingTrash=new ArrayList<>(pendingTrash.subList(0,1900));
   try{
     PendingIntent pi=MediaStore.createTrashRequest(getContentResolver(),pendingTrash,true);
     startIntentSenderForResult(pi.getIntentSender(),TRASH,null,0,0,0);
   }catch(Exception e){Toast.makeText(this,"휴지통 요청 실패: "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show();}
 }
 void trash(Cluster c){ArrayList<Uri>u=new ArrayList<>();for(Photo p:c.items)u.add(p.uri);requestTrashUris(u);}
 @Override protected void onActivityResult(int r,int z,Intent d){
   super.onActivityResult(r,z,d);
   if(r==WRITE_ALBUMS){
     if(z==RESULT_OK)applyGalleryFolders();else{Toast.makeText(this,"갤러리 폴더 적용이 취소되었습니다",Toast.LENGTH_SHORT).show();pendingAlbumUris.clear();pendingAlbumPaths.clear();}
     return;
   }
   if(r==TRASH){
     if(z==RESULT_OK){
       HashSet<String> done=new HashSet<>();for(Uri u:pendingTrash)done.add(u.toString());
       for(Photo p:photos)if(done.contains(p.uri.toString()))p.featured=false;
       Toast.makeText(this,"휴지통 이동 완료: "+pendingTrash.size()+"장",Toast.LENGTH_SHORT).show();
       pendingTrash.clear(); pendingTrashCount=0;
       ArrayList<Photo> eligible=new ArrayList<>();for(Photo p:photos)if(p.featured&&!protectedIds.contains(p.id))eligible.add(p);
       clusters.clear();clusters.addAll(autoCluster(eligible));persistClusters(clusters);clusterIndex=0;showAutoClusters();
     }else{
       Toast.makeText(this,"휴지통 이동이 취소되었습니다",Toast.LENGTH_SHORT).show();
       pendingTrash.clear();pendingTrashCount=0;
     }
   }
 } void loadThumb(Uri u,ImageView v,int z){v.setImageDrawable(new ColorDrawable(0xffdddddd));pool.submit(()->{try{Bitmap b=getContentResolver().loadThumbnail(u,new android.util.Size(z,z),null);runOnUiThread(()->{if(b!=null)v.setImageBitmap(b);else v.setImageDrawable(new ColorDrawable(0xffbbbbbb));});}catch(Exception e){runOnUiThread(()->{v.setImageDrawable(new ColorDrawable(0xffbbbbbb));v.setContentDescription("이미지 로딩 실패");});}});}
 class PhotoAdapter extends BaseAdapter{public int getCount(){return photos.size();}public Object getItem(int p){return photos.get(p);}public long getItemId(int p){return photos.get(p).id;}public View getView(int p,View cv,ViewGroup par){FrameLayout box;ImageView im;if(cv==null){box=new FrameLayout(MainActivity.this);im=new ImageView(MainActivity.this);im.setId(100);im.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(im,new FrameLayout.LayoutParams(-1,dp(96)));cv=box;}else{box=(FrameLayout)cv;im=box.findViewById(100);}Photo ph=photos.get(p);im.setImageDrawable(new ColorDrawable(0xffdddddd));loadThumb(ph.uri,im,256);box.setForeground(new ColorDrawable(protectedIds.contains(ph.id)?0x6633aa55:0));return cv;}}
 @Override protected void onDestroy(){if(poseDetector!=null)poseDetector.close();pool.shutdownNow();super.onDestroy();}
}
