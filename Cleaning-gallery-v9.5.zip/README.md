# Cleaning Gallery v9.5

Incremental persistent classification:
- Photo cache keyed by MediaStore ID.
- Cache validity checks DATE_MODIFIED + SIZE.
- Unchanged photos restore saved score, grade and stable cluster ID.
- New/modified photos alone run feature extraction.
- New/modified photos attach to the nearest existing cluster when within the existing threshold; otherwise a new cluster is created.
- Existing grades/clusters are not globally reshuffled on app restart.
- Protected IDs persist locally.
- Existing grade-folder → cluster-folder → grid UI and Galaxy Gallery folder export remain.

Android recommends resyncing cached MediaStore data when the media collection changes. v9.5 additionally checks per-photo modification metadata so unchanged items can reuse classification.
