# Gallery Cleaner 1.0
Fresh rebuild: fixed absolute grades, cropped-photo aware scoring, persistent features, incremental MediaStore scanning, 32-photo checkpoints, stable groups, and MediaStore trash.

## v2 on-device AI direction
- Build includes Google MediaPipe Tasks Vision and downloads the official Pose Landmarker Lite and MobileNet V3 Small Image Embedder models into APK assets.
- Runtime inference is intended to remain entirely on-device: no per-photo API fee and no photo upload.
- Large imports use 100-photo checkpoint groups, while inference itself remains sequential so 100 Bitmaps are never held in memory at once.
- Pose visibility/world-landmark output is the body-evidence layer; image embeddings are the similarity/grouping layer.
- Existing cached photos are not globally regraded when new photos arrive.
