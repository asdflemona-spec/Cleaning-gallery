package xyz.quaver.pupil.ui.compose

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/** First-party login page: Iris never receives, logs, or stores account passwords. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun IrisSocialWebSource(service: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val isX = service == "x"
    val home = if (isX) "https://x.com/" else "https://www.pinterest.com/"
    val login = if (isX) "https://x.com/i/flow/login" else "https://www.pinterest.com/login/"
    var webView by remember(service) { mutableStateOf<WebView?>(null) }
    var currentUrl by remember(service) { mutableStateOf(home) }
    var canBack by remember(service) { mutableStateOf(false) }
    DisposableEffect(service) {
        onDispose {
            webView?.stopLoading()
            webView?.destroy()
            webView = null
        }
    }
    BackHandler(canBack) { webView?.goBack() }
    Column(modifier) {
        Text(if (isX) "X" else "Pinterest", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        Text("로그인 정보는 해당 서비스의 웹페이지에 직접 입력합니다. Iris는 비밀번호를 수집하거나 저장하지 않습니다.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { webView?.loadUrl(home) }) { Text("홈") }
            OutlinedButton(onClick = { webView?.loadUrl(login) }) { Text("로그인") }
            OutlinedButton(onClick = { webView?.reload() }) { Text("새로고침") }
            OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))) }) { Text("브라우저") }
        }
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.setSupportMultipleWindows(false)
                    CookieManager.getInstance().setAcceptCookie(true)
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            currentUrl = url ?: home
                            canBack = view?.canGoBack() == true
                        }
                    }
                    loadUrl(home)
                    webView = this
                }
            },
            update = { webView = it },
        )
    }
}
