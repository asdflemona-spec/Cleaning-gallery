# Cleaning Gallery v7 — Active Learning

v7 changes the product loop: feedback creates the clustering criterion instead of merely correcting prebuilt clusters.

Flow: protect photos → extract features → active pair questions → personalized 16D metric → provisional clusters → boundary correction → random representative cleanup.

Active question value combines uncertainty, estimated affected neighborhood size, and novelty. After 15 feedback answers the user can build provisional clusters. The review screen can return to active learning or ask a high-impact cluster-boundary question. About 20% of pair feedback remains a fixed validation holdout and does not update the model.

The existing on-device visual/body/pose features are inputs; user same/different-attractiveness-type feedback determines the learned metric. No single attractiveness score is used.
