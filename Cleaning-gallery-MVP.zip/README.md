# Cleaning Gallery MVP

Flow:
1. Load all images.
2. User selects photos that must NOT be removed.
3. Exclude protected photos.
4. Cluster the rest by capture date (MVP rule).
5. Pick one random representative per cluster.
6. User sees only that random representative.
7. "Trash cluster" sends the whole cluster to Android's system trash using `MediaStore.createTrashRequest()`.

## Requirements
- Android 11 (API 30) or newer.
- Photo read permission.
- Trash operation requires Android's system confirmation dialog.

## GitHub Actions
Use `.github/workflows/build-apk.yml` from the provided package, or paste the workflow supplied with the delivery.
