package com.cleaninggallery.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private static final int PERM = 10;
    private final ArrayList<Photo> photos = new ArrayList<>();
    private final HashSet<Long> protectedIds = new HashSet<>();
    private final ArrayList<Cluster> clusters = new ArrayList<>();
    private int clusterIndex = 0;
    private LinearLayout root;
    private TextView title, subtitle;
    private ExecutorService pool = Executors.newFixedThreadPool(4);

    static class Photo {
        long id, taken;
        Uri uri;
        Photo(long id, long taken, Uri uri) { this.id=id; this.taken=taken; this.uri=uri; }
    }
    static class Cluster {
        String key;
        ArrayList<Photo> items = new ArrayList<>();
        Photo sample;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildShell();
        requestAccess();
    }

    private TextView tv(String s, int sp) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(0xff111111);
        v.setPadding(dp(16), dp(8), dp(16), dp(8));
        return v;
    }
    private Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b;
    }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density); }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xfffafafa);
        title = tv("Cleaning Gallery", 26);
        title.setTypeface(null, 1);
        subtitle = tv("사진을 불러오는 중…", 15);
        root.addView(title);
        root.addView(subtitle);
        setContentView(root);
    }

    private void requestAccess() {
        String p = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) loadPhotos();
        else requestPermissions(new String[]{p}, PERM);
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == PERM && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) loadPhotos();
        else subtitle.setText("사진 접근 권한이 필요합니다.");
    }

    private void loadPhotos() {
        photos.clear();
        String[] projection = {
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DATE_TAKEN
        };
        try (Cursor c = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, null, null,
                MediaStore.Images.Media.DATE_TAKEN + " DESC")) {
            if (c != null) {
                int idCol=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                int dateCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN);
                while(c.moveToNext()) {
                    long id=c.getLong(idCol);
                    long taken=c.getLong(dateCol);
                    Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, Long.toString(id));
                    photos.add(new Photo(id,taken,uri));
                }
            }
        }
        showProtectScreen();
    }

    private void resetBody() {
        while(root.getChildCount() > 2) root.removeViewAt(2);
    }

    private void showProtectScreen() {
        resetBody();
        title.setText("1. 제거 안 할 사진 선택");
        subtitle.setText("전체 " + photos.size() + "장 · 탭한 사진은 보호됩니다.");

        GridView grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setVerticalSpacing(dp(2)); grid.setHorizontalSpacing(dp(2));
        PhotoAdapter adapter = new PhotoAdapter(photos, protectedIds);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((p,v,pos,id)->{
            long pid=photos.get(pos).id;
            if (!protectedIds.add(pid)) protectedIds.remove(pid);
            adapter.notifyDataSetChanged();
            subtitle.setText("전체 " + photos.size() + "장 · 보호 " + protectedIds.size() + "장");
        });
        root.addView(grid, new LinearLayout.LayoutParams(-1,0,1));

        Button next=btn("보호 완료 → 군집화");
        next.setOnClickListener(v -> makeClusters());
        root.addView(next);
    }

    private void makeClusters() {
        // MVP: 촬영일(yyyy-MM-dd) 기준 군집. DATE_TAKEN이 없으면 unknown.
        // 보호 사진은 군집화에서 완전히 제외한다.
        LinkedHashMap<String, Cluster> map = new LinkedHashMap<>();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        for (Photo p: photos) {
            if (protectedIds.contains(p.id)) continue;
            String key = p.taken > 0 ? f.format(new Date(p.taken)) : "날짜 없음";
            Cluster c = map.get(key);
            if (c == null) { c=new Cluster(); c.key=key; map.put(key,c); }
            c.items.add(p);
        }
        clusters.clear();
        clusters.addAll(map.values());
        Collections.shuffle(clusters);
        Random random = new Random();
        for (Cluster c: clusters) c.sample = c.items.get(random.nextInt(c.items.size()));
        clusterIndex=0;
        showCluster();
    }

    private void showCluster() {
        resetBody();
        title.setText("2. 랜덤 이미지만 확인");
        if (clusters.isEmpty() || clusterIndex >= clusters.size()) {
            subtitle.setText("모든 군집을 확인했습니다.");
            Button again=btn("처음으로");
            again.setOnClickListener(v->showProtectScreen());
            root.addView(again);
            return;
        }
        Cluster c=clusters.get(clusterIndex);
        subtitle.setText((clusterIndex+1)+"/"+clusters.size()+" · "+c.key+" · "+c.items.size()+"장");

        ImageView image=new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setBackgroundColor(0xffeeeeee);
        root.addView(image,new LinearLayout.LayoutParams(-1,0,1));
        loadThumb(c.sample.uri,image,1200);

        LinearLayout actions=new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button skip=btn("건너뛰기");
        Button trash=btn("군집 전체 휴지통 ("+c.items.size()+")");
        actions.addView(skip,new LinearLayout.LayoutParams(0,dp(64),1));
        actions.addView(trash,new LinearLayout.LayoutParams(0,dp(64),1));
        root.addView(actions);

        skip.setOnClickListener(v->{ clusterIndex++; showCluster(); });
        trash.setOnClickListener(v->trashCluster(c));
    }

    private void trashCluster(Cluster c) {
        ArrayList<Uri> uris=new ArrayList<>();
        for(Photo p:c.items) uris.add(p.uri);
        // Android 15+ target에서 요청당 URI 제한에 대비해 1900개씩 처리.
        if (uris.size() > 1900) {
            Toast.makeText(this,"MVP에서는 군집당 최대 1900장까지 휴지통 이동합니다.",Toast.LENGTH_LONG).show();
            uris = new ArrayList<>(uris.subList(0,1900));
        }
        PendingIntent pi=MediaStore.createTrashRequest(getContentResolver(),uris,true);
        try {
            startIntentSenderForResult(pi.getIntentSender(),200,null,0,0,0);
        } catch(IntentSender.SendIntentException e) {
            Toast.makeText(this,"휴지통 요청 실패",Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if(req==200) {
            if(result==RESULT_OK) Toast.makeText(this,"휴지통으로 이동했습니다.",Toast.LENGTH_SHORT).show();
            clusterIndex++;
            showCluster();
        }
    }

    private void loadThumb(Uri uri, ImageView target, int size) {
        pool.submit(()->{
            try {
                Bitmap b=getContentResolver().loadThumbnail(uri,new android.util.Size(size,size),null);
                runOnUiThread(()->target.setImageBitmap(b));
            } catch(IOException ignored){}
        });
    }

    class PhotoAdapter extends BaseAdapter {
        ArrayList<Photo> data; HashSet<Long> selected;
        PhotoAdapter(ArrayList<Photo>d,HashSet<Long>s){data=d;selected=s;}
        public int getCount(){return data.size();}
        public Object getItem(int p){return data.get(p);}
        public long getItemId(int p){return data.get(p).id;}
        public View getView(int p, View convert, android.view.ViewGroup parent) {
            FrameLayout box;
            ImageView im;
            if(convert==null) {
                box=new FrameLayout(MainActivity.this);
                im=new ImageView(MainActivity.this);
                im.setId(100);
                im.setScaleType(ImageView.ScaleType.CENTER_CROP);
                box.addView(im,new FrameLayout.LayoutParams(-1,dp(96)));
                convert=box;
            } else { box=(FrameLayout)convert; im=box.findViewById(100); }
            Photo photo=data.get(p);
            im.setImageDrawable(new ColorDrawable(0xffdddddd));
            loadThumb(photo.uri,im,256);
            box.setForeground(new ColorDrawable(selected.contains(photo.id)?0x6633aa55:0x00000000));
            return convert;
        }
    }

    @Override protected void onDestroy() {
        pool.shutdownNow();
        super.onDestroy();
    }
}
