package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisAuctionRecord
import xyz.quaver.pupil.util.IrisAuctionStore

@Composable
fun IrisHumanAuction(modifier:Modifier=Modifier){
    val context=LocalContext.current
    var records by remember { mutableStateOf(IrisAuctionStore.list(context)) }
    var editing by remember { mutableStateOf<IrisAuctionRecord?>(null) }
    var section by remember { mutableStateOf(0) }
    Column(modifier){
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)) {
            FilterChip(section==0,{section=0},label={Text("추천 자료")})
            Spacer(Modifier.width(8.dp))
            FilterChip(section==1,{section=1},label={Text("제도 전시")})
            Spacer(Modifier.width(8.dp))
            FilterChip(section==2,{section=2},label={Text("구조 분석")})
        }
        if(section==1 || section==2){
            Text(if(section==1) "성노예제 제도 전시 · 비판적 분석" else "성착취 구조 분석 · 비판적 분석",style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(16.dp))
            Text("가상 제도 분석입니다. 실제 사진 속 인물의 권리·소유권·성적 동의를 변경하지 않습니다.",modifier=Modifier.padding(horizontal=16.dp))
            Text("추천 자료에서 H번호를 선택해 역사 기반 속성을 편집하세요.",modifier=Modifier.padding(12.dp))
            val stages=if(section==1) listOf("정보화 · 사진과 기록","서열화 · 분류 제도의 작동","상품화 · 역사적 거래 구조","도구화 · 권리 침해의 구조","제도적 처우 · 통제와 배제") else listOf("시각적 소비 · 열람과 비교","상업적 소비 · 상품화 메커니즘","강제적 이용 · 동의권 침해","권리 회복 · 보호와 지원")
            stages.forEachIndexed { index, stage -> Card(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=5.dp)){Text("${index+1}. $stage",modifier=Modifier.padding(14.dp))} }
        } else {
        Text("H-Series · 역사 기반 가상 제도 모델",style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(16.dp))
        Text("실제 인물의 거래·법적 지위를 나타내지 않는 사용자 지정 분류입니다.",modifier=Modifier.padding(horizontal=16.dp))
        LazyColumn { items(records,key={it.uri}) { r ->
            Card(Modifier.fillMaxWidth().padding(8.dp).clickable { editing=r }) {
                Row(Modifier.padding(12.dp)) {
                    AsyncImage(model=r.uri,contentDescription="추천 사진",modifier=Modifier.size(100.dp))
                    Column(Modifier.padding(start=12.dp)) {
                        Text("H-${r.number.toString().padStart(3,'0')}",style=MaterialTheme.typography.titleMedium)
                        Text("경제적 · ${r.credits} 크레딧")
                        Text("기능적 · ${r.function}")
                        Text("정보적 · ${informationOptions.getOrElse(r.score) { informationOptions[0] }}")
                        Text("사회적 · ${r.social}")
                        Text("법적 · ${r.legal}")
                    }
                }
            }
        } }
        }
    }
    editing?.let { initial ->
        var credits by remember(initial.uri) { mutableStateOf(initial.credits.toString()) }
        var function by remember(initial.uri) { mutableStateOf(initial.function) }
        var info by remember(initial.uri) { mutableStateOf(informationOptions.getOrElse(initial.score) { informationOptions[0] }) }
        var social by remember(initial.uri) { mutableStateOf(initial.social) }
        var legal by remember(initial.uri) { mutableStateOf(initial.legal) }
        AlertDialog(onDismissRequest={editing=null},title={Text("H-${initial.number.toString().padStart(3,'0')} 속성 편집")},text={
            Column {
                Text("경제적 속성 (가상 크레딧)")
                OutlinedTextField(credits,{credits=it.filter(Char::isDigit).take(8)},label={Text("크레딧")},singleLine=true)
                Text("기능적 속성")
                AttributeSelector(function,functionOptions){function=it}
                Text("정보적 속성 · 역사적 등록·감시 제도")
                AttributeSelector(info,informationOptions){info=it}
                Text("사회적 속성")
                AttributeSelector(social,socialOptions){social=it}
                Text("법적 속성 (가상 세계관 설정)")
                AttributeSelector(legal,legalOptions){legal=it}
            }
        },confirmButton={TextButton(onClick={
            IrisAuctionStore.update(context,initial.copy(credits=credits.toIntOrNull()?:0,function=function,score=informationOptions.indexOf(info).coerceAtLeast(0),social=social,legal=legal))
            records=IrisAuctionStore.list(context);editing=null
        }){Text("저장")}},dismissButton={TextButton(onClick={editing=null}){Text("취소")}})
    }
}

@Composable private fun AttributeSelector(value:String,choices:List<String>,onChange:(String)->Unit){
    var expanded by remember { mutableStateOf(false) }
    Box { TextButton(onClick={expanded=true}){Text("$value ▾")}
        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
            choices.forEach { option -> DropdownMenuItem(text={Text(option)},onClick={onChange(option);expanded=false}) }
        }
    }
}


/** Historical analytical categories; applying them to objects is fictional, not a historical claim. */
private val functionOptions=listOf("가사노동","생산노동","접객","강제적 성적 이용에 관한 제도 분류","미분류")
private val informationOptions=listOf("미등록","기본 등록","상세 등록","지속 감시","기록 말소")
private val socialOptions=listOf("특권층","일반층","종속층","배제층","등급 외")
private val legalOptions=listOf("권리 인정","권리 제한","타인의 지배 아래 놓인 지위","법적 보호 배제","해방")
