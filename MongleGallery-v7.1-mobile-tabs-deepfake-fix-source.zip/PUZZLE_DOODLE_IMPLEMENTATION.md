# Puzzle and doodle extension (2026-10-23)

Implemented in `IrisHumanAuction.kt`: configurable 3x3/4x4/6x6 reveal, sliding puzzle with solvable shuffle, tile swap, per-item puzzle board persistence, and doodle pen/highlighter/line/eraser-like dark stroke, colors, brush width, undo/redo within session. Video still frame used as tile source.

Limitations: No third-party source has been imported or redistributed. The planned irregular jigsaw, text, stickers, true transparent eraser, export, and full editable layer model are not implemented. No Gradle compile verification because Gradle distribution could not be downloaded in this environment. Existing older saved doodles are not migrated to v2 storage.
