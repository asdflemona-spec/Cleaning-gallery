package xyz.quaver.pupil.ui.compose

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize

enum class IrisLibrarySource { GALLERY }

@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    IrisGallerySection(Modifier.fillMaxSize())
}
