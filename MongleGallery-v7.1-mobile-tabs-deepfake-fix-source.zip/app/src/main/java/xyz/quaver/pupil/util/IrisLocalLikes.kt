package xyz.quaver.pupil.util

import android.content.Context

/** Local-only hearts. Unrelated to any registry or auction. */
object IrisLocalLikes {
    private fun prefs(context: Context) = context.getSharedPreferences("iris_gallery_likes_v1", Context.MODE_PRIVATE)
    fun contains(context: Context, uri: String): Boolean = prefs(context).getBoolean(uri, false)
    fun toggle(context: Context, uri: String): Boolean {
        val next = !contains(context, uri)
        prefs(context).edit().putBoolean(uri, next).apply()
        return next
    }
}
