package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisGalleryMedia
import kotlin.math.roundToInt

/** Local-only visual face-overlay simulation; no AI processing or external upload. */
@Composable
fun IrisDeepfakeStudio(items: List<IrisGalleryMedia>, modifier: Modifier = Modifier) {
    val photos = remember(items) { items.filterNot { it.isVideo } }
    var source by remember { mutableStateOf<IrisGalleryMedia?>(null) }
    var target by remember { mutableStateOf<IrisGalleryMedia?>(null) }
    var choosingSource by remember { mutableStateOf(true) }
    var opacity by remember { mutableFloatStateOf(.75f) }
    var size by remember { mutableFloatStateOf(.55f) }
    var x by remember { mutableFloatStateOf(0f) }
    var y by remember { mutableFloatStateOf(0f) }
    var editing by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Text("Deepfake · 시뮬레이션", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(vertical = 8.dp))
        Text("사진을 겹쳐 배치하는 로컬 연출입니다. 실제 AI 얼굴 교체는 하지 않습니다.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(choosingSource, onClick = { choosingSource = true; editing = false }, label = { Text("원본 사진 ${if (source != null) "✓" else "+"}") })
            FilterChip(!choosingSource, onClick = { choosingSource = false; editing = false }, label = { Text("대상 사진 ${if (target != null) "✓" else "+"}") })
            if (source != null && target != null) TextButton(onClick = { editing = !editing }) { Text(if (editing) "선택" else "합성 보기") }
        }
        if (editing && source != null && target != null) {
            Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(12.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
                AsyncImage(target!!.uri, "대상", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AsyncImage(
                        source!!.uri, "원본 오버레이",
                        Modifier.fillMaxWidth(size).aspectRatio(1f)
                            .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
                            .alpha(opacity)
                            .clip(RoundedCornerShape(48.dp))
                            .pointerInput(size) { detectDragGestures { change, drag -> change.consume(); x += drag.x; y += drag.y } },
                        contentScale = ContentScale.Crop
                    )
                }
            }
            Text("원본 사진을 드래그해 위치를 조정하세요", style = MaterialTheme.typography.bodySmall)
            Text("크기 ${(size * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
            Slider(size, { size = it }, valueRange = .2f..1f)
            Text("투명도 ${(opacity * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
            Slider(opacity, { opacity = it }, valueRange = 0f..1f)
            TextButton(onClick = { x = 0f; y = 0f; size = .55f; opacity = .75f }) { Text("위치·효과 초기화") }
        } else {
            Text(if (choosingSource) "겹쳐 놓을 원본 사진 선택" else "배경이 될 대상 사진 선택", style = MaterialTheme.typography.labelMedium)
            if (photos.isEmpty()) Text("갤러리에 접근 가능한 사진이 없습니다.")
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(photos, key = { it.uri }) { photo ->
                    val selected = if (choosingSource) source?.uri == photo.uri else target?.uri == photo.uri
                    Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(8.dp)).background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.DarkGray).clickable {
                        if (choosingSource) { source = photo; choosingSource = false } else { target = photo; if (source != null) editing = true }
                        x = 0f; y = 0f
                    }) {
                        AsyncImage(photo.uri, photo.name, Modifier.fillMaxSize().padding(if (selected) 3.dp else 0.dp), contentScale = ContentScale.Crop)
                    }
                }
            }
        }
    }
}
