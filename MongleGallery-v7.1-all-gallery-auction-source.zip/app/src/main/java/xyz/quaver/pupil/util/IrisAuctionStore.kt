package xyz.quaver.pupil.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Metadata for user-selected images of non-person objects. Stores current values only. */
data class IrisAuctionRecord(
    val uri: String,
    val number: Int,
    val credits: Int = 320,
    val function: String = "",
    val status: String = "",
    val social: String = "",
    val legal: String = ""
)

object IrisAuctionStore {
    private fun prefs(c: Context) = c.getSharedPreferences("iris_auction_catalog_v1", Context.MODE_PRIVATE)

    fun list(c: Context): List<IrisAuctionRecord> {
        val raw = prefs(c).getString("records", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val o = array.getJSONObject(i)
                // Older versions used numeric "score" for information status. Preserve the
                // user's existing information value as editable status text on migration.
                val legacyStatuses = listOf("미등록", "기본 등록", "상세 등록", "지속 감시", "기록 말소")
                val status = if (o.has("status")) o.optString("status", "")
                    else legacyStatuses.getOrElse(o.optInt("score", 0)) { "" }
                IrisAuctionRecord(
                    uri = o.getString("uri"),
                    number = o.getInt("number"),
                    credits = o.optInt("credits", 320),
                    function = o.optString("function", ""),
                    status = status,
                    social = o.optString("social", ""),
                    legal = o.optString("legal", "")
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun save(c: Context, items: List<IrisAuctionRecord>) {
        val array = JSONArray()
        items.forEach { r ->
            array.put(JSONObject()
                .put("uri", r.uri).put("number", r.number).put("credits", r.credits)
                .put("function", r.function).put("status", r.status)
                .put("social", r.social).put("legal", r.legal))
        }
        prefs(c).edit().putString("records", array.toString()).apply()
    }

    /** Include all currently visible gallery media without resetting existing H numbers or edits. */
    fun syncGallery(c: Context, galleryUris: List<String>): List<IrisAuctionRecord> {
        val existing = list(c)
        val byUri = existing.associateBy { it.uri }
        var next = existing.maxOfOrNull { it.number } ?: 0
        val newItems = galleryUris.distinct().filterNot { byUri.containsKey(it) }.map { uri ->
            IrisAuctionRecord(uri = uri, number = ++next)
        }
        if (newItems.isNotEmpty()) save(c, existing + newItems)
        val available = galleryUris.toHashSet()
        return (existing + newItems).filter { it.uri in available }.sortedBy { it.number }
    }

    fun toggle(c: Context, uri: String): Boolean {
        val items = list(c).toMutableList()
        val existing = items.indexOfFirst { it.uri == uri }
        if (existing >= 0) {
            items.removeAt(existing)
            save(c, items)
            return false
        }
        val next = (items.maxOfOrNull { it.number } ?: 0) + 1
        items.add(IrisAuctionRecord(uri = uri, number = next))
        save(c, items)
        return true
    }

    fun update(c: Context, record: IrisAuctionRecord) {
        save(c, list(c).map { if (it.uri == record.uri) record else it })
    }

    fun contains(c: Context, uri: String): Boolean = list(c).any { it.uri == uri }
}


/** Shared user-authored option sets, independent of individual item values. */
object IrisAuctionOptions {
    val categories = listOf("function", "status", "social", "legal")
    private fun prefs(c: Context) = c.getSharedPreferences("iris_auction_options_v1", Context.MODE_PRIVATE)
    fun list(c: Context, category: String): List<String> {
        if (category !in categories) return emptyList()
        return runCatching {
            val a = JSONArray(prefs(c).getString(category, "[]") ?: "[]")
            (0 until a.length()).map { a.getString(it) }.filter { it.isNotBlank() }.distinct()
        }.getOrDefault(emptyList())
    }
    fun add(c: Context, category: String, value: String) {
        val v = value.trim()
        if (v.isNotEmpty()) save(c, category, list(c, category) + v)
    }
    fun rename(c: Context, category: String, old: String, replacement: String) {
        val v = replacement.trim()
        if (v.isEmpty() || category !in categories) return
        save(c, category, list(c, category).map { if (it == old) v else it })
        // Existing selections are migrated to the renamed option.
        IrisAuctionStore.list(c).forEach { record ->
            val updated = when (category) {
                "function" -> if (record.function == old) record.copy(function = v) else record
                "status" -> if (record.status == old) record.copy(status = v) else record
                "social" -> if (record.social == old) record.copy(social = v) else record
                else -> if (record.legal == old) record.copy(legal = v) else record
            }
            if (updated != record) IrisAuctionStore.update(c, updated)
        }
    }
    fun remove(c: Context, category: String, value: String) {
        save(c, category, list(c, category).filterNot { it == value })
        // Preserve current item values even when a reusable option is deleted.
    }
    private fun save(c: Context, category: String, values: List<String>) {
        if (category !in categories) return
        val a = JSONArray()
        values.distinct().forEach { a.put(it) }
        prefs(c).edit().putString(category, a.toString()).apply()
    }
}
