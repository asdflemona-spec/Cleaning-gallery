package xyz.quaver.pupil.ui.compose

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.graphics.nativeCanvas
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import xyz.quaver.pupil.util.IrisAuctionRecord
import xyz.quaver.pupil.util.IrisAuctionStore
import xyz.quaver.pupil.util.IrisAuctionOptions
import xyz.quaver.pupil.util.IrisGalleryIndex

private val fieldNames = mapOf("function" to "기능적", "status" to "상태적", "social" to "사회적", "legal" to "법적")

@Composable
private fun AuctionPreview(uri: String, modifier: Modifier = Modifier.size(100.dp)) {
    val context = LocalContext.current
    val video = remember(uri) {
        val parsed = Uri.parse(uri)
        parsed.path?.contains("/video/", ignoreCase = true) == true ||
            runCatching { context.contentResolver.getType(parsed)?.startsWith("video/") == true }.getOrDefault(false)
    }
    if (!video) {
        AsyncImage(model = uri, contentDescription = "경매 물품 사진", modifier = modifier, contentScale = ContentScale.Crop)
    } else {
        val bitmap by produceState<android.graphics.Bitmap?>(null, uri) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(context, Uri.parse(uri))
                        retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?: retriever.getFrameAtTime()
                    } finally { retriever.release() }
                }.getOrNull()
            }
        }
        Box(modifier.background(Color.DarkGray), contentAlignment = Alignment.Center) {
            bitmap?.let { Image(it.asImageBitmap(), "동영상 대표 화면", Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
            Text("▶", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        }
    }
}

@Composable
fun IrisHumanAuction(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    fun hasGalleryAccess(): Boolean = if (Build.VERSION.SDK_INT >= 33) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
    } else ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(hasGalleryAccess()) }
    var refresh by remember { mutableIntStateOf(0) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasGalleryAccess()
        refresh++
    }
    var records by remember { mutableStateOf<List<IrisAuctionRecord>>(emptyList()) }
    var scanning by remember { mutableStateOf(false) }
    LaunchedEffect(granted, refresh) {
        if (granted) {
            scanning = true
            records = withContext(Dispatchers.IO) {
                val gallery = runCatching { IrisGalleryIndex.scan(context) }.getOrDefault(emptyList())
                IrisAuctionStore.syncGallery(context, gallery.map { it.uri })
            }
            scanning = false
        } else records = emptyList()
    }
    var editing by remember { mutableStateOf<IrisAuctionRecord?>(null) }
    var managing by remember { mutableStateOf(false) }
    var decorating by remember { mutableStateOf<IrisAuctionRecord?>(null) }
    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("경매 물품", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = { refresh++ }, enabled = granted) { Text("새로고침") }
            TextButton(onClick = { managing = true }) { Text("속성 선택지 관리") }
        }
        if (!granted) {
            Column(Modifier.padding(16.dp)) {
                Text("갤러리 전체를 표시하려면 사진 및 동영상 접근 권한이 필요합니다.")
                Button(onClick = {
                    permissionLauncher.launch(if (Build.VERSION.SDK_INT >= 33)
                        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
                    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
                }) { Text("갤러리 접근 허용") }
            }
        } else if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth())
        else if (records.isEmpty()) Text("갤러리에 접근 가능한 사진이나 동영상이 없습니다.", Modifier.padding(16.dp))
        else Text("갤러리 물품 ${records.size}개", Modifier.padding(horizontal = 16.dp))
        LazyColumn(contentPadding = PaddingValues(8.dp)) {
            items(records, key = { it.uri }) { record ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { editing = record }) {
                    Row(Modifier.padding(12.dp)) {
                        AuctionPreview(record.uri)
                        Column(Modifier.padding(start = 12.dp)) {
                            Text("H-${record.number.toString().padStart(3, '0')}", style = MaterialTheme.typography.titleMedium)
                            Text("경제적 · ${record.credits} 크레딧")
                            Text("기능적 · ${record.function}")
                            Text("상태적 · ${record.status}")
                            Text("사회적 · ${record.social}")
                            Text("법적 · ${record.legal}")
                            TextButton(onClick = { decorating = record }) { Text("퍼즐 / 낙서") }
                        }
                    }
                }
            }
        }
    }
    decorating?.let { item -> AuctionMediaEditor(item.uri, onClose = { decorating = null }) }
    if (managing) OptionManager(onClose = { managing = false; records = IrisAuctionStore.list(context) })
    editing?.let { initial ->
        var credits by remember(initial.uri) { mutableStateOf(initial.credits.toString()) }
        var function by remember(initial.uri) { mutableStateOf(initial.function) }
        var status by remember(initial.uri) { mutableStateOf(initial.status) }
        var social by remember(initial.uri) { mutableStateOf(initial.social) }
        var legal by remember(initial.uri) { mutableStateOf(initial.legal) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("H-${initial.number.toString().padStart(3, '0')} 속성 선택") },
            text = {
                Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                    OutlinedTextField(credits, { credits = it.filter(Char::isDigit).take(8) }, label = { Text("경제적 · 크레딧") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    AuctionOptionPicker("function", function) { function = it }
                    AuctionOptionPicker("status", status) { status = it }
                    AuctionOptionPicker("social", social) { social = it }
                    AuctionOptionPicker("legal", legal) { legal = it }
                    Text("선택지는 모든 경매 물품에서 공유됩니다.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    IrisAuctionStore.update(context, initial.copy(
                        credits = credits.toIntOrNull() ?: 0,
                        function = function, status = status, social = social, legal = legal
                    ))
                    records = records.map { if (it.uri == initial.uri) initial.copy(credits = credits.toIntOrNull() ?: 0, function = function, status = status, social = social, legal = legal) else it }
                    editing = null
                }) { Text("저장") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("취소") } }
        )
    }
}

@Composable
private fun AuctionOptionPicker(category: String, selected: String, onSelect: (String) -> Unit) {
    val context = LocalContext.current
    var options by remember(category) { mutableStateOf(IrisAuctionOptions.list(context, category)) }
    var expanded by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text("${fieldNames[category]} 속성", style = MaterialTheme.typography.labelLarge)
        Box {
            OutlinedButton(onClick = { options = IrisAuctionOptions.list(context, category); expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected.ifBlank { "선택하세요" }, modifier = Modifier.weight(1f))
                Text("⌄")
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                DropdownMenuItem(text = { Text("선택 안 함") }, onClick = { onSelect(""); expanded = false })
                options.forEach { value ->
                    DropdownMenuItem(text = { Text(value) }, onClick = { onSelect(value); expanded = false })
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(draft, { draft = it }, label = { Text("새 선택지 입력") }, singleLine = true, modifier = Modifier.weight(1f))
            TextButton(onClick = {
                if (draft.isNotBlank()) {
                    IrisAuctionOptions.add(context, category, draft)
                    options = IrisAuctionOptions.list(context, category)
                    onSelect(draft.trim())
                    draft = ""
                }
            }) { Text("추가") }
        }
    }
}

@Composable
private fun OptionManager(onClose: () -> Unit) {
    val context = LocalContext.current
    var revision by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("공통 속성 선택지 관리") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                fieldNames.forEach { (category, name) ->
                    key(category, revision) {
                        var draft by remember { mutableStateOf("") }
                        Text("$name 속성", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 12.dp))
                        IrisAuctionOptions.list(context, category).forEach { option ->
                            var rename by remember(option) { mutableStateOf(option) }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(rename, { rename = it }, modifier = Modifier.weight(1f), singleLine = true)
                                TextButton(onClick = {
                                    IrisAuctionOptions.rename(context, category, option, rename)
                                    revision++
                                }) { Text("수정") }
                                TextButton(onClick = {
                                    IrisAuctionOptions.remove(context, category, option)
                                    revision++
                                }) { Text("삭제") }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(draft, { draft = it }, label = { Text("새 선택지") }, modifier = Modifier.weight(1f), singleLine = true)
                            TextButton(onClick = {
                                IrisAuctionOptions.add(context, category, draft)
                                revision++
                            }) { Text("추가") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("완료") } }
    )
}

/** Current-only media state: independent puzzle boards and vector annotations per item. */
private object AuctionMediaState {
    private fun prefs(c: android.content.Context) = c.getSharedPreferences("iris_auction_media_v2", android.content.Context.MODE_PRIVATE)
    private fun key(uri: String) = uri.hashCode().toString() + "_" + uri.length
    fun board(c: android.content.Context, uri: String, mode: String, n: Int): List<Int> {
        val saved = prefs(c).getString("board_${mode}_${n}_" + key(uri), null)
        val parsed = runCatching { JSONArray(saved).let { a -> (0 until a.length()).map { a.getInt(it) } } }.getOrNull()
        return if (parsed?.size == n*n && parsed.toSet().size == n*n && parsed.all { it in 0 until n*n }) parsed else (0 until n*n).toList()
    }
    fun saveBoard(c: android.content.Context, uri: String, mode: String, n: Int, b: List<Int>) =
        prefs(c).edit().putString("board_${mode}_${n}_" + key(uri), JSONArray(b).toString()).apply()
    fun revealed(c: android.content.Context, uri: String, n: Int): Set<Int> =
        prefs(c).getStringSet("tiles_${n}_" + key(uri), emptySet())?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()
    fun saveRevealed(c: android.content.Context, uri: String, n: Int, v: Set<Int>) =
        prefs(c).edit().putStringSet("tiles_${n}_" + key(uri), v.map(Int::toString).toSet()).apply()
    data class Stroke(val points: List<Offset>, val color: Long, val width: Float, val tool: String)
    fun strokes(c: android.content.Context, uri: String): List<Stroke> = runCatching {
        val a = JSONArray(prefs(c).getString("draw_" + key(uri), "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val pts = o.getJSONArray("points")
            Stroke((0 until pts.length()).map { j -> val xy=pts.getJSONArray(j); Offset(xy.getDouble(0).toFloat(), xy.getDouble(1).toFloat()) },
                o.optLong("color", 0xffff0000L), o.optDouble("width", 6.0).toFloat(), o.optString("tool", "pen"))
        }
    }.getOrDefault(emptyList())
    fun saveStrokes(c: android.content.Context, uri: String, strokes: List<Stroke>) {
        val a = JSONArray()
        strokes.forEach { s ->
            val pts=JSONArray(); s.points.forEach { pts.put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble())) }
            a.put(JSONObject().put("points", pts).put("color", s.color).put("width", s.width.toDouble()).put("tool", s.tool))
        }
        prefs(c).edit().putString("draw_" + key(uri), a.toString()).apply()
    }
}

@Composable
private fun AuctionMediaEditor(uri: String, onClose: () -> Unit) {
    val context=LocalContext.current
    var mode by remember(uri) { mutableStateOf("reveal") }
    var n by remember(uri) { mutableIntStateOf(4) }
    var revealed by remember(uri,n) { mutableStateOf(AuctionMediaState.revealed(context,uri,n)) }
    var strokes by remember(uri) { mutableStateOf(AuctionMediaState.strokes(context,uri)) }
    var redo by remember(uri) { mutableStateOf(emptyList<AuctionMediaState.Stroke>()) }
    var active by remember(uri) { mutableStateOf<List<Offset>>(emptyList()) }
    var tool by remember { mutableStateOf("pen") }
    var color by remember { mutableStateOf(0xffff1744L) }
    var width by remember { mutableFloatStateOf(6f) }
    val bitmap by produceState<android.graphics.Bitmap?>(null,uri) {
        value=withContext(Dispatchers.IO) { runCatching {
            val u=Uri.parse(uri)
            if (context.contentResolver.getType(u)?.startsWith("video/")==true || u.path?.contains("/video/")==true) {
                val r=MediaMetadataRetriever(); try { r.setDataSource(context,u); r.getFrameAtTime(0L) } finally { r.release() }
            } else context.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it) }
        }.getOrNull() }
    }
    AlertDialog(onDismissRequest=onClose, title={ Text("물품 · 퍼즐 / 낙서") }, text={
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                listOf("reveal" to "공개", "draw" to "낙서").forEach { (id,label) ->
                    FilterChip(selected=mode==id,onClick={mode=id},label={Text(label)})
                }
            }
            if(mode!="draw") {
                Row { listOf(3,4,6).forEach { size -> FilterChip(selected=n==size,onClick={n=size},label={Text("${size}×${size}")},modifier=Modifier.padding(end=5.dp)) } }
            } else {
                Row { listOf("pen" to "펜", "highlighter" to "형광", "eraser" to "지우개", "line" to "직선", "mosaic" to "모자이크").forEach { (id,label) ->
                    FilterChip(selected=tool==id,onClick={tool=id},label={Text(label)},modifier=Modifier.padding(end=3.dp))
                } }
                Row { listOf(0xffff1744L,0xff2196f3L,0xff4caf50L,0xffffc107L,0xff000000L,0xffffffffL).forEach { c ->
                    Box(Modifier.padding(3.dp).size(if(color==c) 29.dp else 25.dp).background(Color(c),androidx.compose.foundation.shape.CircleShape).clickable {color=c})
                } }
                Text(if(tool=="mosaic") "모자이크 크기 ${width.toInt()}" else "굵기 ${width.toInt()}")
                Slider(value=width,onValueChange={width=it},valueRange=2f..32f)
            }
            Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Color.DarkGray)) {
                AuctionPreview(uri,Modifier.fillMaxSize())
                if(mode=="reveal") {
                    Column(Modifier.fillMaxSize()) { repeat(n) { row ->
                        Row(Modifier.weight(1f)) { repeat(n) { col -> val idx=row*n+col
                            Box(Modifier.weight(1f).fillMaxHeight().padding(0.5.dp)
                                .background(if(idx in revealed) Color.Transparent else Color(0xff263238))
                                .clickable { revealed=revealed+idx; AuctionMediaState.saveRevealed(context,uri,n,revealed) })
                        } }
                    } }
                } else {
                    Canvas(Modifier.fillMaxSize()) {
                        (strokes + if(active.isNotEmpty()) listOf(AuctionMediaState.Stroke(active,color,width,tool)) else emptyList()).forEach { s ->
                            if(s.points.isNotEmpty()) {
                                val path=Path().apply { moveTo(s.points.first().x*size.width,s.points.first().y*size.height)
                                    if(s.tool=="line") lineTo(s.points.last().x*size.width,s.points.last().y*size.height)
                                    else s.points.drop(1).forEach { lineTo(it.x*size.width,it.y*size.height) } }
                                if (s.tool == "mosaic") {
                                    // Sample the original media frame into coarse colored squares along the brush path.
                                    // Stroke positions are normalized, so mosaics persist across screen sizes.
                                    val image = bitmap
                                    if (image != null) {
                                        val block = (s.width.dp.toPx() * 0.48f).coerceAtLeast(6f)
                                        val radius = s.width.dp.toPx().coerceAtLeast(block)
                                        val sampled = mutableSetOf<Pair<Int, Int>>()
                                        val coords = s.points.flatMapIndexed { index, point ->
                                            val prev = s.points.getOrElse(index - 1) { point }
                                            val distance = kotlin.math.hypot((point.x-prev.x)*size.width, (point.y-prev.y)*size.height)
                                            val count = (distance / (block / 2f)).toInt().coerceIn(1, 200)
                                            (0..count).map { t ->
                                                val f = t.toFloat()/count
                                                Offset((prev.x+(point.x-prev.x)*f)*size.width, (prev.y+(point.y-prev.y)*f)*size.height)
                                            }
                                        }
                                        coords.forEach { point ->
                                            val x0 = kotlin.math.floor((point.x-radius/2f)/block).toInt()
                                            val x1 = kotlin.math.floor((point.x+radius/2f)/block).toInt()
                                            val y0 = kotlin.math.floor((point.y-radius/2f)/block).toInt()
                                            val y1 = kotlin.math.floor((point.y+radius/2f)/block).toInt()
                                            for (gx in x0..x1) for (gy in y0..y1) {
                                                if (!sampled.add(gx to gy)) continue
                                                val px = (gx+0.5f)*block; val py = (gy+0.5f)*block
                                                if (px !in 0f..size.width || py !in 0f..size.height) continue
                                                // AuctionPreview uses Crop: reproduce its center-crop sampling.
                                                val scale = maxOf(size.width/image.width, size.height/image.height)
                                                val srcX = ((px-(size.width-image.width*scale)/2f)/scale).toInt().coerceIn(0,image.width-1)
                                                val srcY = ((py-(size.height-image.height*scale)/2f)/scale).toInt().coerceIn(0,image.height-1)
                                                drawRect(Color(image.getPixel(srcX,srcY)), Offset(gx*block,gy*block), androidx.compose.ui.geometry.Size(block+0.5f,block+0.5f))
                                            }
                                        }
                                    }
                                } else {
                                    drawPath(path,if(s.tool=="eraser") Color.Black else Color(s.color).copy(alpha=if(s.tool=="highlighter") .3f else 1f),
                                        style=Stroke(width=s.width.dp.toPx(),cap=androidx.compose.ui.graphics.StrokeCap.Round))
                                }
                            }
                        }
                    }
                    Box(Modifier.fillMaxSize().pointerInput(uri,tool,color,width) {
                        detectDragGestures(onDragStart={p->active=listOf(Offset((p.x/size.width).coerceIn(0f,1f),(p.y/size.height).coerceIn(0f,1f)))},
                            onDrag={change,_->active=active+Offset((change.position.x/size.width).coerceIn(0f,1f),(change.position.y/size.height).coerceIn(0f,1f));change.consume()},
                            onDragEnd={if(active.isNotEmpty()) { strokes=strokes+AuctionMediaState.Stroke(active,color,width,tool);redo=emptyList();AuctionMediaState.saveStrokes(context,uri,strokes) };active=emptyList()},
                            onDragCancel={active=emptyList()})
                    })
                }
            }
            if(mode=="reveal") Row {
                TextButton(onClick={revealed=emptySet();AuctionMediaState.saveRevealed(context,uri,n,revealed)}) {Text("다시 가리기")}
                TextButton(onClick={revealed=(0 until n*n).toSet();AuctionMediaState.saveRevealed(context,uri,n,revealed)}) {Text("전체 공개")}
            } else Row {
                TextButton(onClick={if(strokes.isNotEmpty()){redo=redo+strokes.last();strokes=strokes.dropLast(1);AuctionMediaState.saveStrokes(context,uri,strokes)}}) {Text("취소")}
                TextButton(onClick={if(redo.isNotEmpty()){strokes=strokes+redo.last();redo=redo.dropLast(1);AuctionMediaState.saveStrokes(context,uri,strokes)}}) {Text("다시 실행")}
                TextButton(onClick={strokes=emptyList();redo=emptyList();AuctionMediaState.saveStrokes(context,uri,strokes)}) {Text("전체 삭제")}
            }
            Text("물품별 현재 상태만 저장하며 원본 파일은 변경하지 않습니다.",style=MaterialTheme.typography.bodySmall)
        }
    },confirmButton={TextButton(onClick=onClose){Text("완료")}})
}
