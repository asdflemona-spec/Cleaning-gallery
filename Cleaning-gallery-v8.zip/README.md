# Cleaning Gallery v8 — Constraint-first Interactive Clustering

설계 근거는 기존 성공 계열에 한정한다.

- COBRA / COBRAS: 먼저 보수적으로 over-clustering하여 super-instance를 만들고 사용자 질의로 구조를 수정한다.
- COP-KMeans 계열: 사용자 `같음`은 Must-Link, `다름`은 Cannot-Link라는 명시적 제약으로 취급한다.
- MPCK-Means 계열: 제약조건과 learned metric을 함께 사용하되, 제약조건이 최종 군집 경계에서 우선한다.

## v8 동작
1. 보호되지 않은 사진의 기존 시각/pose/body 특징을 추출한다.
2. 매우 보수적인 거리 기준으로 작은 super-instance들을 만든다(over-clustering).
3. `같은 유형` 피드백은 Must-Link로 영구 저장한다.
4. `다른 유형` 피드백은 Cannot-Link로 영구 저장한다.
5. Must-Link는 전이적으로 super-instance를 합친다.
6. Cannot-Link가 존재하는 두 군집은 경계 질문/합병 후보에서 제외한다.
7. learned metric은 active query 우선순위와 아직 질문하지 않은 관계의 보조 신호로만 쓴다.
8. 군집 수 K를 미리 지정하지 않는다.

이 구조의 핵심은 metric collapse가 발생해도 사용자 Cannot-Link를 무시하고 모든 사진이 한 군집으로 합쳐질 수 없게 하는 것이다.
