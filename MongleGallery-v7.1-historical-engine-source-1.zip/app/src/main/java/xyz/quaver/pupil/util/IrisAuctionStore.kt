package xyz.quaver.pupil.util

import android.content.Context
import org.json.JSONObject

/** Fictional catalogue metadata; never a statement about any person's actual status. */
data class IrisAuctionRecord(val uri:String, val number:Int, val credits:Int=320, val function:String="미분류", val score:Int=0, val social:String="등급 외", val legal:String="권리 인정")

object IrisAuctionStore {
    private fun prefs(c:Context)=c.getSharedPreferences("iris_auction_catalog_v1",Context.MODE_PRIVATE)
    fun list(c:Context):List<IrisAuctionRecord> {
        val raw=prefs(c).getString("records","[]") ?: "[]"
        return runCatching {
            val arr=org.json.JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o=arr.getJSONObject(i)
                IrisAuctionRecord(o.getString("uri"),o.getInt("number"),o.optInt("credits",320),o.optString("function","미분류"),o.optInt("score",0),o.optString("social","등급 외"),o.optString("legal","권리 인정"))
            }
        }.getOrDefault(emptyList())
    }
    private fun save(c:Context,items:List<IrisAuctionRecord>){
        val a=org.json.JSONArray()
        items.forEach { r -> a.put(JSONObject().put("uri",r.uri).put("number",r.number).put("credits",r.credits).put("function",r.function).put("score",r.score).put("social",r.social).put("legal",r.legal)) }
        prefs(c).edit().putString("records",a.toString()).apply()
    }
    fun toggle(c:Context,uri:String):Boolean {
        val items=list(c).toMutableList(); val old=items.indexOfFirst { it.uri==uri }
        if(old>=0){items.removeAt(old);save(c,items);return false}
        val next=(items.maxOfOrNull { it.number } ?: 0)+1
        items.add(IrisAuctionRecord(uri,next));save(c,items);return true
    }
    fun update(c:Context,r:IrisAuctionRecord){save(c,list(c).map { if(it.uri==r.uri)r else it })}
    fun contains(c:Context,uri:String)=list(c).any { it.uri==uri }
}
