package xyz.quaver.pupil.util

/** Transparent rule-based historical comparison, not a claim that an image depicts a person. */
object IrisHistoricalEngine {
    data class Finding(val heading:String,val historical:String,val outcome:String,val source:String,val sourceUrl:String)
    private val sources=listOf(
        "Encyclopaedia Britannica — Slavery" to "https://www.britannica.com/topic/slavery-sociology",
        "Encyclopaedia Britannica — Manumission" to "https://www.britannica.com/topic/manumission",
        "International Labour Organization — Forced labour" to "https://www.ilo.org/topics/forced-labour",
        "United Nations — Slavery Convention (1926)" to "https://www.ohchr.org/en/instruments-mechanisms/instruments/slavery-convention",
        "United Nations — Universal Declaration of Human Rights" to "https://www.un.org/en/about-us/universal-declaration-of-human-rights"
    )
    fun evaluate(section:Int,stage:Int,r:IrisAuctionRecord):Finding {
        val monitored=r.score>=3
        val registered=r.score in 1..3
        val subordinated=r.social=="종속층" || r.social=="배제층"
        val restricted=r.legal=="권리 제한" || r.legal=="타인의 지배 아래 놓인 지위" || r.legal=="법적 보호 배제"
        val liberated=r.legal=="해방" || r.legal=="권리 인정"
        val sexual=r.function.contains("성적")
        val controlled= (if(monitored) 2 else if(registered) 1 else 0)+(if(subordinated) 2 else 0)+(if(restricted) 2 else 0)
        val tier=when { controlled>=5->"높음";controlled>=3->"중간";else->"낮음" }
        fun finding(title:String,historical:String,result:String,sourceIndex:Int):Finding {
            val s=sources[sourceIndex]
            return Finding(title,historical,result,s.first,s.second)
        }
        return if(section==1) when(stage) {
            0->finding("등록과 감시","노예제와 강제노동 체제에서는 명부, 신분 구분, 이동 통제 등이 사람을 관리하는 수단으로 사용되었습니다.","정보 상태: ${listOf("미등록","기본 등록","상세 등록","지속 감시","기록 말소").getOrElse(r.score){"미등록"}}. 감시 규칙: ${if(monitored) "활성" else "비활성"}. 제도 통제 지수: $controlled/6 ($tier).",2)
            1->finding("신분 서열","역사적 신분제와 노예제는 법적·사회적 지위에 따라 자원 접근과 이동의 자유를 차등화했습니다.","분류: ${r.social}. 종속 규칙: ${if(subordinated) "적용" else "미적용"}. 통제 지수: $controlled/6.",0)
            2->finding("상품화","노예제는 인간을 재산처럼 취급하고 거래 대상으로 만든 제도였습니다. 이 비교는 그 구조를 비판적으로 설명합니다.","가상 표기액: ${r.credits} CR. ${if(restricted) "권리 제한과 교환가치 부여가 결합된 설정" else "권리 인정 상태에서 임의 가격만 부여된 모순 설정"}. 실제 거래 기능 없음.",3)
            3->finding("강제된 역할","강제노동은 처벌의 위협 아래 비자발적으로 제공되는 노동을 포함합니다. 성적 착취는 별도의 역사적 폭력 맥락에서 다뤄야 합니다.","설정된 기능: ${r.function}. ${if(sexual) "성적 착취 제도 관련 해설 대상" else "노동·역할 분류 해설 대상"}. 강제성 조건(권리 제한+종속): ${if(restricted&&subordinated) "충족" else "미충족"}.",2)
            else->finding("제도적 처우","법적 권리의 부정, 이동 제한, 감시, 종속적 지위는 서로 결합하여 강제력을 강화했습니다.","법적 상태: ${r.legal}; 사회적 상태: ${r.social}; 통제 지수: $controlled/6 ($tier). ${if(liberated) "권리 보호 시나리오 우선" else "권리 침해 시나리오 활성"}.",3)
        } else when(stage) {
            0->finding("이미지와 분류","역사 자료의 사진·명부·문서는 당시 제도가 대상을 어떻게 기록하고 구분했는지 보여 줍니다. 이미지 자체가 역사적 피해자를 뜻하지는 않습니다.","H-${r.number.toString().padStart(3,'0')} 이미지 참조 연결. 정보 분류 단계 ${r.score}/4, 감시 규칙 ${if(monitored) "활성" else "비활성"}.",0)
            1->finding("경제적 가치 부여","노예제에서 사람의 상품화는 인간의 자유와 권리를 침해하는 핵심 구조였습니다.","가상 평가액 ${r.credits} CR; ${if(restricted) "권리 제한과 상품화 결합" else "권리 보호 상태와 상품화 표기의 충돌"}. 구매·판매는 실행하지 않습니다.",3)
            2->finding("강제와 동의","국제노동기구의 강제노동 개념은 비자발성과 처벌의 위협을 중심으로 합니다. 성적 착취의 역사적 사례에는 강제와 권리 침해가 수반됩니다.","역할 ${r.function}; 권리 ${r.legal}. 제도적 취약성: ${if(restricted&&subordinated) "높음" else if(restricted||subordinated) "중간" else "낮음"}. 이는 입력 속성에 대한 규칙 결과이지 역사적 사건의 판정이 아닙니다.",2)
            else->finding("해방과 권리 회복","노예 해방과 인권 보장의 역사는 소유·통제 관계의 해체 및 법적 인격과 자유의 회복을 포함합니다.","현재 ${r.legal}. ${if(liberated) "권리 회복 조건 충족: 강제 통제 해제 시나리오" else "권리 회복 조건 미충족: 법적 상태를 '해방' 또는 '권리 인정'으로 변경하면 결과가 전환됩니다"}.",if(liberated) 4 else 1)
        }
    }
}
