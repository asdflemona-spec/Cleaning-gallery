package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import xyz.quaver.pupil.util.IrisAuctionRecord
import xyz.quaver.pupil.util.IrisAuctionStore
import xyz.quaver.pupil.util.IrisHistoricalEngine
import androidx.compose.ui.platform.LocalUriHandler

@Composable
fun IrisHumanAuction(modifier:Modifier=Modifier){
    val context=LocalContext.current
    var records by remember { mutableStateOf(IrisAuctionStore.list(context)) }
    var editing by remember { mutableStateOf<IrisAuctionRecord?>(null) }
    var section by remember { mutableStateOf(0) }
    Column(modifier){
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)) {
            FilterChip(section==0,{section=0},label={Text("추천 자료")})
            Spacer(Modifier.width(8.dp))
            FilterChip(section==1,{section=1},label={Text("제도 전시")})
            Spacer(Modifier.width(8.dp))
            FilterChip(section==2,{section=2},label={Text("구조 분석")})
        }
        if(section==1 || section==2){
            HistoricalInteractiveSection(section,records)
        } else {
        Text("H-Series · 역사 기반 가상 제도 모델",style=MaterialTheme.typography.titleMedium,modifier=Modifier.padding(16.dp))
        Text("실제 인물의 거래·법적 지위를 나타내지 않는 사용자 지정 분류입니다.",modifier=Modifier.padding(horizontal=16.dp))
        LazyColumn { items(records,key={it.uri}) { r ->
            Card(Modifier.fillMaxWidth().padding(8.dp).clickable { editing=r }) {
                Row(Modifier.padding(12.dp)) {
                    AsyncImage(model=r.uri,contentDescription="추천 사진",modifier=Modifier.size(100.dp))
                    Column(Modifier.padding(start=12.dp)) {
                        Text("H-${r.number.toString().padStart(3,'0')}",style=MaterialTheme.typography.titleMedium)
                        Text("경제적 · ${r.credits} 크레딧")
                        Text("기능적 · ${r.function}")
                        Text("정보적 · ${informationOptions.getOrElse(r.score) { informationOptions[0] }}")
                        Text("사회적 · ${r.social}")
                        Text("법적 · ${r.legal}")
                    }
                }
            }
        } }
        }
    }
    editing?.let { initial ->
        var credits by remember(initial.uri) { mutableStateOf(initial.credits.toString()) }
        var function by remember(initial.uri) { mutableStateOf(initial.function) }
        var info by remember(initial.uri) { mutableStateOf(informationOptions.getOrElse(initial.score) { informationOptions[0] }) }
        var social by remember(initial.uri) { mutableStateOf(initial.social) }
        var legal by remember(initial.uri) { mutableStateOf(initial.legal) }
        AlertDialog(onDismissRequest={editing=null},title={Text("H-${initial.number.toString().padStart(3,'0')} 속성 편집")},text={
            Column {
                Text("경제적 속성 (가상 크레딧)")
                OutlinedTextField(credits,{credits=it.filter(Char::isDigit).take(8)},label={Text("크레딧")},singleLine=true)
                Text("기능적 속성")
                AttributeSelector(function,functionOptions){function=it}
                Text("정보적 속성 · 역사적 등록·감시 제도")
                AttributeSelector(info,informationOptions){info=it}
                Text("사회적 속성")
                AttributeSelector(social,socialOptions){social=it}
                Text("법적 속성 (가상 세계관 설정)")
                AttributeSelector(legal,legalOptions){legal=it}
            }
        },confirmButton={TextButton(onClick={
            IrisAuctionStore.update(context,initial.copy(credits=credits.toIntOrNull()?:0,function=function,score=informationOptions.indexOf(info).coerceAtLeast(0),social=social,legal=legal))
            records=IrisAuctionStore.list(context);editing=null
        }){Text("저장")}},dismissButton={TextButton(onClick={editing=null}){Text("취소")}})
    }
}

@Composable private fun AttributeSelector(value:String,choices:List<String>,onChange:(String)->Unit){
    var expanded by remember { mutableStateOf(false) }
    Box { TextButton(onClick={expanded=true}){Text("$value ▾")}
        DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
            choices.forEach { option -> DropdownMenuItem(text={Text(option)},onClick={onChange(option);expanded=false}) }
        }
    }
}


/** Historical analytical categories; applying them to objects is fictional, not a historical claim. */
private val functionOptions=listOf("가사노동","생산노동","접객","강제적 성적 이용에 관한 제도 분류","미분류")
private val informationOptions=listOf("미등록","기본 등록","상세 등록","지속 감시","기록 말소")
private val socialOptions=listOf("특권층","일반층","종속층","배제층","등급 외")
private val legalOptions=listOf("권리 인정","권리 제한","타인의 지배 아래 놓인 지위","법적 보호 배제","해방")

@Composable
private fun HistoricalInteractiveSection(section:Int,records:List<IrisAuctionRecord>){
    var selectedUri by remember { mutableStateOf<String?>(null) }
    var stage by remember(section) { mutableIntStateOf(0) }
    val uriHandler=LocalUriHandler.current
    val current=records.firstOrNull { it.uri==selectedUri } ?: records.firstOrNull()
    val stages=if(section==1) listOf("정보화","서열화","상품화","도구화","제도적 처우")
        else listOf("시각적 소비","상업적 소비","강제적 이용","권리 회복")
    LazyColumn(contentPadding=PaddingValues(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text(if(section==1) "제도 전시 · 작동형 역사 분석" else "구조 분석 · 작동형 역사 분석",style=MaterialTheme.typography.titleMedium) }
        if(records.isEmpty()) {
            item { Text("추천 자료가 없습니다. 갤러리에서 ♥ 추천을 등록하세요.") }
        } else {
            item { Text("분석 대상 선택",style=MaterialTheme.typography.titleSmall) }
            items(records,key={"select_"+it.uri}) { r ->
                FilterChip(selected=current?.uri==r.uri,onClick={selectedUri=r.uri},label={Text("H-${r.number.toString().padStart(3,'0')}")})
            }
            item {
                current?.let { r ->
                    Row {
                        AsyncImage(model=r.uri,contentDescription="추천 이미지",modifier=Modifier.size(92.dp))
                        Column(Modifier.padding(start=12.dp)) {
                            Text("H-${r.number.toString().padStart(3,'0')}",style=MaterialTheme.typography.titleMedium)
                            Text("${r.credits} CR · ${r.social}")
                            Text("${r.function} · ${r.legal}")
                        }
                    }
                }
            }
            items(stages.size) { i ->
                OutlinedCard(onClick={stage=i},modifier=Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("${i+1}. ${stages[i]} ${if(stage==i) "●" else ""}",style=MaterialTheme.typography.titleSmall)
                        if(stage==i && current!=null){
                            Spacer(Modifier.height(8.dp))
                            val finding=IrisHistoricalEngine.evaluate(section,i,current)
                            Text(finding.heading,style=MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(6.dp))
                            Text("역사적 근거: ${finding.historical}")
                            Spacer(Modifier.height(6.dp))
                            Text("현재 객체의 계산 결과: ${finding.outcome}")
                            TextButton(onClick={uriHandler.openUri(finding.sourceUrl)}) { Text("출처: ${finding.source} ↗") }
                            Text("자연물·인공물에 대한 가상 규칙 분석이며 실제 역사적 인물 판정이 아닙니다.",style=MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

