# Cleaning Gallery v9.4

## UI
- Hierarchy: grade folders → cluster folders → photo grid.
- Cluster folders use their representative image as a cover.
- Long-press enters multi-select mode; subsequent taps toggle selection.
- Select-all toggle and selected-count trash button.

## Real gallery folders
The optional `갤러리에 폴더 적용` action requests Android batch write consent, then moves media by updating `MediaStore.MediaColumns.RELATIVE_PATH` into:
`Pictures/CleaningGallery/<GRADE>/Cluster_NNN/`.

This physically reorganizes the shared-media paths, so gallery apps that group albums by folder can display the classification. It is intentionally opt-in because it moves the original files.

## Existing behavior
- Evidence-layered morphology scoring from v9.3.
- Relative S/A/B/C/D grading.
- Android MediaStore trash confirmation and RESULT_OK handling.
