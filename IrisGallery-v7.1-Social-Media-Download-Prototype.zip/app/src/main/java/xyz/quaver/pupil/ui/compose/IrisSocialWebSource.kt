package xyz.quaver.pupil.ui.compose

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray

/** User-initiated downloads only. Credentials are handled by the first-party site, never by Iris. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun IrisSocialWebSource(service: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val isX = service == "x"
    val home = if (isX) "https://x.com/" else "https://www.pinterest.com/"
    val login = if (isX) "https://x.com/i/flow/login" else "https://www.pinterest.com/login/"
    var webView by remember(service) { mutableStateOf<WebView?>(null) }
    var currentUrl by remember(service) { mutableStateOf(home) }
    var canBack by remember(service) { mutableStateOf(false) }
    var candidates by remember(service) { mutableStateOf<List<String>>(emptyList()) }
    var showPicker by remember(service) { mutableStateOf(false) }

    fun offer(url: String?) {
        if (url != null && (url.startsWith("https://") || url.startsWith("http://"))) {
            candidates = listOf(url)
            showPicker = true
        } else Toast.makeText(context, "직접 저장 가능한 미디어 주소가 없습니다.", Toast.LENGTH_SHORT).show()
    }

    DisposableEffect(service) {
        onDispose {
            webView?.stopLoading()
            webView?.destroy()
            webView = null
        }
    }
    BackHandler(canBack) { webView?.goBack() }
    Column(modifier) {
        Text(if (isX) "X" else "Pinterest", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        Text("사진 길게 누르기 또는 '미디어 찾기'로 선택 후 저장. 로그인 정보는 해당 사이트에만 입력합니다.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { webView?.loadUrl(home) }) { Text("홈") }
            TextButton(onClick = { webView?.loadUrl(login) }) { Text("로그인") }
            TextButton(onClick = { webView?.reload() }) { Text("새로고침") }
            TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))) }) { Text("브라우저") }
        }
        Button(onClick = {
            // Read visible page media attributes only on explicit user action.
            // No page HTML, cookies or credentials are sent to Iris servers.
            val script = """(function(){var els=document.querySelectorAll('img,video,video source');var out=[];for(var i=0;i<els.length;i++){var e=els[i];var u=e.currentSrc||e.src||e.getAttribute('src');if(u&&(u.indexOf('https://')===0||u.indexOf('http://')===0)&&out.indexOf(u)<0){out.push(u);}}return JSON.stringify(out.slice(0,80));})()"""
            webView?.evaluateJavascript(script) { encoded ->
                try {
                    val decoded = JSONArray("[$encoded]").getString(0)
                    val arr = JSONArray(decoded)
                    candidates = (0 until arr.length()).map { arr.getString(it) }.filter { it.startsWith("https://") }.distinct()
                    if (candidates.isNotEmpty()) showPicker = true
                    else Toast.makeText(context, "이 화면에서 직접 저장 가능한 미디어를 찾지 못했습니다.", Toast.LENGTH_LONG).show()
                } catch (_: Exception) {
                    Toast.makeText(context, "미디어 검색에 실패했습니다.", Toast.LENGTH_SHORT).show()
                }
            }
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)) { Text("현재 화면 미디어 찾기") }
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.setSupportMultipleWindows(false)
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            currentUrl = url ?: home
                            canBack = view?.canGoBack() == true
                        }
                    }
                    setOnLongClickListener {
                        val hit = hitTestResult
                        if (hit.type == WebView.HitTestResult.IMAGE_TYPE || hit.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                            offer(hit.extra)
                            true
                        } else false
                    }
                    setDownloadListener { url, _, _, _, _ -> offer(url) }
                    loadUrl(home)
                    webView = this
                }
            },
            update = { webView = it },
        )
    }
    if (showPicker) {
        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("미디어 다운로드") },
            text = {
                Column {
                    Text("발견 ${candidates.size}개. 직접 접근 가능한 이미지·동영상만 저장됩니다. 보호된 스트림(blob/HLS/DRM)은 지원하지 않습니다.")
                    candidates.take(12).forEachIndexed { index, url ->
                        TextButton(onClick = {
                            queueSocialDownload(context, url, if (isX) "X" else "Pinterest", currentUrl)
                            showPicker = false
                        }) { Text("${index + 1}. ${url.substringBefore('?').takeLast(65)}", maxLines = 2) }
                    }
                    if (candidates.size > 12) Text("처음 12개만 표시됩니다.")
                }
            },
            confirmButton = { TextButton(onClick = { showPicker = false }) { Text("닫기") } }
        )
    }
}

private fun queueSocialDownload(context: Context, url: String, service: String, referer: String) {
    try {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" || uri.host.isNullOrBlank()) throw IllegalArgumentException("HTTPS 주소만 지원")
        val name = URLUtil.guessFileName(url, null, null).take(100)
        val request = DownloadManager.Request(uri)
            .setTitle(name)
            .setDescription("IrisGallery $service")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_PICTURES, "Iris/$service/$name")
        CookieManager.getInstance().getCookie(url)?.let { request.addRequestHeader("Cookie", it) }
        if (referer.startsWith("https://")) request.addRequestHeader("Referer", referer)
        request.addRequestHeader("User-Agent", android.webkit.WebSettings.getDefaultUserAgent(context))
        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        Toast.makeText(context, "다운로드 대기열에 추가했습니다. 알림에서 결과를 확인하세요.", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "다운로드 요청 실패: ${e.message}", Toast.LENGTH_LONG).show()
    }
}
