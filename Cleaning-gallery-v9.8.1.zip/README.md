# Cleaning Gallery v9.5

Incremental persistent classification:
- Photo cache keyed by MediaStore ID.
- Cache validity checks DATE_MODIFIED + SIZE.
- Unchanged photos restore saved score, grade and stable cluster ID.
- New/modified photos alone run feature extraction.
- New/modified photos attach to the nearest existing cluster when within the existing threshold; otherwise a new cluster is created.
- Existing grades/clusters are not globally reshuffled on app restart.
- Protected IDs persist locally.
- Existing grade-folder → cluster-folder → grid UI and Galaxy Gallery folder export remain.

Android recommends resyncing cached MediaStore data when the media collection changes. v9.5 additionally checks per-photo modification metadata so unchanged items can reuse classification.

## v9.5.1 Samsung Gallery export
- Flattened exported cluster directories to `Pictures/CleaningGallery_<GRADE>_<STABLE_CLUSTER_ID>/`.
- Stable cluster IDs from v9.5 are reused, so incremental photos continue targeting the same physical album.
- After `RELATIVE_PATH` update, the app queries MediaStore again and reports both update count and verified-path count.
- A successful `update()` is no longer presented as proof that the requested path is actually stored.

## v9.5.2 selection UX fix
- Normal tap now immediately selects/deselects a photo.
- Multiple photos can be accumulated by repeated taps.
- Long press still enters explicit multi-select mode and selects the pressed photo.
- Selection does not collapse back to single-selection after the first item.
- Updated helper text and empty-selection warning.

## v9.6
- Grade is now a hard top-level grouping for incremental classification.
- New/modified photos receive a grade first and are compared only with clusters inside that grade.
- Removed long-press selection entirely; normal taps accumulate multiple selections.
- Replaced raw score-heavy labels with Korean natural-language explanations for grade meaning, cluster similarity, and representative-photo morphology.

## v9.6.1 simplified groups
- Removed the extra grade-folder navigation layer.
- Clusters are shown directly as S-001, S-002, A-001, etc.
- Gallery export uses the same album names directly under Pictures/.
- Explanations are compact feature tags only.

## v9.7 incremental scan + cropped-photo handling
- Added an explicit `추가 사진 확인` rescan from the group screen.
- MediaStore is queried again; cache misses/new IDs and modified-size/date changes are the only photos sent to incremental analysis.
- Existing cached photos keep their grade and cluster; incremental analysis does not call global relative grading.
- Body morphology is used only when both shoulder and hip geometry are visible with usable confidence.
- Cropped/partial photos are not penalized for missing body regions; grouping dynamically reweights toward visual, hash, aspect and available pose evidence.
- Compact explanation for partial images: `부분 구도 · 색감/구도/자세 유사도 중심`.

## v9.8 branding
- App display name: Gallery Cleaner
- Launcher icon: Twemoji Wizard character, CC BY 4.0, on a custom rounded background.
- Attribution: THIRD_PARTY_NOTICES.md

## v9.8.1 build fix
- Removed raw `.svg` from Android `res/drawable`; Android resource merger accepts the generated PNG launcher resources.
