# Cleaning Gallery v5 — Personalized Metric Learning MVP

v5 keeps the fixed product flow (protect -> cluster -> random representative -> whole cluster to OS trash), but replaces the fixed similarity weighting with a small on-device personalized metric head.

## Feedback
Long-press the representative to open Learning Inspector. Tap a member and label whether it is the same kind as the representative. The 7-dimensional distance weights update online and persist in SharedPreferences. "군집 대체로 맞음" adds positive pairs for the cluster.

## Metric inputs
1. rendered body geometry
2. pose
3. RGB histogram
4. dHash
5. aspect/composition
6. edge/texture
7. capture time

Cold-start weights emphasize body geometry. Feedback changes feature importance; low-confidence body/pose measurements are dynamically downweighted.

This is deliberately a small reversible MVP metric learner, not a pretrained universal attractiveness model.
