# Cleaning Gallery v9.3 — evidence-layered grading

The automatic grade is split into two layers.

## Morphology grade
Only image-observable morphology proxies can affect S/A/B/C/D:
- 45% apparent whole-body/torso mass-shape proxy
- 35% waist + multiple torso ratios
- 20% sexually dimorphic silhouette proxy

Low detection confidence shrinks morphology toward neutral. The app does not claim to infer true BMI, body fat, health, fertility, or a universal attractiveness value from a 2D image.

Grades remain relative within the eligible gallery:
S top 10%, A next 20%, B middle 40%, C next 20%, D bottom 10%.

## Presentation score
Pose and body occupancy are shown separately and do not raise the morphology grade. This prevents framing/cropping from being mistaken for body morphology.

## Rationale
The implementation follows the recurring findings that apparent overall mass/body composition, waist/body-shape information, and multiple interacting body ratios matter; it avoids treating WHR alone or a fixed 0.70 target as a universal law. Exact implementation weights are engineering priors, not literature-estimated universal coefficients.
