# IRIS PRIVÉ · Auction Catalogue update
- Restores TikTok / Instagram / Recap source tabs: TikTok and Instagram use folder path matching; Recap uses device favorites and Iris media. Other items are not falsely assigned.
- Video thumbnail extraction via ContentResolver.loadThumbnail (API 29+) and MediaStore fallback on older devices.
- Manual price tags retained, stored locally by media URI.
- Auction-inspired restrained lot grid and dark-gold icon. No bidding, purchase, or people trading.
- Real AI chat: optional user-provided OpenAI API key, direct HTTPS request, conversational history and visible errors. Never embeds a key in source. Only chat text is sent, not gallery media. Direct on-device key storage is not secure for production; use a backend proxy for public release. API usage may incur fees.
- Compilation and device execution NOT verified here.
