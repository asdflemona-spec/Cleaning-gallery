package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.LazyColumn
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import java.net.URL
import javax.net.ssl.HttpsURLConnection

private val black = Color(0xFF0B0B0C)
private val gold = Color(0xFFC2A785)
private val white = Color(0xFFEAE2D8)
private data class ChatLine(val mine: Boolean, val text: String)

@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("iris_secretary", 0) }
    var page by remember { mutableStateOf("Collection") }
    var category by remember { mutableStateOf("Instagram") }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(prefs.getString("model", "gpt-4.1-mini") ?: "gpt-4.1-mini") }
    val scope = rememberCoroutineScope()
    var waiting by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("All") }
    var draft by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(ChatLine(false, "안녕하세요. IRIS PRIVÉ 비서입니다. 가격표 작성, 컬렉션 이용법, 전시 문구를 도와드릴게요. 현재는 오프라인 기본 응답 모드입니다.")) }
    fun reply(q: String): String {
        val t = q.lowercase()
        return when {
            "가격" in t || "price" in t -> "Collection에서 사진이나 영상을 고른 뒤, 썸네일 아래 '+ 가격'을 누르면 원화 가격표를 직접 저장할 수 있습니다. 실제 거래 기능은 없습니다."
            "영상" in t || "비디오" in t -> "Collection에서 Videos를 선택하고 썸네일을 누르면 영상을 재생합니다."
            "사진" in t || "이미지" in t -> "Collection에서 Images를 선택하면 사진만 볼 수 있습니다."
            "문구" in t || "소개" in t -> "추천 전시 문구: '가장 사적인 취향에 붙인 가장 터무니없는 가격.'"
            "안녕" in t -> "어서 오세요. 오늘은 어떤 컬렉션을 정리해 드릴까요?"
            else -> "현재는 인터넷 AI가 연결되지 않은 기본 비서입니다. '가격', '사진', '영상', '전시 문구'를 물어보실 수 있어요. 자유 대화형 AI는 별도 모델 연결이 필요합니다."
        }
    }
    Column(Modifier.fillMaxSize().background(black)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("PRIVATE COLLECTION", color = gold, fontSize = 9.sp, letterSpacing = 2.sp)
                Text("IRIS PRIVÉ", color = white, fontSize = 27.sp, fontFamily = FontFamily.Serif)
            }
            Text("◇", color = gold, fontSize = 24.sp)
        }
        if (page == "Collection") {
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("TikTok", "Instagram", "Recap").forEach { c ->
                    Surface(Modifier.weight(1f).clickable { category = c }, color = if (category == c) gold else Color(0xFF30232A), shape = RoundedCornerShape(10.dp)) {
                        Text(c, Modifier.padding(vertical = 11.dp), color = if (category == c) black else white, fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
            Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(15.dp)) {
                listOf("All", "Images", "Videos").forEach { f ->
                    Text(f, Modifier.clickable { filter = f }.padding(7.dp), color = if (filter == f) gold else white, fontSize = 12.sp)
                }
            }
            IrisGallerySection(Modifier.weight(1f).padding(horizontal = 6.dp), category = category, mediaFilter = filter)
        } else {
            Text("PRIVATE SECRETARY", Modifier.padding(horizontal = 18.dp, vertical = 8.dp), color = gold, fontSize = 11.sp)
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (apiKey.isBlank()) "AI 미연결 · API 키 설정 필요" else "AI 연결 준비 · $model", color = white, fontSize = 11.sp)
                Text("설정 ⚙", Modifier.clickable { showSettings = true }, color = gold, fontSize = 12.sp)
            }
            androidx.compose.foundation.lazy.LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(messages.size) { i ->
                    val line = messages[i]
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.mine) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (line.mine) gold else Color(0xFF30232A), shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth(.87f)) {
                            Text(line.text, Modifier.padding(13.dp), color = if (line.mine) black else white, fontSize = 14.sp)
                        }
                    }
                }
            }
            if (waiting) LinearProgressIndicator(Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text("비서에게 메시지...") }, singleLine = true)
                TextButton(onClick = {
                    val q = draft.trim()
                    if (q.isNotEmpty() && !waiting) {
                        messages.add(ChatLine(true, q)); draft = ""
                        if (apiKey.isBlank()) messages.add(ChatLine(false, "실제 AI를 사용하려면 우측 상단 설정에서 본인의 OpenAI API 키를 입력해 주세요. 키가 없으면 기본 안내만 가능합니다.\n\n" + reply(q)))
                        else {
                            waiting = true
                            val history = messages.takeLast(16).map { it.mine to it.text }
                            scope.launch {
                                val result = withContext(Dispatchers.IO) { callSecretary(apiKey, model, history) }
                                messages.add(ChatLine(false, result)); waiting = false
                            }
                        }
                    }
                }) { Text("전송", color = gold) }
            }
        }
        if (showSettings) AlertDialog(onDismissRequest = { showSettings = false },
            title = { Text("AI 비서 연결") },
            text = { Column {
                Text("OpenAI API 키를 기기에 저장합니다. 개인 테스트 전용이며, 배포용 앱에서는 서버 프록시를 사용하세요.")
                OutlinedTextField(apiKey, { apiKey = it.trim() }, label = { Text("OpenAI API key") }, singleLine = true,
                    visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                OutlinedTextField(model, { model = it.trim() }, label = { Text("Model") }, singleLine = true)
            } },
            confirmButton = { TextButton(onClick = { prefs.edit().putString("api_key", apiKey).putString("model", model).apply(); showSettings = false }) { Text("저장") } },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("취소") } })
        Row(Modifier.fillMaxWidth().background(Color(0xFF25181E)).padding(12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Collection", "Secretary").forEach { tab ->
                Text(tab, Modifier.clickable { page = tab }.padding(8.dp), color = if (page == tab) gold else white)
            }
        }
    }
}

private fun callSecretary(key: String, model: String, history: List<Pair<Boolean, String>>): String = try {
    val url = URL("https://api.openai.com/v1/chat/completions")
    val conn = (url.openConnection() as HttpsURLConnection).apply {
        requestMethod = "POST"; connectTimeout = 15000; readTimeout = 45000; doOutput = true
        setRequestProperty("Authorization", "Bearer $key")
        setRequestProperty("Content-Type", "application/json")
    }
    val arr = JSONArray().put(JSONObject().put("role", "system").put("content", "You are IRIS PRIVÉ's elegant Korean-speaking private auction catalogue assistant. Help with media organization, manual price tags, catalogue descriptions, and tasteful fictional luxury atmosphere. Price tags are for images/videos, never prices of people. Do not claim to see the user's gallery or prices; no gallery data is sent. Be concise."))
    history.forEach { (mine, message) -> arr.put(JSONObject().put("role", if (mine) "user" else "assistant").put("content", message)) }
    val payload = JSONObject().put("model", model).put("messages", arr).put("max_tokens", 500)
    conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
    val status = conn.responseCode
    val response = (if (status in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
    conn.disconnect()
    if (status in 200..299) JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "응답이 비어 있습니다.")
    else "AI 요청 실패 (HTTP $status). API 키·모델·결제 상태를 확인해 주세요. " + JSONObject(response).optJSONObject("error")?.optString("message", "")?.take(180)
} catch (e: Exception) { "AI 연결 오류: ${e.message?.take(160) ?: "알 수 없는 오류"}" }
