package xyz.quaver.pupil.ui.compose

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val obsidian = Color(0xFF0B0B0C)
private val champagne = Color(0xFFC2A785)
private val ivory = Color(0xFFEAE2D8)
private val oxblood = Color(0xFF28191E)

/** Private collection home. Category and filters are connected to the actual MediaStore gallery. */
@Composable
fun IrisLibraryHub(onGalleryClick: (Int) -> Unit, onShowDetail: (Int) -> Unit) {
    var category by remember { mutableStateOf("TikTok") }
    var filter by remember { mutableStateOf("All") }
    Column(Modifier.fillMaxSize().background(obsidian).padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("PRIVATE COLLECTION", color = champagne, fontSize = 10.sp, letterSpacing = 2.sp)
            Text("◇", color = champagne, fontSize = 24.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text("IRIS PRIVÉ", color = ivory, fontSize = 32.sp, fontFamily = FontFamily.Serif)
        Text("THE ART OF PRIVATE DESIRE", color = champagne, fontSize = 10.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("TikTok", "Instagram", "Recap").forEach { name ->
                val active = category == name
                Surface(
                    modifier = Modifier.weight(1f).clickable { category = name; filter = "All" },
                    color = if (active) oxblood else Color(0xFF191719),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, if (active) champagne else Color(0xFF373033))
                ) {
                    Column(Modifier.padding(vertical = 13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(when (name) { "TikTok" -> "♪"; "Instagram" -> "◎"; else -> "♛" }, color = champagne, fontSize = 23.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(name, color = ivory, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Text(when (category) { "TikTok" -> "The Velvet Theatre"; "Instagram" -> "The Private Salon"; else -> "The Secret Archive" }, color = ivory, fontSize = 23.sp, fontFamily = FontFamily.Serif)
        Text("A world of your own.", color = Color(0xFFB2A29B), fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Images", "Videos").forEach { option ->
                Surface(
                    modifier = Modifier.clickable { filter = option },
                    color = if (filter == option) champagne else Color(0xFF252024),
                    shape = RoundedCornerShape(50)
                ) {
                    Text(option, Modifier.padding(horizontal = 16.dp, vertical = 9.dp), color = if (filter == option) obsidian else ivory, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        IrisGallerySection(Modifier.weight(1f), category = category, mediaFilter = filter)
    }
}
